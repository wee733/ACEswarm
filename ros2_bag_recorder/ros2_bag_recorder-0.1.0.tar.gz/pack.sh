#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
archive="${1:-ros2_bag_recorder-0.1.0.tar.gz}"
staging="$(mktemp -d)"
trap 'rm -rf "$staging"' EXIT
mkdir -p "$staging/backend"
cp -r manifest.yaml start.sh pack.sh assets config ui "$staging/"
cp backend/*.py "$staging/backend/"
tar -czf "$archive" -C "$staging" .
printf '%s\n' "$(realpath "$archive")"
