# Swarm Dashboard 0.3.4

订阅通过同源 Zenoh Bridge 2.3.0 网关的 /zenoh/api/zenoh/stream。独立页面与 Panel Hub 子应用共用相同的应用入口。配置、卡片与用户布局可在原设置编辑器中管理。
