"""One serialized PX4 command transaction and one local NED hold trajectory."""
from dataclasses import dataclass
import math
import re


ARM_DISARM, SET_MODE, NAV_LAND, SET_NAV_STATE = 400, 176, 21, 100001
OFFBOARD, AUTO_LOITER = 14, 4
ARMED = 2
# PX4 custom main/sub modes, as consumed by Commander::handle_command.
MODES = {'OFFBOARD': (6, 0), 'POSCTL': (3, 0), 'ALTCTL': (2, 0), 'STABILIZED': (7, 0),
         'AUTO.LOITER': (4, 3), 'AUTO.LAND': (4, 6), 'AUTO.RTL': (4, 5)}
ACTIONS = ('arm', 'disarm', 'set_mode', 'takeoff', 'land', 'cancel', 'register_extra')
RESULT = {0: 'ACCEPTED / PX4 已接受', 1: 'TEMPORARILY_REJECTED / PX4 暂时拒绝',
          2: 'DENIED / PX4 拒绝', 3: 'UNSUPPORTED / 不支持该指令', 4: 'FAILED / 指令执行失败',
          5: 'IN_PROGRESS / PX4 正在处理', 6: 'CANCELLED / PX4 已取消',
          7: 'COMMAND_LONG_ONLY', 8: 'COMMAND_INT_ONLY', 9: 'UNSUPPORTED_MAV_FRAME'}
ACK_TIMEOUT = 2.0
WARMUP = 1.1


def reply(command, message, code=None, ok=False, **extra):
    return dict(ok=ok, command=command, result_code=code, message=message, **extra)


@dataclass
class Request:
    name: str
    payload: dict
    respond: object
    deadline: float = 0.
    phase: str = ''
    command_id: int = 0
    sent_us: int = 0
    source_system: int = 0
    source_component: int = 0
    ack: object = None
    height: float = 0.

    @property
    def needs_offboard(self):
        return self.name == 'takeoff' or (self.name == 'set_mode' and self.payload.get('mode') == 'OFFBOARD')


@dataclass
class Hold:
    north: float
    east: float
    down: float
    yaw: float
    xy_reset: int
    z_reset: int
    yaw_reset: int
    target_down: float
    last_tick: float
    first_sample: float = 0.
    samples: int = 0
    active: bool = False
    armed: bool = False
    entry_grace_until: float = 0.


class Controller:
    def __init__(self, port, climb_rate, max_height):
        self.port = port
        self.climb_rate = climb_rate
        self.max_height = max_height
        self.pending = None
        self.hold = None
        self.samples = {}
        self.quarantine = {}

    def receive(self, kind, msg, now):
        self.samples[kind] = (msg, now)

    def sample(self, kind, now, max_age):
        msg, received = self.samples.get(kind, (None, -math.inf))
        if msg is None or now - received > max_age:
            raise ValueError(f'{kind} unavailable or stale / 缺少新鲜飞控数据')
        return msg

    def pose(self, now):
        p = self.sample('vehicle_local_position', now, .5)
        if not (p.xy_valid and p.z_valid and all(map(math.isfinite, (p.x, p.y, p.z)))):
            raise ValueError('Local position invalid / PX4 本地水平或高度定位无效')
        return p

    def status(self, now):
        return self.sample('vehicle_status', now, 2.)

    def check_liftoff(self, now):
        status = self.status(now)
        if status.arming_state != ARMED:
            raise ValueError('Takeoff requires an armed vehicle / 请先解锁')
        if not status.pre_flight_checks_pass or status.failsafe:
            raise ValueError('PX4 preflight checks failed or failsafe active / 飞控起飞条件未满足')
        if not self.sample('vehicle_land_detected', now, 2.).landed:
            raise ValueError('Takeoff requires confirmed landed state / 飞控未确认已着陆')

    def start_hold(self, now):
        pose = self.pose(now)
        self.hold = Hold(pose.x, pose.y, pose.z, pose.heading, pose.xy_reset_counter,
                         pose.z_reset_counter, pose.heading_reset_counter, pose.z, now)

    def freeze(self, now):
        if self.hold is not None:
            try:
                p = self.pose(now)
                self.hold.north, self.hold.east, self.hold.down = p.x, p.y, p.z
                self.hold.target_down = p.z
            except ValueError:
                self.hold = None

    def finish(self, body):
        req, self.pending = self.pending, None
        req.respond(body)

    def abort(self, reason, now):
        req = self.pending
        if req.phase == 'ack':
            # ACK lacks a transaction ID. Never reuse an ambiguous in-flight ID on retry.
            self.quarantine[req.command_id] = now + ACK_TIMEOUT
        if self.hold is not None and not self.hold.active:
            status = self.samples['vehicle_status'][0]
            if status.nav_state == OFFBOARD or req.phase == 'mode_confirmation':
                # PX4 may already be in OFFBOARD before its status sample arrives. Keep
                # the measured hold briefly so an interrupted transition never starts a climb.
                self.hold.active = True
                self.hold.armed = status.arming_state == ARMED
                self.hold.entry_grace_until = now + 1.5
                self.freeze(now)
            else:
                self.hold = None
        result = req.ack.result if req.ack is not None else None
        self.finish(reply(req.name, reason, code=result))

    def send(self, command, params, now):
        req = self.pending
        if now < self.quarantine.get(command, 0):
            raise ValueError('Previous ACK is unresolved / 上次同类型指令未确认，请稍后重试')
        status = self.status(now)
        req.command_id = command
        req.sent_us, req.source_system, req.source_component = self.port.send(command, params, status)
        req.deadline = now + ACK_TIMEOUT
        req.phase = 'ack'

    def set_mode(self, mode, payload, now):
        if mode == 'OFFBOARD':
            if self.status(now).failsafe:
                raise ValueError('PX4 failsafe active / 飞控处于失效保护')
            self.port.check_offboard()
            if self.hold is not None and self.hold.active and self.status(now).nav_state == OFFBOARD:
                # Our heartbeat is already running. Revalidate the mode with PX4 while
                # continuing the existing trajectory, including when PX4 rejects the command.
                self.pose(now)
                self.send(SET_MODE, (1, *MODES['OFFBOARD']), now)
                return
            self.start_hold(now)
            self.pending.phase = 'warmup'
            self.pending.deadline = now + WARMUP + 1.
            return
        if mode in MODES:
            self.send(SET_MODE, (1, *MODES[mode]), now)
            return
        if mode == 'EXTRA':
            mode_id = payload.get('nav_state', self.port.registered_id())
        elif isinstance(mode, str) and re.fullmatch(r'EXTERNAL[1-8]', mode):
            mode_id = 22 + int(mode[-1])
        else:
            raise ValueError('Unknown mode / 未知飞行模式')
        if type(mode_id) is not int or not 23 <= mode_id <= 30:
            raise ValueError('Extra mode is unregistered or nav_state is invalid / 外部模式未注册或 ID 无效')
        status = self.status(now)
        if not (status.valid_nav_states_mask & status.can_set_nav_states_mask & (1 << mode_id)):
            raise ValueError(f'External mode {mode_id} unavailable / PX4 未开放该外部模式')
        self.send(SET_NAV_STATE, (mode_id,), now)

    def request(self, req, now):
        if self.pending is not None:
            if req.name != 'cancel' or self.pending.name not in ('takeoff', 'set_mode'):
                req.respond(reply(req.name, 'Busy / 正在等待上一条飞控指令'))
                return
            self.abort('Superseded by cancel / 已被取消请求中止', now)
        self.pending = req
        try:
            p = req.payload
            if req.name in ('disarm', 'arm'):
                arm = p.get('value') if req.name == 'arm' else False
                if type(arm) is not bool or (arm and p.get('confirm') is not True):
                    raise ValueError('Arm requires {"value":true,"confirm":true}; use {"value":false} to disarm')
                if arm and not self.status(now).pre_flight_checks_pass:
                    raise ValueError('Preflight checks failed / PX4 起飞前检查未通过')
                self.send(ARM_DISARM, (int(arm), 0), now)
            elif req.name == 'takeoff':
                h = p.get('target_altitude_m')
                if type(h) not in (float, int) or not math.isfinite(h) or not 0 < h <= self.max_height:
                    raise ValueError(f'target_altitude_m must be within (0, {self.max_height:g}] m')
                self.check_liftoff(now)
                req.height = h
                self.set_mode('OFFBOARD', p, now)
            elif req.name == 'set_mode':
                mode = p.get('mode')
                if not isinstance(mode, str):
                    raise ValueError('A mode string is required / 缺少模式名称')
                self.set_mode(mode, p, now)
            elif req.name == 'land':
                self.freeze(now)
                self.send(NAV_LAND, (0, 0, 0, math.nan, math.nan, math.nan, math.nan), now)
            elif req.name == 'cancel':
                self.freeze(now)
                # Use a different command ID if a DO_SET_MODE ACK is still in flight.
                if now < self.quarantine.get(SET_MODE, 0):
                    self.send(SET_NAV_STATE, (AUTO_LOITER,), now)
                else:
                    self.set_mode('AUTO.LOITER', p, now)
            else:
                raise ValueError('Unknown command')
        except (ValueError, RuntimeError, OverflowError) as err:
            self.abort(str(err), now)

    def acknowledge(self, ack, now):
        req = self.pending
        if req is None or req.phase != 'ack' or now > req.deadline:
            return
        if (ack.command != req.command_id or ack.target_system != req.source_system
                or ack.target_component != req.source_component or ack.timestamp < req.sent_us):
            return
        req.ack = ack
        if ack.result == 5:
            return  # Preserve progress, continue waiting for a terminal result.
        if req.needs_offboard and ack.result == 0:
            req.phase, req.deadline = 'mode_confirmation', now + 1.5
            return
        if req.needs_offboard and self.hold and not self.hold.active:
            self.hold = None
        if ack.result == 0 and (req.name != 'arm' or req.payload.get('value') is False):
            # Continue holding until status confirms the handover or disarm.
            self.freeze(now)
        self.finish_ack()

    def finish_ack(self, detail=''):
        req, ack = self.pending, self.pending.ack
        message = RESULT.get(ack.result, f'Unknown PX4 result {ack.result}')
        self.finish(reply(req.name, (message + ' ' + detail).strip(), code=ack.result,
                          ok=ack.result == 0, vehicle_command=ack.command,
                          result_param1=ack.result_param1, result_param2=ack.result_param2))

    def tick(self, now):
        req = self.pending
        if req and now > req.deadline:
            reason = {'ack': 'No terminal PX4 ACK within 2 s / 飞控回执超时',
                      'warmup': 'OFFBOARD stream warmup interrupted / 预热未连续完成',
                      'mode_confirmation': 'PX4 ACK accepted but OFFBOARD entry unconfirmed / 未确认进入 OFFBOARD'}
            self.abort(reason[req.phase], now)
        if self.hold is None:
            return
        try:
            self.update_hold(now)
        except (ValueError, RuntimeError) as err:
            self.hold = None
            self.port.report(str(err))
            if self.pending and self.pending.needs_offboard:
                self.abort(str(err), now)

    def update_hold(self, now):
        hold, req = self.hold, self.pending
        status, p = self.status(now), self.pose(now)
        if status.failsafe:
            raise ValueError('PX4 failsafe active / 已停止 OFFBOARD 输出')
        if (p.xy_reset_counter, p.z_reset_counter, p.heading_reset_counter) != (
                hold.xy_reset, hold.z_reset, hold.yaw_reset):
            raise ValueError('Local estimate reset / 定位基准发生重置，已停止 OFFBOARD 输出')
        if status.nav_state == OFFBOARD:
            hold.entry_grace_until = 0.
        if hold.active and ((status.nav_state != OFFBOARD and now >= hold.entry_grace_until)
                            or (hold.armed and status.arming_state != ARMED)):
            self.hold = None
            if req and req.needs_offboard:
                self.abort('PX4 left OFFBOARD or disarmed / 飞控已退出 OFFBOARD 或上锁', now)
            return
        dt = now - hold.last_tick
        if dt > .15 and not hold.active:
            hold.samples = 0
        if hold.samples == 0:
            hold.first_sample = now
        hold.last_tick = now
        if not hold.active:
            # Hold the measured pose throughout the handshake; only climb after confirmed entry.
            hold.north, hold.east, hold.down = p.x, p.y, p.z
            hold.target_down = p.z
            hold.yaw = p.heading
        else:
            if status.arming_state == ARMED:
                hold.armed = True
            # Positive ENU climb maps to decreasing NED down. Cap dt after scheduling gaps.
            hold.down = max(hold.target_down, hold.down - self.climb_rate * min(.1, dt))
        self.port.publish_hold(hold)
        hold.samples += 1
        if req is None:
            return
        if req.name == 'takeoff':
            try:
                self.check_liftoff(now)
            except ValueError as err:
                self.abort(str(err), now)
                return
        if req.phase == 'warmup' and now - hold.first_sample >= WARMUP and hold.samples >= 22:
            self.send(SET_MODE, (1, *MODES['OFFBOARD']), now)
        if req.phase == 'mode_confirmation' and status.nav_state == OFFBOARD:
            hold.active = True
            hold.armed = status.arming_state == ARMED
            hold.north, hold.east, hold.down = p.x, p.y, p.z
            hold.target_down = hold.down - req.height
            self.finish_ack('OFFBOARD confirmed; climb started / 已开始爬升' if req.height
                            else 'OFFBOARD confirmed / 已确认进入 OFFBOARD')
