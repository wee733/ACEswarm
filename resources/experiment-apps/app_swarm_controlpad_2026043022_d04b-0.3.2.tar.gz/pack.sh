#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
out="$(realpath -m "${1:-artifacts}")"
mkdir -p "$out"
tar --sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner -czf "$out/app_swarm_controlpad_2026043022_d04b-0.3.2.tar.gz" README.md manifest.yaml pack.sh start.sh assets config scripts ui
