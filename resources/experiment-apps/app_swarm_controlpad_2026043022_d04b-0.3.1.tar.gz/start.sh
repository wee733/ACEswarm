#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/scripts/render-config.py" "$SCRIPT_DIR" swarm_controlpad "${AIVUDA_APP_CONFIG_PATH:-}"
# Caddy serves assets on the host; only the managed idle process runs in Docker.
config_path="${AIVUDA_APP_CONFIG_PATH:-$SCRIPT_DIR/config/default_config.yaml}"
if [[ "$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" swarm_controlpad.docker.enabled false)" == true ]]; then
  source "$SCRIPT_DIR/scripts/docker_helpers.sh"
  container="$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" swarm_controlpad.docker.container '')"
  docker_helper_target_use_docker_container "$container"
  docker_helper_target_require_available '[start.sh]'
  exec python3 "$SCRIPT_DIR/scripts/process_runner.py" --container "$container" -- tail -f /dev/null
else
  exec tail -f /dev/null
fi
