# foxglove_studio_embed_pkg

`foxglove_studio_embed_pkg` 是一个符合 AivudaOS 规范的 app package，用于在应用内嵌入 Foxglove Studio 页面。

clone仓库后还记得要更新子模块：

```bash
git submodule update --init --recursive 
```

## 目录结构

- `manifest.yaml`：标准 Aivuda app manifest
- `start.sh`：运行入口脚本
- `scripts/pre_install.sh`：为 ROS1/ROS2 bridge 准备依赖，并准备 host 上 custom backend 与 local embed mirror server 的 Python venv（不包含 crawl 依赖）
- `scripts/docker_helpers.sh`：复用与 `roscore_pkg` 同风格的 host/docker 目标执行 helper，用于 ROS bridge 命令
- `config/default_config.yaml`：运行时 ROS/backend 配置
- `config/config_schema.yaml`：运行时配置 schema
- `config/caddy/foxglove_studio_embed.caddy`：将 `/foxglove_studio_embed/embed_mirror_server` 代理到 local embed mirror server，将 `/foxglove_studio_embed/ws` 代理到 aggregator，并将 `/foxglove_studio_embed/api` 代理到 display control API
- `assets/icon.png`：应用图标
- `ui/`：前端构建产物，作为 `ui_index_path`
- `foxglove_studio_panel/`：前端源码目录，仅参与构建，不会打进最终 tar.gz

## 前端构建

在源码目录中安装依赖并构建：

```bash
cd foxglove_studio_panel
pnpm install
pnpm build
```

构建完成后，静态资源会输出到包根目录的 `ui/`。

## 打包

包根目录提供 `pack.sh`：

```bash
./pack.sh
./pack.sh /tmp/aivuda-packages
```

打包规则：

- tar.gz 根目录直接包含 `manifest.yaml`
- 包含 `start.sh`、`scripts/`、`config/`、`assets/`、`ui/`
- 包含 `backend/`，其中 `visualize_foxglove_server` 提供 Foxglove SDK custom server 和 URDF/mesh assets，`foxglove_embed_mirror_server` 提供本地离线 embed mirror HTTP 服务
- 忽略 `.git/`
- 忽略 `foxglove_studio_panel/` 前端源码目录及其构建依赖

## 配置项

`config/default_config.yaml` 当前包含以下字段：

- `ros.distro`
- `ros.setup_script`
- `foxglove_studio_embed.ros_runtime.docker.*`
- `foxglove_studio_embed.backend.embed_mirror_server.*`
- `foxglove_studio_embed.backend.foxglove_bridge.*`
- `foxglove_studio_embed.backend.aggregator.*`
- `foxglove_studio_embed.backend.visualize.*`

运行行为：

- `scripts/pre_install.sh` 会先为 ROS 1 部分选择运行目标：host 或当前运行中的 docker container
- 若选择 docker，默认前提是该容器使用 `--network host`，这样 host 上的 aggregator 仍可通过当前本地地址访问容器内的 `foxglove_bridge`
- `foxglove_studio_embed.ros_runtime.docker.enabled=true` 时，`start.sh` 只会把 `rosnode` 检查和 `foxglove_bridge` 启动放到对应容器内执行；其余 Python/conda backend 仍固定运行在 host
- `foxglove_studio_embed.backend.embed_mirror_server.enabled=true` 时，`start.sh` 会先启动 `foxglove_embed_mirror_server`，默认监听 `127.0.0.1:3000`
- `foxglove_studio_embed.backend.foxglove_bridge.enabled=true` 时，`start.sh` 会先在 ROS 目标环境里等待 `roscore`/`rosout` 就绪
- `foxglove_studio_embed.backend.foxglove_bridge.enabled=true` 时启动 ROS 1 `foxglove_bridge`，默认监听 `127.0.0.1:18766`，并将其作为 aggregator 的 ROS upstream
- `foxglove_studio_embed.backend.foxglove_bridge.services_enabled=false` 时，`foxglove_bridge` 不向 Studio 暴露 ROS service capability，并使用空 `service_whitelist`
- 启动 `visualize_foxglove_server`，默认监听 `127.0.0.1:18767`，并启动 display control API，默认监听 `127.0.0.1:19287`
- 启动 foxglove aggregator，默认监听 `127.0.0.1:8765`，作为 Studio 的唯一入口
- AivudaOS 顶层 Caddy 会把 `/foxglove_studio_embed/embed_mirror_server` 反代到本地 embed mirror 服务
- AivudaOS 顶层 Caddy 会把 `/foxglove_studio_embed/ws` 反代到 aggregator WebSocket 服务
- AivudaOS 顶层 Caddy 会把 `/foxglove_studio_embed/api` 反代到 display control API
- 前端默认 organization 为 `offline`，默认 embed src 为当前站点下的 `/foxglove_studio_embed/embed_mirror_server`
- 若 `foxglove_studio_embed.backend.embed_mirror_server.enabled=false`，本地 offline embed preset 仍会显示在前端，但对应 mirror 服务不会启动
- Settings 中的 organization 和 embed src 都提供离线默认、官方源和用户自定义三种模式；官方源选项会提示“官方源，需要联网认证”
- 前端默认连接当前站点下的 `/foxglove_studio_embed/ws`，并通过 `/foxglove_studio_embed/api/displays` 动态增删改 display robots
- 前端作为 panelhub/qiankun 子应用运行时，右侧 `Auto configure` 可订阅 sharedState 的 `swarm.dashboardRobots`，使用其中每个 robot 的 `name` 和 `robotType` 全量同步 display robots 到 `/foxglove_studio_embed/api/displays`
- 当 `foxglove_studio_embed.backend.visualize.enabled=true` 时，`start.sh` 会给 aggregator 配置 `lifecycle_hook_url`，指向 display control API 的 `/lifecycle`
- aggregator 检测到 Studio 前端连接数变化后会 POST lifecycle event；当连接数为 0 时，display control API 会等待 `foxglove_studio_embed.backend.visualize.display_control_api.idle_clear_delay_sec` 秒，期间无人重连则清空所有 display robots
- 当前 `config/caddy/foxglove_studio_embed.caddy` 是固定路由：`foxglove_studio_embed.backend.embed_mirror_server.proxy_path=/foxglove_studio_embed/embed_mirror_server`、`foxglove_studio_embed.backend.aggregator.proxy_path=/foxglove_studio_embed/ws`、`foxglove_studio_embed.backend.visualize.display_control_api.proxy_path=/foxglove_studio_embed/api`，并固定反代到本机端口 `3000`、`8765` 和 `19287`
- 因为 Caddy 配置目前是固定的，config schema 会将相关 `host`、`port`、`proxy_path` 字段限制为单一可选值，避免修改配置后与实际反代链路不一致
- Python 后端默认使用应用内的 `.venv`。

display lifecycle 清理链路：

```text
Foxglove Studio 断开
  -> aggregator frontend client_count 变为 0
  -> HTTP POST http://127.0.0.1:19287/lifecycle
  -> display control API 延迟确认空闲
  -> replace displays with []
```

display auto configure 链路：

```text
swarm_dashboard
  -> sharedState swarm.dashboardRobots
  -> foxglove_studio_panel Auto configure
  -> PUT /foxglove_studio_embed/api/displays
  -> display control API replace displays
```

ROS2 bridge 配置：`backend.foxglove_bridge_ros2.enabled`，默认启用，先加载 Lyrical 基座，再加载已配置的消息工作区。`overlay_setup_scripts` 可加载自定义 ROS2 消息工作空间。模型、轨迹、TF 与原生 ROS 2 CDR 消息共用聚合 WebSocket。可视化后端使用官方 eclipse-zenoh Python SDK，通过局域网发现 peer。若环境要求固定连接，在 backend.visualize.foxglove_sdk_server.zenoh_endpoint 填写实际已监听的 Zenoh locator，如 tcp/192.168.20.10:7447。

## Standalone packaging

Clone this repository (with `--recurse-submodules` when it has submodules). Run `./pack.sh` from any directory; output defaults to the repository’s `artifacts/`, or pass an output directory. Packaging uses Bash, sed and tar; no Python packaging dependencies or sibling repositories are required. UI packages additionally require Node.js/npm and run `npm ci` followed by `npm run build`. Custom ROS sources are built by `pre_install` for the selected host/container ROS distribution; generated workspaces are excluded from the archive. System-package wrappers require no compilation.

The archive contains local runtime sources/assets, validates manifest paths and default configuration, excludes development/build caches, and rejects external symlinks. `SOURCE_DATE_EPOCH` controls archive timestamps (default 0).
