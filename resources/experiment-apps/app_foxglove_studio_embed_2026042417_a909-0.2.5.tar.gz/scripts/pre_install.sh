#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_PATH="${AIVUDA_APP_CONFIG_PATH:-$APP_ROOT/config/default_config.yaml}"
source "$APP_ROOT/scripts/docker_helpers.sh"
get() { python3 "$APP_ROOT/scripts/config_get.py" "$CONFIG_PATH" "$1" "$2"; }
ros1="$(get foxglove_studio_embed.backend.foxglove_bridge.enabled false)"
ros2="$(get foxglove_studio_embed.backend.foxglove_bridge_ros2.enabled false)"
[[ "$ros1" != true || "$ros2" != true ]] || { echo 'ROS1 and ROS2 bridges are mutually exclusive' >&2; exit 1; }
if [[ "$(get foxglove_studio_embed.ros_runtime.docker.enabled false)" == true ]]; then
  docker_helper_target_use_docker_container "$(get foxglove_studio_embed.ros_runtime.docker.container '')"
fi
if [[ "$ros1" == true || "$ros2" == true ]]; then
  if [[ "$ros2" == true ]]; then distro="$(get foxglove_studio_embed.backend.foxglove_bridge_ros2.distro lyrical)"; else distro="$(get ros.distro noetic)"; fi
  [[ "$distro" =~ ^[a-z0-9]+$ ]] || exit 1
  if docker_helper_target_is_docker; then
    docker_helper_target_exec_bash "dpkg -s ros-$distro-foxglove-bridge >/dev/null || { apt-get update && apt-get install -y ros-$distro-foxglove-bridge; }"
  elif ! [[ -f "/opt/ros/$distro/share/foxglove_bridge/package.xml" ]]; then
    python3 "$APP_ROOT/scripts/install_ros_deb.py" "ros-$distro-foxglove-bridge" "$APP_ROOT/.ros-deps"
  fi
fi
# Prepare the ROS2 bridge when ROS2 exists even if its runtime toggle is off.
distro="$(get foxglove_studio_embed.backend.foxglove_bridge_ros2.distro lyrical)"
if [[ -f "/opt/ros/$distro/setup.bash" && ! -f "/opt/ros/$distro/share/foxglove_bridge/package.xml" && ! -f "$APP_ROOT/.ros-deps/opt/ros/$distro/share/foxglove_bridge/package.xml" ]]; then
  python3 "$APP_ROOT/scripts/install_ros_deb.py" "ros-$distro-foxglove-bridge" "$APP_ROOT/.ros-deps"
fi
python3 -m venv "$APP_ROOT/.venv"
"$APP_ROOT/.venv/bin/python" -m pip install 'foxglove-sdk==0.31.0' 'websockets==13.1' PyYAML cbor2 'eclipse-zenoh==1.9.0'
