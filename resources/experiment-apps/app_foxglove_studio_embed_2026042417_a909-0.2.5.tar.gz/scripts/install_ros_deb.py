#!/usr/bin/env python3
"""Install an official ROS apt package into an app-owned prefix without sudo.

apt sources and runtime dependencies must already exist; never modifies system packages.
"""
import argparse,pathlib,subprocess,tempfile,json,hashlib
p=argparse.ArgumentParser();p.add_argument('package');p.add_argument('destination');a=p.parse_args()
dest=pathlib.Path(a.destination).resolve();dest.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='aivuda-ros-deb-') as work:
 subprocess.run(['apt-get','download',a.package],cwd=work,check=True)
 packages=list(pathlib.Path(work).glob('*.deb'))
 if len(packages)!=1:raise RuntimeError('Expected exactly one apt archive')
 archive=packages[0]
 version=subprocess.check_output(['dpkg-deb','-f',str(archive),'Version'],text=True).strip()
 subprocess.run(['dpkg-deb','-x',str(archive),str(dest)],check=True)
 (dest/'package-provenance.json').write_text(json.dumps({'package':a.package,'version':version,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source':'configured official ROS apt repository'},indent=2)+'\n')
