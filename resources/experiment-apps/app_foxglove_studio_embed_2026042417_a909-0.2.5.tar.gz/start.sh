#!/usr/bin/env bash
set -e

echo "[start.sh] started at $(date '+%Y-%m-%d %H:%M:%S')"
echo "[start.sh] app: ${AIVUDA_APP_ID:-foxglove_studio_embed}@${AIVUDA_APP_VERSION:-0.2.5}"

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_PATH="${AIVUDA_APP_CONFIG_PATH:-${APP_ROOT}/config/default_config.yaml}"
RUNTIME_DIR="${AIVUDA_APP_RUNTIME_DATA_PATH:-${AIVUDAOS_WS_ROOT:-$HOME/aivudaOS_ws}/data/runtime/foxglove_studio_embed}"
CONDA_ENV_NAME="${FOXGLOVE_STUDIO_EMBED_CONDA_ENV:-foxglove-studio-embed-py310}"
CONDA_ROOT="${CONDA_ROOT:-${HOME}/miniconda3}"
DOCKER_HELPERS_PATH="${APP_ROOT}/scripts/docker_helpers.sh"

# Own the full host process group; bridges have their own nested container supervisor.
if [[ "${AIVUDA_FOX_MANAGED_INTERNAL:-0}" != 1 ]]; then
  export AIVUDA_FOX_MANAGED_INTERNAL=1
  exec python3 "$APP_ROOT/scripts/process_runner.py" -- bash "$APP_ROOT/start.sh"
fi

source "${DOCKER_HELPERS_PATH}" # for docker_helper_xxx functions

mkdir -p "${RUNTIME_DIR}"

yaml_get() {
  local key="$1"
  local fallback="$2"

  if [[ -n "${AIVUDA_APP_HELPERS_ENTRY_PATH:-}" ]] && [[ -f "${AIVUDA_APP_HELPERS_ENTRY_PATH}" ]]; then
    # shellcheck disable=SC1090
    source "${AIVUDA_APP_HELPERS_ENTRY_PATH}"
    aivuda_yaml_get "${key}" "${fallback}"
    return 0
  fi

  python3 "${APP_ROOT}/scripts/config_get.py" "${CONFIG_PATH}" "${key}" "${fallback}"
}

find_conda() {
  if command -v conda >/dev/null 2>&1; then
    command -v conda
    return 0
  fi
  if [[ -x "${CONDA_ROOT}/condabin/conda" ]]; then
    echo "${CONDA_ROOT}/condabin/conda"
    return 0
  fi
  if [[ -x "${HOME}/miniconda3/condabin/conda" ]]; then
    echo "${HOME}/miniconda3/condabin/conda"
    return 0
  fi
  return 1
}

wait_for_websocket() {
  local host="$1"
  local port="$2"
  local name="$3"
  local subprotocol="$4"
  local attempt

  for attempt in $(seq 1 80); do
    if "${backend_python}" - "${host}" "${port}" "${subprotocol}" <<'PY' >/dev/null 2>&1
import asyncio
import sys

import websockets


async def main() -> None:
    host = sys.argv[1]
    port = int(sys.argv[2])
    subprotocol = sys.argv[3]
    async with websockets.connect(
        f"ws://{host}:{port}",
        subprotocols=list(dict.fromkeys([subprotocol, "foxglove.sdk.v1"])),
        open_timeout=0.5,
        ping_interval=None,
    ):
        pass


asyncio.run(main())
PY
    then
      echo "[start.sh] ${name} is reachable at ${host}:${port}"
      return 0
    fi
    sleep 0.25
  done

  echo "[start.sh] ${name} did not become reachable at ${host}:${port}"
  return 1
}

cleanup() {
  local status=$?
  trap - EXIT INT TERM
  echo "[start.sh] stopping child processes"
  for pid in "${child_pids[@]:-}"; do
    if kill -0 "${pid}" >/dev/null 2>&1; then
      kill "${pid}" >/dev/null 2>&1 || true
    fi
  done
  wait >/dev/null 2>&1 || true
  exit "${status}"
}

wait_for_rosout() {
  local wait_command

  wait_command="$(cat <<EOF
if [[ -f $(printf '%q' "${setup_script}") ]]; then
  source $(printf '%q' "${setup_script}")
fi
rosnode ping -c 1 rosout >/dev/null 2>&1
EOF
)"

  echo "[start.sh] waiting for roscore/rosout on $(docker_helper_target_describe) ..."
  while ! docker_helper_target_exec_bash "${wait_command}"; do
    echo "[start.sh] rosout not ready yet on $(docker_helper_target_describe), retrying in 1s"
    sleep 1
  done
}

launch_foxglove_bridge_runner() {
  local bridge_command

  bridge_command="$(cat <<EOF
if [[ -f $(printf '%q' "${setup_script}") ]]; then
  source $(printf '%q' "${setup_script}")
fi

if ! command -v roslaunch >/dev/null 2>&1; then
  echo '[start.sh] roslaunch not found after sourcing setup script'
  exit 1
fi

exec roslaunch foxglove_bridge foxglove_bridge.launch \
  port:=$(printf '%q' "${ros_bridge_port}") \
  address:=$(printf '%q' "${ros_bridge_host}") \
  capabilities:=$(printf '%q' "${foxglove_bridge_capabilities}") \
  service_whitelist:=$(printf '%q' "${foxglove_bridge_service_whitelist}")
EOF
)"

  if [[ "$bridge_ros_version" == 2 ]]; then
    printf -v bridge_command 'exec ros2 launch foxglove_bridge foxglove_bridge_launch.xml port:=%q address:=%q capabilities:=%q service_whitelist:=%q' \
      "$ros_bridge_port" "$ros_bridge_host" "$foxglove_bridge_capabilities" "$foxglove_bridge_service_whitelist"
    # Source configured message overlays before bridge startup, including custom flight status types.
    local overlays overlay prefix
    printf -v prefix 'set -e; source %q; ' "$setup_script"
    overlays="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.overlay_setup_scripts' '[]')"
    while IFS= read -r overlay; do
      [[ -n "$overlay" ]] || continue
      printf -v prefix '%ssource %q; ' "$prefix" "$overlay"
    done < <(python3 -c 'import sys,yaml; print("\n".join(yaml.safe_load(sys.argv[1]) or []))' "$overlays")
    if [[ -d "$APP_ROOT/.ros-deps/opt/ros/$ros_distro" ]]; then
      printf -v prefix '%sexport AMENT_PREFIX_PATH=%q:$AMENT_PREFIX_PATH; export LD_LIBRARY_PATH=%q:$LD_LIBRARY_PATH; ' "$prefix" "$APP_ROOT/.ros-deps/opt/ros/$ros_distro" "$APP_ROOT/.ros-deps/opt/ros/$ros_distro/lib"
    fi
    bridge_command="${prefix}${bridge_command}"

  fi
  if docker_helper_target_is_docker; then
    python3 "$APP_ROOT/scripts/process_runner.py" --container "$TARGET_EXEC_CONTAINER" -- bash -c "${bridge_command}" &
  else
    python3 "$APP_ROOT/scripts/process_runner.py" -- bash -c "${bridge_command}" &
  fi
  bridge_runner_pid=$!
  child_pids+=("${bridge_runner_pid}")
}

ros_distro="$(yaml_get 'ros.distro' 'noetic')"
setup_script="$(yaml_get 'ros.setup_script' "/opt/ros/${ros_distro}/setup.bash")"
ros_runtime_docker_enabled="$(yaml_get 'foxglove_studio_embed.ros_runtime.docker.enabled' 'false')"
ros_runtime_docker_container="$(yaml_get 'foxglove_studio_embed.ros_runtime.docker.container' '')"
bridge_proxy_path="$(yaml_get 'foxglove_studio_embed.backend.aggregator.proxy_path' '/foxglove_studio_embed/ws')"
embed_mirror_enabled="$(yaml_get 'foxglove_studio_embed.backend.embed_mirror_server.enabled' 'true')"
embed_mirror_proxy_path="$(yaml_get 'foxglove_studio_embed.backend.embed_mirror_server.proxy_path' '/foxglove_studio_embed/embed_mirror_server')"
embed_mirror_host="$(yaml_get 'foxglove_studio_embed.backend.embed_mirror_server.listen_host' '127.0.0.1')"
embed_mirror_port="$(yaml_get 'foxglove_studio_embed.backend.embed_mirror_server.listen_port' '3000')"
foxglove_bridge_enabled="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge.enabled' 'false')"
foxglove_bridge_services_enabled="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge.services_enabled' 'false')"
aggregator_host="$(yaml_get 'foxglove_studio_embed.backend.aggregator.listen_host' '127.0.0.1')"
aggregator_port="$(yaml_get 'foxglove_studio_embed.backend.aggregator.listen_port' '8765')"
ros_bridge_host="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge.listen_host' '127.0.0.1')"
ros_bridge_port="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge.listen_port' '18766')"
ros2_bridge_enabled="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.enabled' 'false')"
if [[ "$foxglove_bridge_enabled" == true && "$ros2_bridge_enabled" == true ]]; then
  echo '[start.sh] ROS1 and ROS2 bridges cannot both be enabled' >&2; exit 1
fi
bridge_ros_version=1
if [[ "$ros2_bridge_enabled" == true ]]; then
  bridge_ros_version=2
  foxglove_bridge_enabled=true
  ros_distro="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.distro' 'lyrical')"
  setup_script="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.setup_script' "/opt/ros/$ros_distro/setup.bash")"
  ros_bridge_host="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.listen_host' '127.0.0.1')"
  ros_bridge_port="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.listen_port' '18766')"
  foxglove_bridge_services_enabled="$(yaml_get 'foxglove_studio_embed.backend.foxglove_bridge_ros2.services_enabled' 'false')"
fi
visualize_enabled="$(yaml_get 'foxglove_studio_embed.backend.visualize.enabled' 'true')"
custom_server_host="$(yaml_get 'foxglove_studio_embed.backend.visualize.foxglove_sdk_server.listen_host' '127.0.0.1')"
custom_server_port="$(yaml_get 'foxglove_studio_embed.backend.visualize.foxglove_sdk_server.listen_port' '18767')"
control_host="$(yaml_get 'foxglove_studio_embed.backend.visualize.display_control_api.listen_host' '127.0.0.1')"
control_port="$(yaml_get 'foxglove_studio_embed.backend.visualize.display_control_api.listen_port' '19287')"
control_proxy_path="$(yaml_get 'foxglove_studio_embed.backend.visualize.display_control_api.proxy_path' '/foxglove_studio_embed/api')"
idle_clear_delay_sec="$(yaml_get 'foxglove_studio_embed.backend.visualize.display_control_api.idle_clear_delay_sec' '3.0')"
zenoh_endpoint="$(yaml_get 'foxglove_studio_embed.backend.visualize.foxglove_sdk_server.zenoh_endpoint' '')"

echo "[start.sh] config path: ${CONFIG_PATH}"
echo "[start.sh] runtime dir: ${RUNTIME_DIR}"
echo "[start.sh] ros distro: ${ros_distro}"
echo "[start.sh] setup script: ${setup_script}"
echo "[start.sh] ROS runtime docker enabled: ${ros_runtime_docker_enabled}"
echo "[start.sh] ROS runtime docker container: ${ros_runtime_docker_container:-<empty>}"
echo "[start.sh] embed mirror: enabled=${embed_mirror_enabled} ${embed_mirror_host}:${embed_mirror_port} proxy=${embed_mirror_proxy_path}"
echo "[start.sh] aggregator proxy path: ${bridge_proxy_path}"
echo "[start.sh] foxglove bridge enabled: ${foxglove_bridge_enabled}"
echo "[start.sh] foxglove bridge services enabled: ${foxglove_bridge_services_enabled}"
echo "[start.sh] aggregator address: ${aggregator_host}:${aggregator_port}"
echo "[start.sh] ros bridge upstream: ${ros_bridge_host}:${ros_bridge_port}"
echo "[start.sh] custom visualize server: ${custom_server_host}:${custom_server_port} enabled=${visualize_enabled}"
echo "[start.sh] display control API: ${control_host}:${control_port} proxy=${control_proxy_path}"
echo "[start.sh] display idle clear delay: ${idle_clear_delay_sec}s"
echo "[start.sh] zenoh endpoint: ${zenoh_endpoint}"

if [[ "${ros_runtime_docker_enabled}" == "true" ]]; then
  docker_helper_target_use_docker_container "${ros_runtime_docker_container}"
else
  docker_helper_target_use_host
fi

echo "[start.sh] ROS runtime target: $(docker_helper_target_describe)"

backend_python="${FOXGLOVE_BACKEND_PYTHON:-${APP_ROOT}/.venv/bin/python}"
[[ -x "$backend_python" ]] || { echo 'Backend venv missing; run pre_install.sh' >&2; exit 1; }
"$backend_python" -c 'import cbor2, foxglove, websockets, yaml, zenoh'

wait_for_tcp() {
  local host="$1"
  local port="$2"
  local name="$3"
  local attempt

  for attempt in $(seq 1 80); do
    if python3 - "${host}" "${port}" <<'PY' >/dev/null 2>&1
import socket
import sys

host = sys.argv[1]
port = int(sys.argv[2])
with socket.create_connection((host, port), timeout=0.5):
    pass
PY
    then
      echo "[start.sh] ${name} is reachable at ${host}:${port}"
      return 0
    fi
    sleep 0.25
  done

  echo "[start.sh] ${name} did not become reachable at ${host}:${port}"
  return 1
}

embed_mirror_backend_dir="${APP_ROOT}/backend/foxglove_embed_mirror_server"
embed_mirror_config="${RUNTIME_DIR}/embed_mirror_server.yaml"
if [[ "${embed_mirror_enabled}" == "true" ]]; then
  cat >"${embed_mirror_config}" <<EOF
listen:
  host: "${embed_mirror_host}"
  port: ${embed_mirror_port}

static_dir: "${embed_mirror_backend_dir}/static"
manifest_path: "${embed_mirror_backend_dir}/manifest.json"

runtime_config: {}

crawl:
  target_url: "https://embed.foxglove.dev/"
  probe_query: "?src=live&url=ws%3A%2F%2Fdummy"
  settle_seconds: 8
  nav_timeout_ms: 60000
  allowed_hosts:
    - "embed.foxglove.dev"
EOF

  if [[ ! -f "${embed_mirror_backend_dir}/static/index.html" ]]; then
    echo "[start.sh] embed mirror static root missing: ${embed_mirror_backend_dir}/static/index.html"
    echo "[start.sh] prepare mirror assets before starting the app"
    exit 1
  fi
fi

if [[ "${foxglove_bridge_enabled}" == "true" ]]; then
  [[ "$bridge_ros_version" == 2 ]] || wait_for_rosout
else
  echo "[start.sh] foxglove_bridge disabled; skipping ROS setup and roscore wait"
fi

aggregator_config="${RUNTIME_DIR}/aggregator.yaml"
if [[ "${visualize_enabled}" == "true" ]]; then
  cat >"${aggregator_config}" <<EOF
listen: "${aggregator_host}:${aggregator_port}"
lifecycle_hook_url: "http://${control_host}:${control_port}/lifecycle"

ros:
  enabled: ${foxglove_bridge_enabled}
  url: "ws://${ros_bridge_host}:${ros_bridge_port}"

custom:
  - name: "visualize_foxglove_server"
    url: "ws://${custom_server_host}:${custom_server_port}"
    topic_prefixes: ["/visualize_foxglove_sdk/"]
    package_prefixes: ["px4_rotor_sim"]
    default: true
EOF
else
  cat >"${aggregator_config}" <<EOF
listen: "${aggregator_host}:${aggregator_port}"

ros:
  enabled: ${foxglove_bridge_enabled}
  url: "ws://${ros_bridge_host}:${ros_bridge_port}"

custom: []
EOF
fi

child_pids=()
trap cleanup EXIT INT TERM

if [[ "${embed_mirror_enabled}" == "true" ]]; then
  echo "[start.sh] launching foxglove embed mirror server on ${embed_mirror_host}:${embed_mirror_port}"
  "${backend_python}" \
    "${embed_mirror_backend_dir}/main.py" \
    --config "${embed_mirror_config}" \
    serve &
  child_pids+=("$!")

  wait_for_tcp "${embed_mirror_host}" "${embed_mirror_port}" "foxglove embed mirror server"
else
  echo "[start.sh] embed mirror server disabled; frontend offline embed preset will be unavailable"
fi

if [[ "${foxglove_bridge_enabled}" == "true" && "${foxglove_bridge_services_enabled}" == "true" ]]; then
  foxglove_bridge_capabilities="[clientPublish,parameters,parametersSubscribe,services,connectionGraph,assets]"
  foxglove_bridge_service_whitelist="['.*']"
else
  foxglove_bridge_capabilities="[clientPublish,parameters,parametersSubscribe,connectionGraph,assets]"
  foxglove_bridge_service_whitelist="['a^']"
fi

if [[ "${foxglove_bridge_enabled}" == "true" ]]; then
  echo "[start.sh] launching foxglove_bridge on $(docker_helper_target_describe) with websocket ${ros_bridge_host}:${ros_bridge_port}"
  launch_foxglove_bridge_runner

  wait_for_websocket "${ros_bridge_host}" "${ros_bridge_port}" "foxglove_bridge" "foxglove.websocket.v1"
else
  echo "[start.sh] foxglove_bridge disabled; aggregator ROS upstream disabled"
fi

if [[ "${visualize_enabled}" == "true" ]]; then
  echo "[start.sh] launching visualize_foxglove_server on ${custom_server_host}:${custom_server_port}"
  "${backend_python}" \
    "${APP_ROOT}/backend/visualize_foxglove_server/foxglove_sdk_server.py" \
    --config-path "${CONFIG_PATH}" \
    --host "${custom_server_host}" \
    --port "${custom_server_port}" \
    --control-host "${control_host}" \
    --control-port "${control_port}" \
    --zenoh-endpoint "${zenoh_endpoint}" &
  child_pids+=("$!")
  wait_for_websocket "${custom_server_host}" "${custom_server_port}" "visualize_foxglove_server" "foxglove.sdk.v1"
fi

echo "[start.sh] launching foxglove aggregator on ${aggregator_host}:${aggregator_port}"
"${backend_python}" \
  "${APP_ROOT}/backend/foxglove_aggregator/aggregator.py" \
  --config "${aggregator_config}" &
child_pids+=("$!")

wait_for_websocket "${aggregator_host}" "${aggregator_port}" "foxglove aggregator" "foxglove.websocket.v1"

echo "[start.sh] all services are running"
wait -n "${child_pids[@]}"
echo "[start.sh] one child process exited; stopping the service group"
exit 1
