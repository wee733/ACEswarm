(()=>{{let w=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};w.SENTRY_RELEASE={id:"fb43bec2fad41cce2dd69fd0796d3790244bbca8"}}(self.webpackChunk=self.webpackChunk||[]).push([[8258],{91400(w,m,g){g.d(m,{A:()=>u});var p=g(36191);function _(z,$){return(0,p.A)(z,$)}const u=_},96603(w,m,g){var p=g(21197),_=g(63986);function u(e,t){return e==null&&console.warn("bigint arrays are not supported in this environment"),(n,r,i)=>{if(e==null)throw new Error("bigint arrays are not supported in this environment");let s=r;const a=n.byteOffset+s,o=e.BYTES_PER_ELEMENT*i,f=n.byteLength-r;if(o<0||o>f)throw new RangeError(`Array(${t}) deserialization error: size ${o}, maxSize ${f}`);if(a%e.BYTES_PER_ELEMENT===0)return new e(n.buffer,a,i);if(i<10){const h=new e(i);for(let c=0;c<i;++c)h[c]=n[t](s,!0),s+=e.BYTES_PER_ELEMENT;return h}const d=new Uint8Array(o);return d.set(new Uint8Array(n.buffer,a,o)),new e(d.buffer,d.byteOffset,i)}}const z=new Map([["bool",1],["int8",1],["uint8",1],["int16",2],["uint16",2],["int32",4],["uint32",4],["int64",8],["uint64",8],["float32",4],["float64",8],["time",8],["duration",8]]),$={bool:(e,t)=>e.getUint8(t)!==0,int8:(e,t)=>e.getInt8(t),uint8:(e,t)=>e.getUint8(t),int16:(e,t)=>e.getInt16(t,!0),uint16:(e,t)=>e.getUint16(t,!0),int32:(e,t)=>e.getInt32(t,!0),uint32:(e,t)=>e.getUint32(t,!0),int64:(e,t)=>e.getBigInt64(t,!0),uint64:(e,t)=>e.getBigUint64(t,!0),float32:(e,t)=>e.getFloat32(t,!0),float64:(e,t)=>e.getFloat64(t,!0),time:(e,t)=>{const n=e.getUint32(t,!0),r=e.getUint32(t+4,!0);return{sec:n,nsec:r}},duration:(e,t)=>{const n=e.getInt32(t,!0),r=e.getInt32(t+4,!0);return{sec:n,nsec:r}},string:(e,t)=>{const n=e.getUint32(t,!0),r=e.byteOffset+t+4,i=e.byteLength-t;if(n<0||n>i)throw new RangeError(`String deserialization error: length ${n}, maxLength ${i}`);const s=new Uint8Array(e.buffer,r,n);return(0,_.A)(s)},boolArray:(e,t,n)=>{let r=t;const i=new Array(n);for(let s=0;s<n;++s)i[s]=$.bool(e,r),r+=1;return i},int8Array:u(Int8Array,"getInt8"),uint8Array:u(Uint8Array,"getUint8"),int16Array:u(Int16Array,"getInt16"),uint16Array:u(Uint16Array,"getUint16"),int32Array:u(Int32Array,"getInt32"),uint32Array:u(Uint32Array,"getUint32"),int64Array:u(typeof BigInt64Array=="function"?BigInt64Array:void 0,"getBigInt64"),uint64Array:u(typeof BigUint64Array=="function"?BigUint64Array:void 0,"getBigUint64"),float32Array:u(Float32Array,"getFloat32"),float64Array:u(Float64Array,"getFloat64"),timeArray:(e,t,n)=>{let r=t;const i=new Array(n),s=e.byteOffset+r;if(s%Int32Array.BYTES_PER_ELEMENT===0){const a=new Int32Array(e.buffer,s,n*2);for(let o=0,f=0;o<n;++o,f=f+2)i[o]={sec:a[f],nsec:a[f+1]}}else for(let a=0;a<n;++a)i[a]={sec:e.getInt32(r,!0),nsec:e.getInt32(r+4,!0)},r+=8;return i},durationArray:(e,t,n)=>$.timeArray(e,t,n),fixedArray:(e,t,n,r,i)=>{let s=t;const a=new Array(n);for(let o=0;o<n;++o)a[o]=r(e,s),s+=i(e,s);return a},dynamicArray:(e,t,n,r)=>{const i=e.getUint32(t,!0);return $.fixedArray(e,t+4,i,n,r)}},b={string:(e,t)=>{const n=e.getUint32(t,!0),r=e.byteLength-t-4;if(n<0||n>r)throw new RangeError(`String length error: length ${n}, maxLength ${r}`);return 4+n},fixedArray:(e,t,n,r)=>{let i=t,s=0;for(let o=0;o<n;++o){const f=r(e,i);s+=f,i+=f}const a=e.byteLength-t;if(s>a)throw new RangeError(`Fixed array length error: size ${s}, maxSize ${a}`);return s},array:(e,t,n)=>{let r=t;const i=e.getUint32(r,!0);let s=4;r+=4;for(let o=0;o<i;++o){const f=n(e,r);s+=f,r+=f}const a=e.byteLength-t;if(s>a)throw new RangeError(`Dynamic array length error: size ${s}, maxSize ${a}`);return s}};function l(e){return e.replace(/^[0-9]|[^a-zA-Z0-9_]/g,"_")}function A(e){if(e.isConstant===!0)return"";const t=fixedSizeTypes.get(e.type);if(t==null){const n=e.type==="string"?"builtinSizes.string":`${l(e.type)}.size`;return e.isArray===!0?e.arrayLength!=null?`
          static __${e.name}$size(view /* dataview */, offset) {
              return builtinSizes.fixedArray(view, offset, ${e.arrayLength}, ${n});
          }`:`
          static __${e.name}$size(view /* dataview */, offset) {
              return builtinSizes.array(view, offset, ${n});
          }`:`
      static __${e.name}$size(view /* dataview */, offset) {
          return ${n}(view, offset);
      }`}else return e.isArray===!0?e.arrayLength!=null?`
          static __${e.name}$size(view /* dataview */, offset) {
            return ${t} * ${e.arrayLength};
          }`:`
          static __${e.name}$size(view /* dataview */, offset) {
            const len = view.getUint32(offset, true);
            return 4 + len * ${t};
          }`:`
      static __${e.name}$size(view /* dataview */, offset) {
          return ${t};
      }`}function v(e,t){if(t.isConstant===!0)return"";const n=fixedSizeTypes.get(t.type),r=t.isArray===!0&&t.arrayLength!=null;if(n!=null&&(r||t.isArray===!1))if(t.arrayLength!=null){const i=n*t.arrayLength;return`
        // ${t.type}[${t.arrayLength}] ${t.name}
        totalSize += ${i};
        offset += ${i};
      `}else return`
        // ${t.type} ${t.name}
        totalSize += ${n};
        offset += ${n};
      `;return`
    // ${t.type} ${t.name}
    {
        const size = ${e}.__${t.name}$size(view, offset);
        totalSize += size;
        offset += size;
    }
    `}function S(e){if(e.isConstant===!0)return"";const t=e.type in deserializers,n=e.type in b,r=t?`deserializers.${e.type}`:`${l(e.type)}.build`,i=n?`builtinSizes.${e.type}`:`${l(e.type)}.size`,s=fixedSizeTypes.get(e.type);if(e.isArray===!0){const a=e.arrayLength;return a!=null?s!=null?`
          // ${e.type}[${a}] ${e.name}
          get ${e.name}() {
            const offset = this.__${e.name}$offset(this.#view, this.#offset);
            return deserializers.${e.type}Array(this.#view, offset, ${a});
          }`:`
        // ${e.type}[${a}] ${e.name}
          get ${e.name}() {
            const offset = this.__${e.name}$offset(this.#view, this.#offset);
            return deserializers.fixedArray(this.#view, offset, ${a}, ${r}, ${i});
          }`:s!=null?`
          // ${e.type}[] ${e.name}
          get ${e.name}() {
            const offset = this.__${e.name}$offset(this.#view, this.#offset);
            const len = this.#view.getUint32(offset, true);
            return deserializers.${e.type}Array(this.#view, offset + 4, len);
          }`:`
          // ${e.type}[] ${e.name}
          get ${e.name}() {
            const offset = this.__${e.name}$offset(this.#view, this.#offset);
            return deserializers.dynamicArray(this.#view, offset, ${r}, ${i});
          }`}else return`get ${e.name}() {
        const offset = this.__${e.name}$offset(this.#view, this.#offset);
        return ${r}(this.#view, offset);
      }`}function O(e){const t=new Array,n="__RootMsg";for(const o of e){const f=l(o.name??n),d=new Array,h=new Array;let c;for(const y of o.definitions)y.isConstant!==!0&&(c==null?d.push(`
          __${y.name}$offset(view, initOffset) {
            return initOffset;
          }`):(h.push(`#_${y.name}_offset_cache = undefined;`),d.push(`
          __${y.name}$offset(view, initOffset) {
            if (this.#_${y.name}_offset_cache) {
              return this.#_${y.name}_offset_cache;
            }
            const prevOffset = this.__${c.name}$offset(view, initOffset);
            const totalOffset = prevOffset + ${f}.__${c.name}$size(view, prevOffset);
            this.#_${y.name}_offset_cache = totalOffset;
            return totalOffset;
          }`)),c=y);const L=`class ${f} {
        ${o.definitions.map(A).join(`
`)}

        // return the total serialized size of the message in the view
        static size(view /* DataView */, initOffset = 0) {
          let totalSize = 0;
          let offset = initOffset;

          ${o.definitions.map(v.bind(void 0,f)).join(`
`)}

          return totalSize;
        }

        ${d.join(`
`)}

        // return an instance of ${f} from the view at initOffset bytes into the view
        // NOTE: the underlying view data lifetime must be at least the lifetime of the instance
        static build(view /* DataView */, offset = 0) {
          return new ${f}(view, offset);
        }

        #view = undefined;
        #offset;
        ${h.join(`
`)}
  
        constructor(view, offset = 0) {
          this.#view = view;
          this.#offset = offset;
        }

        // return a json object of the fields
        // This fully deserializes all fields of the message into native types
        // Typed arrays are considered native types and remain as typed arrays
        toJSON() {
          const view = this.#view;
          const buffer = new Uint8Array(view.buffer, view.byteOffset + this.#offset, view.byteLength - this.#offset);
          const reader = new StandardTypeReader(buffer);
          return new (typeReaders.get(${JSON.stringify(o.name??n)}))(reader);
        }

        // return a plain javascript object of the message
        // This fully deserializes all fields of the message into native types
        // Typed arrays are considered native types and remain as typed arrays
        toObject() {
          const view = this.#view;
          const buffer = new Uint8Array(view.buffer, view.byteOffset + this.#offset, view.byteLength - this.#offset);
          const reader = new StandardTypeReader(buffer);
          return new (typeReaders.get(${JSON.stringify(o.name??n)}))(reader);
        }

        ${o.definitions.map(S).join(`
`)}
    }`;t.push(L)}const r=t.reverse().join(`

`),i=createParsers({definitions:e,topLevelReaderKey:n}),s=new Function("deserializers","builtinSizes","typeReaders","StandardTypeReader",`${r}
return __RootMsg;`),a=s.call(void 0,deserializers,b,i,StandardTypeReader);return a.source=()=>s.toString(),a}function E(){const e=new Uint8Array(4),t=new Uint32Array(e.buffer);return t[0]=1,e[3]===1}if(!!E())throw new Error("Only Little Endian architectures are supported");class R{readerImpl;definitions;constructor(t){this.readerImpl=buildReader(t),this.definitions=t}size(t){const n=new DataView(t.buffer,t.byteOffset,t.byteLength);return this.readerImpl.size(n)}source(){return this.readerImpl.source()}readMessage(t){const n=new DataView(t.buffer,t.byteOffset,t.byteLength);return this.readerImpl.build(n)}}}}]);})();
