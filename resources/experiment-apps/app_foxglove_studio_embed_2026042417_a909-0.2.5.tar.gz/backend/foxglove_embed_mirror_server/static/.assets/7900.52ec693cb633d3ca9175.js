(()=>{{let D=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};D.SENTRY_RELEASE={id:"fb43bec2fad41cce2dd69fd0796d3790244bbca8"}}(()=>{"use strict";var D={57900(o,f,u){var A=u(25087),x=u(19549),T=u(88496),w=u(98727),P=u(91922);function I(e){return typeof e=="object"&&e!=null}function L(e,t="Unknown error"){return e instanceof Error?e:new Error(t)}function Me(e){return e!=null}var Pe=u(51261),ye=u(26893),We=u(47824),Z=u(80407),_e=u(75277),Be=u(69844),Ue=u(9832),De=u(82637),Le=u(6298),Ne=u(10993),M=u(7226),oe=u(46481);const me=1/32767;class Q{channels;#s=[];#i=0;#r=0;#e=0;#t;constructor(){this.channels=[],this.#a()}#n(t){const n=Math.max(t,this.#e*2),i=this.#r-this.#i,r=this.#s.map(a=>{const s=new Float32Array(n*2);return s.set(a.subarray(this.#i*2,this.#r*2)),s});this.#s=r,this.#e=n,this.#i=0,this.#r=i}#a(){if(this.#r-this.#i===0){this.channels=[];return}this.channels=this.#s.map(n=>n.subarray(this.#i*2,this.#r*2))}#l(t){if(this.isEmpty()||this.#t==null)return;const n=t-this.#t;let i=this.#i;for(;i<this.#r&&!(this.#s[0][i*2]>=n);)i++;if(this.#i=i,this.#i>=this.#r){this.clear();return}this.#a()}startTime(){if(this.channels.length===0||this.channels[0].length===0)return;const t=this.channels[0][0];return this.#t!=null&&t!=null?this.#t+t:void 0}endTime(){if(this.channels.length===0||this.channels[0].length===0)return;const n=this.channels[0].at(-2);return this.#t!=null&&n!=null?this.#t+n:void 0}isEmpty(){return this.#r===this.#i}clear(){this.#i=0,this.#r=0,this.#t=void 0,this.#a()}appendNewSamples(t){const n=t[0];if(n==null)return;this.#t==null&&(this.#t=(0,M.toSec)(n.timestamp));const i=this.#s.length>0?this.#s.length:n.number_of_channels;let r=0;for(const l of t){const m=Math.floor(l.data.length/2);r+=Math.floor(m/i)}if(r===0)return;const a=this.#r+r;for(a>this.#e&&this.#n(a);this.#s.length<i;)this.#s.push(new Float32Array(this.#e*2));let s=this.#r;for(const l of t){const h=(0,M.toSec)(l.timestamp)-this.#t,g=l.sample_rate,b=Math.floor(l.data.length/2),p=Math.floor(b/i),S=new DataView(l.data.buffer,l.data.byteOffset,l.data.byteLength);for(let E=0;E<p;E++){const v=s+E,F=h+E/g;for(let C=0;C<i;C++){const Y=(E*i+C)*2,W=S.getInt16(Y,!0)*me,_=v*2;this.#s[C][_]=F,this.#s[C][_+1]=W}}s+=p}this.#r=s,this.#a()}updateWithMessages(t){const n=this.startTime(),i=this.endTime();if(t.length===0)return!1;const r=(0,M.toSec)(t[0].timestamp),a=(0,M.toSec)(t.at(-1).timestamp);if(n==null||i==null)return this.clear(),this.appendNewSamples(t),!0;const s=r>n,l=a>i;let m=!1;if(s&&(this.#l(r),m=!0),l){const h=oe.A(t,g=>(0,M.toSec)(g.timestamp)>i);if(h!==-1){const g=t.slice(h);this.appendNewSamples(g),m=!0}}return(r<n||a<i&&!s)&&(this.clear(),this.appendNewSamples(t),m=!0),m}}const de=256,K=64,he=8,fe=32,pe=2048,ce=1.25;function xe(e,t){const n=Math.max(1,Math.min(e,t)),i=Math.max(1,Math.ceil(e/n));return{width:n,height:i}}function Ve(e,t){return{x:e%t,y:Math.floor(e/t)}}class Te{#s=[];#i=void 0;#r=new Q;#e=void 0;#t=void 0;#n=void 0;#a=[];#l=0;#o=!1;#u=!1;setCanvas(t){this.#i=t,this.#d()}setAudioMessages(t){t!==this.#s&&(this.#o=this.#r.updateWithMessages(t),this.#s=t)}async render(t){if(!this.#u||!this.#e||!this.#t||!this.#n)throw new Error("Can't render waveform: WebGL2 not initialized.");const n=this.#e,{width:i,height:r,backgroundColor:a,color:s,startTime:l,endTime:m}=t;if(i<=0||r<=0)return;this.#h(i,r);const h=this.#r.channels,g=h.length,b=te(a),p=te(s);if(g===0){this.#m(b);return}const S=this.#r.startTime(),E=this.#r.endTime();if(S==null||E==null){this.#m(b);return}const v=this.#f(h,l,m,S,E);if(!v){this.#m(b);return}const F=this.#p(h[0],i,v.timeRange),C=F!=null&&F<=ce,Y=this.#c(F),re=Math.floor((h[0]?.length??0)/2),W=this.#x(re,Y),_=C?this.#I(h[0],v.relativeMinTime,v.relativeMaxTime):void 0,ae=C&&_!=null&&_.count>1,se=this.#T(h,i,W),le=this.#o;if((le||se)&&(this.#g(h),this.#o=!1),!ae)for(let X=0;X<g;X++){const ue=h[X],z=this.#a[X];if(!ue||!z)continue;const $=Math.floor(ue.length/2);$!==0&&((le||se||z.binSize!==W)&&this.#b(z,$,W),this.#S(z,{width:i,sampleCount:$,relativeMinTime:v.relativeMinTime,relativeMaxTime:v.relativeMaxTime,timeRange:v.timeRange,binSize:W}))}O(n),n.viewport(0,0,i,r),n.disable(n.BLEND),n.clearColor(b.r,b.g,b.b,b.a),n.clear(n.COLOR_BUFFER_BIT),this.#v(i,r,g,p),ae?this.#C(i,r,g,v,_,p):this.#E(i,r,g,p)}dispose(){const t=this.#e;if(t){for(const n of this.#a)n&&(t.deleteTexture(n.sampleTexture),t.deleteTexture(n.downsampleTexture),t.deleteFramebuffer(n.downsampleFramebuffer),t.deleteTexture(n.binTexture),t.deleteFramebuffer(n.binFramebuffer));this.#t&&(t.deleteProgram(this.#t.downsampleProgram),t.deleteProgram(this.#t.binProgram),t.deleteProgram(this.#t.waveformProgram),t.deleteProgram(this.#t.sampleWaveformProgram),t.deleteProgram(this.#t.zeroLineProgram)),this.#n&&(t.deleteVertexArray(this.#n.fullscreenQuad.vao),t.deleteBuffer(this.#n.fullscreenQuad.vbo),t.deleteVertexArray(this.#n.emptyVertexArray))}this.#a=[],this.#l=0,this.#e=void 0,this.#t=void 0,this.#n=void 0,this.#i=void 0,this.#s=[],this.#r=new Q,this.#o=!1,this.#u=!1}#d(){if(!this.#i)return;const t=this.#i.getContext("webgl2",{alpha:!0,antialias:!1,depth:!1,stencil:!1,preserveDrawingBuffer:!1,powerPreference:"high-performance"});if(t==null){console.error("WebGL2 is not available in this environment."),this.#u=!1;return}if(t.getExtension("EXT_color_buffer_float")==null){console.error("WebGL2 float render targets are not available (missing EXT_color_buffer_float)."),this.#u=!1;return}const n=t.getParameter(t.MAX_TEXTURE_SIZE);if(!Number.isFinite(n)||n<=0){console.error("Unable to query MAX_TEXTURE_SIZE for WebGL2 audio renderer."),this.#u=!1;return}try{const i={downsampleProgram:B(t,ne,Ce),binProgram:B(t,ne,Ee),waveformProgram:B(t,Ie,k),sampleWaveformProgram:B(t,Re,k),zeroLineProgram:B(t,Ae,k)},r=ge(t),a=N(t.createVertexArray(),"empty vertex array");this.#e=t,this.#l=n,this.#t=i,this.#n={fullscreenQuad:r,emptyVertexArray:a},this.#u=!0}catch(i){console.error("Failed to initialize WebGL2 renderer:",L(i)),this.#u=!1}}#h(t,n){this.#i&&(this.#i.width!==t||this.#i.height!==n)&&(this.#i.width=t,this.#i.height=n)}#m(t){!this.#e||!this.#i||(O(this.#e),this.#e.viewport(0,0,this.#i.width,this.#i.height),this.#e.clearColor(t.r,t.g,t.b,t.a),this.#e.clear(this.#e.COLOR_BUFFER_BIT))}#f(t,n,i,r,a){if(t.length===0||t[0].length<2)return;const s=r-t[0][0],l=n?(0,M.toSec)(n):r,m=i?(0,M.toSec)(i):a;let h=m-l;return(!Number.isFinite(h)||h<=0)&&(h=1),{relativeMinTime:l-s,relativeMaxTime:m-s,timeRange:h}}#p(t,n,i){if(!t||t.length<4||n<=0||i<=0)return;const r=Math.floor(t.length/2);if(r<2)return;const a=t[0]??0,l=(t[t.length-2]??a)-a;if(!Number.isFinite(l)||l<=0)return;const h=(r-1)/l*i/n;if(!(!Number.isFinite(h)||h<=0))return h}#c(t){if(t==null)return de;if(t<=K)return K;const n=Math.ceil(t/he);return Math.min(Math.max(n,fe),pe)}#x(t,n){if(t<=0||this.#l<=0)return n;const i=Math.max(1,Math.ceil(t/this.#l));return Math.max(n,i)}#T(t,n,i){if(!this.#e||this.#l<=0)return!1;const r=this.#l;let a=!1;for(;this.#a.length>t.length;){const s=this.#a.pop();s&&(this.#e.deleteTexture(s.sampleTexture),this.#e.deleteTexture(s.downsampleTexture),this.#e.deleteFramebuffer(s.downsampleFramebuffer),this.#e.deleteTexture(s.binTexture),this.#e.deleteFramebuffer(s.binFramebuffer)),a=!0}for(let s=0;s<t.length;s++){const l=t[s];if(!l)continue;const m=Math.floor(l.length/2),h=Math.max(1,Math.ceil(m/Math.max(1,i))),{width:g,height:b}=xe(m,r);if(b>r){console.error(`Audio sample texture exceeds WebGL2 limits: sampleCount=${m}, maxTextureSize=${r}.`);const S=this.#a[s];S&&(this.#e.deleteTexture(S.sampleTexture),this.#e.deleteTexture(S.downsampleTexture),this.#e.deleteFramebuffer(S.downsampleFramebuffer),this.#e.deleteTexture(S.binTexture),this.#e.deleteFramebuffer(S.binFramebuffer),this.#a[s]=void 0,a=!0);continue}const p=this.#a[s];if(p?.sampleCount!==m||p.sampleTextureWidth!==g||p.sampleTextureHeight!==b||p.downsampleWidth!==n||p.binCount!==h||p.binSize!==i){p&&(this.#e.deleteTexture(p.sampleTexture),this.#e.deleteTexture(p.downsampleTexture),this.#e.deleteFramebuffer(p.downsampleFramebuffer),this.#e.deleteTexture(p.binTexture),this.#e.deleteFramebuffer(p.binFramebuffer));const S=be(this.#e,g,b),E=q(this.#e,Math.max(1,n),1),v=ee(this.#e,E),F=q(this.#e,h,1),C=ee(this.#e,F);this.#a[s]={sampleTexture:S,sampleTextureWidth:g,sampleTextureHeight:b,paddedSampleData:void 0,downsampleTexture:E,downsampleFramebuffer:v,binTexture:F,binFramebuffer:C,sampleCount:m,downsampleWidth:n,binCount:h,binSize:i},a=!0}}return a}#g(t){if(this.#e){for(let n=0;n<t.length;n++){const i=t[n],r=this.#a[n];if(!i||!r||r.sampleCount===0)continue;const a=r.sampleTextureWidth*r.sampleTextureHeight*2;let s=i;i.length!==a&&(r.paddedSampleData?.length!==a&&(r.paddedSampleData=new Float32Array(a)),r.paddedSampleData.fill(0),r.paddedSampleData.set(i),s=r.paddedSampleData),this.#e.bindTexture(this.#e.TEXTURE_2D,r.sampleTexture),this.#e.texImage2D(this.#e.TEXTURE_2D,0,this.#e.RG32F,r.sampleTextureWidth,r.sampleTextureHeight,0,this.#e.RG,this.#e.FLOAT,s)}G(this.#e)}}#b(t,n,i){if(!this.#e||!this.#t||!this.#n)return;this.#e.bindFramebuffer(this.#e.FRAMEBUFFER,t.binFramebuffer),this.#e.viewport(0,0,t.binCount,1);const r=this.#t.binProgram;this.#e.useProgram(r),U(this.#e,r,"uSamples",t.sampleTexture,0),R(this.#e,r,"uSampleCount",n),R(this.#e,r,"uSampleTextureWidth",t.sampleTextureWidth),R(this.#e,r,"uBinSize",i),this.#e.bindVertexArray(this.#n.fullscreenQuad.vao),this.#e.drawArrays(this.#e.TRIANGLES,0,6)}#S(t,n){if(!this.#e||!this.#t||!this.#n)return;this.#e.bindFramebuffer(this.#e.FRAMEBUFFER,t.downsampleFramebuffer),this.#e.viewport(0,0,t.downsampleWidth,1);const i=this.#t.downsampleProgram;this.#e.useProgram(i),U(this.#e,i,"uSamples",t.sampleTexture,0),U(this.#e,i,"uBins",t.binTexture,1),R(this.#e,i,"uWidth",n.width),R(this.#e,i,"uSampleCount",n.sampleCount),R(this.#e,i,"uSampleTextureWidth",t.sampleTextureWidth),R(this.#e,i,"uBinSize",n.binSize),c(this.#e,i,"uRelativeMinTime",n.relativeMinTime),c(this.#e,i,"uRelativeMaxTime",n.relativeMaxTime),c(this.#e,i,"uTimeRange",n.timeRange),this.#e.bindVertexArray(this.#n.fullscreenQuad.vao),this.#e.drawArrays(this.#e.TRIANGLES,0,6)}#v(t,n,i,r){if(!this.#e||!this.#t||!this.#n)return;const a=this.#t.zeroLineProgram;this.#e.useProgram(a),this.#e.bindVertexArray(this.#n.emptyVertexArray);for(let s=0;s<i;s++)c(this.#e,a,"uWidth",t),c(this.#e,a,"uHeight",n),c(this.#e,a,"uChannelCount",i),c(this.#e,a,"uChannelIndex",s),H(this.#e,a,"uColor",r.r,r.g,r.b,r.a),this.#e.drawArrays(this.#e.LINES,0,2)}#E(t,n,i,r){if(!this.#e||!this.#t||!this.#n)return;const a=this.#t.waveformProgram;this.#e.useProgram(a),this.#e.bindVertexArray(this.#n.emptyVertexArray);for(let s=0;s<i;s++){const l=this.#a[s];!l||l.downsampleWidth<=0||(U(this.#e,a,"uDownsampled",l.downsampleTexture,0),c(this.#e,a,"uWidth",t),c(this.#e,a,"uHeight",n),c(this.#e,a,"uChannelCount",i),c(this.#e,a,"uChannelIndex",s),H(this.#e,a,"uColor",r.r,r.g,r.b,r.a),this.#e.drawArrays(this.#e.LINE_STRIP,0,l.downsampleWidth*2))}}#C(t,n,i,r,a,s){if(!this.#e||!this.#t||!this.#n)return;const l=this.#t.sampleWaveformProgram;this.#e.useProgram(l),this.#e.bindVertexArray(this.#n.emptyVertexArray);for(let m=0;m<i;m++){const h=this.#a[m];!h||a.count<=1||(U(this.#e,l,"uSamples",h.sampleTexture,0),c(this.#e,l,"uWidth",t),c(this.#e,l,"uHeight",n),c(this.#e,l,"uChannelCount",i),c(this.#e,l,"uChannelIndex",m),c(this.#e,l,"uRelativeMinTime",r.relativeMinTime),c(this.#e,l,"uTimeRange",r.timeRange),R(this.#e,l,"uSampleTextureWidth",h.sampleTextureWidth),R(this.#e,l,"uStartIndex",a.startIndex),H(this.#e,l,"uColor",s.r,s.g,s.b,s.a),this.#e.drawArrays(this.#e.LINE_STRIP,0,a.count))}}#I(t,n,i){if(!t||t.length<4)return;const r=Math.floor(t.length/2);if(r<2)return;const a=this.#R(t,r,n),s=this.#A(t,r,i);if(s===0||a>=r||s<=a)return;const m=Math.min(s,r)-a;if(!(m<=1))return{startIndex:a,count:m}}#R(t,n,i){let r=0,a=n;for(;r<a;){const s=r+a>>>1;(t[s*2]??0)<i?r=s+1:a=s}return r}#A(t,n,i){let r=0,a=n;for(;r<a;){const s=r+a>>>1;(t[s*2]??0)<=i?r=s+1:a=s}return r}}function J(e,t,n){const i=e.createShader(t);if(!i)throw new Error("Failed to create shader");if(e.shaderSource(i,n),e.compileShader(i),e.getShaderParameter(i,e.COMPILE_STATUS)!==!0){const r=e.getShaderInfoLog(i)||"Unknown shader compile error";throw e.deleteShader(i),new Error(r)}return i}function N(e,t){if(e==null)throw new Error(`Failed to create ${t}`);return e}function B(e,t,n){const i=J(e,e.VERTEX_SHADER,t);let r;try{r=J(e,e.FRAGMENT_SHADER,n)}catch(s){throw e.deleteShader(i),s}let a;try{a=N(e.createProgram(),"program")}catch(s){throw e.deleteShader(i),e.deleteShader(r),s}if(e.attachShader(a,i),e.attachShader(a,r),e.linkProgram(a),e.deleteShader(i),e.deleteShader(r),e.getProgramParameter(a,e.LINK_STATUS)!==!0){const s=e.getProgramInfoLog(a)||"Unknown program link error";throw e.deleteProgram(a),new Error(s)}return a}function ge(e){const t=e.createVertexArray(),n=e.createBuffer();if(t==null||n==null)throw t!=null&&e.deleteVertexArray(t),n!=null&&e.deleteBuffer(n),new Error("Failed to create fullscreen quad resources");e.bindVertexArray(t),e.bindBuffer(e.ARRAY_BUFFER,n);const i=new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]);return e.bufferData(e.ARRAY_BUFFER,i,e.STATIC_DRAW),e.enableVertexAttribArray(0),e.vertexAttribPointer(0,2,e.FLOAT,!1,0,0),Se(e),ve(e),{vao:t,vbo:n}}function be(e,t,n){const i=N(e.createTexture(),"RG32F texture");return e.bindTexture(e.TEXTURE_2D,i),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texImage2D(e.TEXTURE_2D,0,e.RG32F,Math.max(1,t),Math.max(1,n),0,e.RG,e.FLOAT,null),G(e),i}function q(e,t,n){const i=N(e.createTexture(),"RGBA16F texture");return e.bindTexture(e.TEXTURE_2D,i),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.texImage2D(e.TEXTURE_2D,0,e.RGBA16F,Math.max(1,t),Math.max(1,n),0,e.RGBA,e.HALF_FLOAT,null),G(e),i}function ee(e,t){const n=e.createFramebuffer();if(e.bindFramebuffer(e.FRAMEBUFFER,n),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0),e.checkFramebufferStatus(e.FRAMEBUFFER)!==e.FRAMEBUFFER_COMPLETE)throw e.deleteFramebuffer(n),new Error("Failed to create complete framebuffer for texture target");return O(e),n}function U(e,t,n,i,r){e.activeTexture(e.TEXTURE0+r),e.bindTexture(e.TEXTURE_2D,i);const a=e.getUniformLocation(t,n);a!=null&&e.uniform1i(a,r)}function R(e,t,n,i){const r=e.getUniformLocation(t,n);r!=null&&e.uniform1i(r,i)}function c(e,t,n,i){const r=e.getUniformLocation(t,n);r!=null&&e.uniform1f(r,i)}function H(e,t,n,i,r,a,s){const l=e.getUniformLocation(t,n);l!=null&&e.uniform4f(l,i,r,a,s)}function te(e){const t=/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(e);if(t){const i=t[1],r=i.length===3?i.split("").map(m=>`${m}${m}`).join(""):i,a=Number.parseInt(r.slice(0,2),16),s=Number.parseInt(r.slice(2,4),16),l=Number.parseInt(r.slice(4,6),16);return{r:a/255,g:s/255,b:l/255,a:1}}const n=/^rgba?\((.+)\)$/i.exec(e);if(n){const i=n[1];if(i.includes(",")){const r=i.split(",").map(a=>a.trim());if(r.length>=3){const[a,s,l]=r,m=r.length>=4?Number.parseFloat(r[3]):1;return{r:y(a),g:y(s),b:y(l),a:Number.isFinite(m)?m:1}}}else{const r=i.split("/"),a=r[0].trim(),s=r[1]?.trim(),l=a.split(/\s+/);if(l.length>=3){const m=s?Number.parseFloat(s):1;return{r:y(l[0]),g:y(l[1]),b:y(l[2]),a:Number.isFinite(m)?m:1}}}}return console.warn(`Unable to parse color "${e}", falling back to white.`),{r:1,g:1,b:1,a:1}}function O(e){e.bindFramebuffer(e.FRAMEBUFFER,null)}function G(e){e.bindTexture(e.TEXTURE_2D,null)}function Se(e){e.bindBuffer(e.ARRAY_BUFFER,null)}function ve(e){e.bindVertexArray(null)}function y(e){const t=e.trim();if(t.endsWith("%")){const i=Number.parseFloat(t.slice(0,-1));return Number.isFinite(i)?ie(i/100):0}const n=Number.parseFloat(t);return Number.isFinite(n)?ie(n/255):0}function ie(e){return Number.isFinite(e)?Math.min(1,Math.max(0,e)):0}const ne=`#version 300 es
layout(location = 0) in vec2 aPosition;
out vec2 vUv;

void main() {
  vUv = aPosition * 0.5 + 0.5;
  gl_Position = vec4(aPosition, 0.0, 1.0);
}
`,Ee=`#version 300 es
precision highp float;
precision highp int;

uniform sampler2D uSamples;
uniform int uSampleCount;
uniform int uSampleTextureWidth;
uniform int uBinSize;

layout(location = 0) out vec4 outMinMax;

vec2 fetchSample(int sampleIndex) {
  int x = sampleIndex % uSampleTextureWidth;
  int y = sampleIndex / uSampleTextureWidth;
  return texelFetch(uSamples, ivec2(x, y), 0).rg;
}

void main() {
  int binIndex = int(floor(gl_FragCoord.x));
  if (uSampleCount <= 0 || uBinSize <= 0) {
    outMinMax = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  int startIndex = binIndex * uBinSize;
  if (startIndex >= uSampleCount) {
    outMinMax = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  int endIndex = min(startIndex + uBinSize - 1, uSampleCount - 1);
  float minimumAmplitude = 1.0;
  float maximumAmplitude = -1.0;

  for (int sampleIndex = startIndex; sampleIndex <= endIndex; sampleIndex++) {
    float amplitude = fetchSample(sampleIndex).y;
    minimumAmplitude = min(minimumAmplitude, amplitude);
    maximumAmplitude = max(maximumAmplitude, amplitude);
  }

  outMinMax = vec4(minimumAmplitude, maximumAmplitude, 0.0, 1.0);
}
`,Ce=`#version 300 es
precision highp float;
precision highp int;

uniform sampler2D uSamples;
uniform sampler2D uBins;
uniform int uWidth;
uniform int uSampleCount;
uniform int uSampleTextureWidth;
uniform float uRelativeMinTime;
uniform float uRelativeMaxTime;
uniform float uTimeRange;
uniform int uBinSize;

layout(location = 0) out vec4 outMinMax;

vec2 fetchSample(int sampleIndex) {
  int x = sampleIndex % uSampleTextureWidth;
  int y = sampleIndex / uSampleTextureWidth;
  return texelFetch(uSamples, ivec2(x, y), 0).rg;
}

int lowerBound(float searchValue, int sampleCount) {
  int low = 0;
  int high = sampleCount;
  while (low < high) {
    int mid = (low + high) / 2;
    float midValue = fetchSample(mid).x;
    if (midValue < searchValue) {
      low = mid + 1;
    } else {
      high = mid;
    }
  }
  return low;
}

int upperBound(float searchValue, int sampleCount) {
  int low = 0;
  int high = sampleCount;
  while (low < high) {
    int mid = (low + high) / 2;
    float midValue = fetchSample(mid).x;
    if (midValue <= searchValue) {
      low = mid + 1;
    } else {
      high = mid;
    }
  }
  return low;
}

void main() {
  int pixelIndex = int(floor(gl_FragCoord.x));
  if (pixelIndex >= uWidth || uSampleCount == 0 || uTimeRange <= 0.0 || uBinSize <= 0) {
    outMinMax = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  float pixelStartTime = uRelativeMinTime + (float(pixelIndex) / float(uWidth)) * uTimeRange;
  float pixelEndTime = uRelativeMinTime + (float(pixelIndex + 1) / float(uWidth)) * uTimeRange;

  int startIndex = lowerBound(pixelStartTime, uSampleCount);
  int endExclusive = upperBound(pixelEndTime, uSampleCount);

  if (endExclusive == 0) {
    outMinMax = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  int endIndex = endExclusive - 1;
  if (startIndex >= uSampleCount || endIndex < startIndex) {
    outMinMax = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  int samplesPerPixel = endIndex - startIndex + 1;
  float minimumAmplitude = 1.0;
  float maximumAmplitude = -1.0;

  if (samplesPerPixel <= uBinSize * 2) {
    for (int sampleIndex = startIndex; sampleIndex <= endIndex; sampleIndex++) {
      float amplitude = fetchSample(sampleIndex).y;
      minimumAmplitude = min(minimumAmplitude, amplitude);
      maximumAmplitude = max(maximumAmplitude, amplitude);
    }
  } else {
    int binCount = (uSampleCount + uBinSize - 1) / uBinSize;
    int binStart = min(startIndex / uBinSize, max(0, binCount - 1));
    int binEnd = min(endIndex / uBinSize, max(0, binCount - 1));

    int startBinEndIndex = min(endIndex, (binStart + 1) * uBinSize - 1);
    for (int sampleIndex = startIndex; sampleIndex <= startBinEndIndex; sampleIndex++) {
      float amplitude = fetchSample(sampleIndex).y;
      minimumAmplitude = min(minimumAmplitude, amplitude);
      maximumAmplitude = max(maximumAmplitude, amplitude);
    }

    if (binStart + 1 <= binEnd - 1) {
      for (int binIndex = binStart + 1; binIndex <= binEnd - 1; binIndex++) {
        vec2 amplitudePair = texelFetch(uBins, ivec2(binIndex, 0), 0).rg;
        minimumAmplitude = min(minimumAmplitude, amplitudePair.x);
        maximumAmplitude = max(maximumAmplitude, amplitudePair.y);
      }
    }

    int endBinStartIndex = max(startIndex, binEnd * uBinSize);
    for (int sampleIndex = endBinStartIndex; sampleIndex <= endIndex; sampleIndex++) {
      float amplitude = fetchSample(sampleIndex).y;
      minimumAmplitude = min(minimumAmplitude, amplitude);
      maximumAmplitude = max(maximumAmplitude, amplitude);
    }
  }

  outMinMax = vec4(minimumAmplitude, maximumAmplitude, 0.0, 1.0);
}
`,Ie=`#version 300 es
precision highp float;
precision highp int;

uniform sampler2D uDownsampled;
uniform float uWidth;
uniform float uHeight;
uniform float uChannelCount;
uniform float uChannelIndex;
uniform vec4 uColor;

out vec4 vColor;

void main() {
  int vertexIndex = gl_VertexID;
  int pixelIndex = vertexIndex / 2;
  bool isMaxVertex = (vertexIndex % 2) == 1;

  vec2 amplitudePair = texelFetch(uDownsampled, ivec2(pixelIndex, 0), 0).rg;
  float amplitude = isMaxVertex ? amplitudePair.y : amplitudePair.x;

  float channelHeight = uHeight / uChannelCount;
  float channelCenterY = (uChannelIndex + 0.5) * channelHeight;
  float yPixels = channelCenterY - amplitude * (channelHeight * 0.5);
  float xPixels = float(pixelIndex) + 0.5;

  float xClip = (xPixels / uWidth) * 2.0 - 1.0;
  float yClip = 1.0 - (yPixels / uHeight) * 2.0;

  gl_Position = vec4(xClip, yClip, 0.0, 1.0);
  vColor = uColor;
}
`,Re=`#version 300 es
precision highp float;
precision highp int;

uniform sampler2D uSamples;
uniform float uWidth;
uniform float uHeight;
uniform float uChannelCount;
uniform float uChannelIndex;
uniform float uRelativeMinTime;
uniform float uTimeRange;
uniform int uSampleTextureWidth;
uniform int uStartIndex;
uniform vec4 uColor;

out vec4 vColor;

vec2 fetchSample(int sampleIndex) {
  int x = sampleIndex % uSampleTextureWidth;
  int y = sampleIndex / uSampleTextureWidth;
  return texelFetch(uSamples, ivec2(x, y), 0).rg;
}

void main() {
  int sampleIndex = uStartIndex + gl_VertexID;
  vec2 sampleData = fetchSample(sampleIndex);

  float normalizedX = clamp((sampleData.x - uRelativeMinTime) / uTimeRange, 0.0, 1.0);
  float xPixels = normalizedX * uWidth;

  float channelHeight = uHeight / uChannelCount;
  float channelCenterY = (uChannelIndex + 0.5) * channelHeight;
  float yPixels = channelCenterY - sampleData.y * (channelHeight * 0.5);

  float xClip = (xPixels / uWidth) * 2.0 - 1.0;
  float yClip = 1.0 - (yPixels / uHeight) * 2.0;

  gl_Position = vec4(xClip, yClip, 0.0, 1.0);
  vColor = uColor;
}
`,Ae=`#version 300 es
precision highp float;
precision highp int;

uniform float uWidth;
uniform float uHeight;
uniform float uChannelCount;
uniform float uChannelIndex;
uniform vec4 uColor;

out vec4 vColor;

void main() {
  float channelHeight = uHeight / uChannelCount;
  float channelCenterY = (uChannelIndex + 0.5) * channelHeight;

  float xPixels = gl_VertexID == 0 ? 0.0 : uWidth;
  float yPixels = channelCenterY;

  float xClip = (xPixels / uWidth) * 2.0 - 1.0;
  float yClip = 1.0 - (yPixels / uHeight) * 2.0;

  gl_Position = vec4(xClip, yClip, 0.0, 1.0);
  vColor = uColor;
}
`,k=`#version 300 es
precision highp float;
in vec4 vColor;
out vec4 outColor;

void main() {
  outColor = vColor;
}
`,V=new Te,we={setCanvas:e=>{V.setCanvas(e)},setAudioMessages:e=>{V.setAudioMessages(e)},render:async e=>{await V.render(e)},[A.Pk]:()=>{V.dispose()}};A.p(we)}},j={};function d(o){var f=j[o];if(f!==void 0)return f.exports;var u=j[o]={exports:{}};return D[o].call(u.exports,u,u.exports,d),u.exports}d.m=D,d.x=()=>{var o=d.O(void 0,[5864,2181,8115,3165,9507,4654,407],()=>d(57900));return o=d.O(o),o},(()=>{var o=[];d.O=(f,u,A,x)=>{if(u){x=x||0;for(var T=o.length;T>0&&o[T-1][2]>x;T--)o[T]=o[T-1];o[T]=[u,A,x];return}for(var w=1/0,T=0;T<o.length;T++){for(var[u,A,x]=o[T],P=!0,I=0;I<u.length;I++)(x&!1||w>=x)&&Object.keys(d.O).every(Z=>d.O[Z](u[I]))?u.splice(I--,1):(P=!1,x<w&&(w=x));if(P){o.splice(T--,1);var L=A();L!==void 0&&(f=L)}}return f}})(),d.n=o=>{var f=o&&o.__esModule?()=>o.default:()=>o;return d.d(f,{a:f}),f},d.d=(o,f)=>{for(var u in f)d.o(f,u)&&!d.o(o,u)&&Object.defineProperty(o,u,{enumerable:!0,get:f[u]})},d.f={},d.e=o=>Promise.all(Object.keys(d.f).reduce((f,u)=>(d.f[u](o,f),f),[])),d.u=o=>""+o+"."+{407:"bfc7fb9c76c0510cd8df",2181:"ae1a46a34390edeec761",3165:"101399ed062808d286ee",4654:"33753103b5625a3d4aa1",5864:"db0e0a57bb08fe3f5e5e",8115:"8a98a344b6f6e336ff9e",9507:"b5319a8489a307619640"}[o]+".js",d.g=(function(){if(typeof globalThis=="object")return globalThis;try{return this||new Function("return this")()}catch{if(typeof window=="object")return window}})(),d.o=(o,f)=>Object.prototype.hasOwnProperty.call(o,f),d.p=(function(){var s=typeof document<"u"&&document.currentScript;var b=(s&&s.src)||(typeof self<"u"&&self.location&&self.location.href)||"";return new URL("./",b).href;})()/*__FOXGLOVE_PUBLICPATH_PATCHED__*/,(()=>{var o={7900:1},f=x=>{var[T,w,P]=x;for(var I in w)d.o(w,I)&&(d.m[I]=w[I]);for(P&&P(d);T.length;)o[T.pop()]=1;A(x)};d.f.i=(x,T)=>{o[x]||importScripts(d.p+d.u(x))};var u=self.webpackChunk=self.webpackChunk||[],A=u.push.bind(u);u.push=f})(),(()=>{var o=d.x;d.x=()=>Promise.all([5864,2181,8115,3165,9507,4654,407].map(d.e,d)).then(o)})();var Fe=d.x()})();})();
