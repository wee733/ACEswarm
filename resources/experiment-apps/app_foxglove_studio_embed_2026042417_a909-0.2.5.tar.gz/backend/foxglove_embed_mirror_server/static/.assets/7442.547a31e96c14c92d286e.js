(()=>{{let i=typeof window<"u"?window:typeof global<"u"?global:typeof globalThis<"u"?globalThis:typeof self<"u"?self:{};i.SENTRY_RELEASE={id:"fb43bec2fad41cce2dd69fd0796d3790244bbca8"}}(self.webpackChunk=self.webpackChunk||[]).push([[7442],{3802(){},39502(){},57467(){},58324(){},75432(){},79029(){},80219(i,f,n){"use strict";n.d(f,{G:()=>pn});var m=n(3342),u=n(31551),p=n(25342),b=n(16157),h=n(30252),y=n(34447),g=n(63648),w=n(91411),v=n(23514),x=n(89831),R=n(53630),T=n(82091),z=n(24248),P=n(70249),A=n(70330),U=n(74487),M=n(63671),E=n(6898),I=n(44577),H=n(15514),D=n(97726),F=n(67424),C=n(96687),j=n(61508),B=n(39716),S=n(89042),N=n(99455),Y=n(44560),O=n(92749),L=n(32599),V=n(17418),G=n(84689),k=n(30960),$=n(35049),Q=n(77431),X=n(13416),Z=n(10647),W=n(88927),J=n(67855),K=n(43716),_=n(36612),q=n(43778),nn=n(62020),en=n(42433),l=n(71278),tn=n(9790),sn=n(90371),an=n(15683),rn=n(66961),on=n(23965),ln=n(92811);const r="lib.d.ts",cn=`
  declare type BaseTypes<T> = number | string | boolean | void | null | T;
  declare type LogArgs = { [key: string]: BaseTypes<LogArgs> | BaseTypes<LogArgs>[] };
  declare var log: (...args: Array<BaseTypes<LogArgs> | BaseTypes<LogArgs>[]>) => void;
`,c=new Map(Object.entries({es5:ln,es2015:h,es2016:P,es2017:A,es2018:C,es2019:Y,es2020:k,es2021:J,es2022:l,"es2015.core":b,"es2015.collection":p,"es2015.iterable":g,"es2015.generator":y,"es2015.promise":w,"es2015.proxy":v,"es2015.reflect":x,"es2015.symbol":R,"es2015.symbol.wellknown":T,"es2016.array.include":z,"es2017.object":M,"es2017.sharedmemory":E,"es2017.string":I,"es2017.intl":U,"es2017.typedarrays":H,"es2018.asynciterable":F,"es2018.asyncgenerator":D,"es2018.promise":B,"es2018.regexp":S,"es2018.intl":j,"es2019.array":N,"es2019.object":O,"es2019.string":L,"es2019.symbol":V,"es2020.bigint":G,"es2020.promise":Q,"es2020.sharedmemory":X,"es2020.string":Z,"es2020.symbol.wellknown":W,"es2020.intl":$,"es2021.intl":K,"es2021.promise":_,"es2021.string":q,"es2021.weakref":nn,"es2022.array":en,"es2022.error":tn,"es2022.intl":sn,"es2022.object":an,"es2022.regexp":rn,"es2022.string":on}));function d(s){return s.replace(/\/\/\/ <reference lib="(.+)" \/>/g,(a,e)=>{const t=c.get(e);return c.delete(e),t==null?"":d(t)})}const dn=`${d(l)}

${cn}`,fn=[{fileName:"pointClouds.ts",sourceCode:`import type { FieldReader } from "./readers.ts";
import { getReader } from "./readers.ts";
import type { Point, Header, RGBA } from "./types.ts";

interface sensor_msgs__PointField {
  name: string;
  offset: number;
  datatype: number;
  count: number;
}

export interface sensor_msgs__PointCloud2 {
  header: Header;
  height: number;
  width: number;
  fields: sensor_msgs__PointField[];
  is_bigendian: boolean;
  point_step: number;
  row_step: number;
  data: Uint8Array;
  is_dense: boolean;
}

type Reader = { datatype: number; offset: number; reader: FieldReader };

function getFieldOffsetsAndReaders(fields: sensor_msgs__PointField[]): Reader[] {
  const result: Reader[] = [];
  for (const { datatype, offset = 0 } of fields) {
    result.push({ datatype, offset, reader: getReader(datatype, offset) });
  }
  return result;
}

type Field = number | string;

/**
 * Read points from a sensor_msgs.PointCloud2 message. Returns a nested array
 * of values whose index corresponds to that of the 'fields' value.
 */
export const readPoints = (message: sensor_msgs__PointCloud2): Array<Field[]> => {
  const { fields, height, point_step, row_step, width, data } = message;
  const readers = getFieldOffsetsAndReaders(fields);

  const points: Array<Field[]> = [];
  for (let i = 0; i < height; i++) {
    const dataOffset = i * row_step;
    for (let j = 0; j < width; j++) {
      const row: Field[] = [];
      const dataStart = j * point_step + dataOffset;
      for (const reader of readers) {
        const value = reader.reader.read(data, dataStart);
        row.push(value);
      }
      points.push(row);
    }
  }
  return points;
};

export function norm({ x, y, z }: Point): number {
  return Math.sqrt(x * x + y * y + z * z);
}

export function setRayDistance(pt: Point, distance: number): Point {
  const { x, y, z } = pt;
  const scale = distance / norm(pt);
  return {
    x: x * scale,
    y: y * scale,
    z: z * scale,
  };
}

// eslint-disable-next-line @foxglove/no-boolean-parameters
export function convertToRangeView(points: Point[], range: number, makeColors: boolean): RGBA[] {
  const colors: RGBA[] = makeColors ? new Array(points.length) : [];
  // First pass to get min and max ranges
  let maxRange = Number.MIN_VALUE;
  if (makeColors) {
    for (const point of points) {
      maxRange = Math.max(maxRange, norm(point));
    }
  }
  // actually move the points and generate colors if specified
  for (let i = 0; i < points.length; ++i) {
    const pt = points[i]!;
    if (makeColors) {
      const dist = norm(pt);
      if (dist <= range) {
        // don't go all the way to white
        const extent = 0.8;
        // closest to target range is lightest,
        // closest to AV is darkest
        const other = (extent * dist) / range;
        colors[i] = { r: 1, g: other, b: other, a: 1 };
      } else {
        // don't go all the way to white
        const extent = 0.8;
        // closest to target range is lightest,
        // closest to max range is darkest
        const upper = maxRange - range;
        const other = extent * (1.0 - dist / upper);
        colors[i] = { r: other, g: other, b: 1, a: 1 };
      }
    }
    points[i] = setRayDistance(pt, range);
  }
  return colors;
}
`},{fileName:"quaternions.ts",sourceCode:`export type Quaternion = {
  x: number;
  y: number;
  z: number;
  w: number;
};

export type Euler = {
  roll: number;
  pitch: number;
  yaw: number;
};

/**
 * Converts roll, pitch, and yaw Euler angles in degrees to a quaternion.
 * Uses the standard roll/pitch/yaw convention with rotations applied in XYZ order.
 *
 * @param euler Input Euler angle roll, pitch, yaw representation, in degrees.
 * @returns Converted quaternion.
 */
export function eulerToQuaternion(euler: Euler): Quaternion {
  const { roll, pitch, yaw } = euler;

  const toRadians = Math.PI / 180;
  const halfRollRadians = (roll * toRadians) / 2;
  const halfPitchRadians = (pitch * toRadians) / 2;
  const halfYawRadians = (yaw * toRadians) / 2;

  const sinHalfRoll = Math.sin(halfRollRadians);
  const cosHalfRoll = Math.cos(halfRollRadians);
  const sinHalfPitch = Math.sin(halfPitchRadians);
  const cosHalfPitch = Math.cos(halfPitchRadians);
  const sinHalfYaw = Math.sin(halfYawRadians);
  const cosHalfYaw = Math.cos(halfYawRadians);

  return {
    x: sinHalfRoll * cosHalfPitch * cosHalfYaw - cosHalfRoll * sinHalfPitch * sinHalfYaw,
    y: cosHalfRoll * sinHalfPitch * cosHalfYaw + sinHalfRoll * cosHalfPitch * sinHalfYaw,
    z: cosHalfRoll * cosHalfPitch * sinHalfYaw - sinHalfRoll * sinHalfPitch * cosHalfYaw,
    w: cosHalfRoll * cosHalfPitch * cosHalfYaw + sinHalfRoll * sinHalfPitch * sinHalfYaw,
  };
}

/**
 * Converts a quaternion to an Euler roll, pitch, yaw representation, in degrees.
 * Uses the standard roll/pitch/yaw convention with rotations applied in XYZ order.
 *
 * @param quaternion Input quaternion.
 * @returns Converted Euler angle roll, pitch, yaw representation, in degrees.
 */
export function quaternionToEuler(quaternion: Quaternion): Euler {
  const { x, y, z, w } = quaternion;

  const toDegrees = 180 / Math.PI;
  const dcm00 = w * w + x * x - y * y - z * z;
  const dcm10 = 2 * (x * y + w * z);
  const dcm20 = 2 * (x * z - w * y);
  const dcm21 = 2 * (w * x + y * z);
  const dcm22 = w * w - x * x - y * y + z * z;
  const roll = toDegrees * Math.atan2(dcm21, dcm22);
  const pitch = toDegrees * Math.asin(-dcm20);
  const yaw = toDegrees * Math.atan2(dcm10, dcm00);
  return {
    roll,
    pitch,
    yaw,
  };
}
`},{fileName:"readers.ts",sourceCode:`// https://docs.ros2.org/foxy/api/sensor_msgs/msg/PointField.html
export const DATATYPE = {
  int8: 1,
  uint8: 2,
  int16: 3,
  uint16: 4,
  int32: 5,
  uint32: 6,
  float32: 7,
  float64: 8,
};

export interface FieldReader {
  read(data: Uint8Array, index: number): number;
}

export class Float32Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(4);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 4;
    if (data.length < base + size) {
      throw new Error("cannot read Float32 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    this.#view.setUint8(2, data[base + 2]!);
    this.#view.setUint8(3, data[base + 3]!);
    return this.#view.getFloat32(0, true);
  }
}

export class Float64Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(8);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 8;
    if (data.length < base + size) {
      throw new Error("cannot read Float64 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    this.#view.setUint8(2, data[base + 2]!);
    this.#view.setUint8(3, data[base + 3]!);
    this.#view.setUint8(4, data[base + 4]!);
    this.#view.setUint8(5, data[base + 5]!);
    this.#view.setUint8(6, data[base + 6]!);
    this.#view.setUint8(7, data[base + 7]!);
    return this.#view.getFloat64(0, true);
  }
}

export class Int8Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(1);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 1;
    if (data.length < base + size) {
      throw new Error("cannot read Int8 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    return this.#view.getInt8(0);
  }
}

export class Int32Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(4);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 4;
    if (data.length < base + size) {
      throw new Error("cannot read Int32 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    this.#view.setUint8(2, data[base + 2]!);
    this.#view.setUint8(3, data[base + 3]!);
    return this.#view.getInt32(0, true);
  }
}

export class Uint32Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(4);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 4;
    if (data.length < base + size) {
      throw new Error("cannot read Uint32 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    this.#view.setUint8(2, data[base + 2]!);
    this.#view.setUint8(3, data[base + 3]!);
    return this.#view.getUint32(0, true);
  }
}

export class Uint16Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(2);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 2;
    if (data.length < base + size) {
      throw new Error("cannot read Uint16 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    return this.#view.getUint16(0, true);
  }
}

export class Uint8Reader implements FieldReader {
  #offset: number;
  public constructor(offset: number) {
    this.#offset = offset;
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 1;
    if (data.length < base + size) {
      throw new Error("cannot read Uint8 from data - not enough data");
    }
    return data[base]!;
  }
}

export class Int16Reader implements FieldReader {
  #offset: number;
  #view: DataView;
  public constructor(offset: number) {
    this.#offset = offset;
    const buffer = new ArrayBuffer(2);
    this.#view = new DataView(buffer);
  }

  public read(data: Uint8Array, index: number): number {
    const base = index + this.#offset;
    const size = 2;
    if (data.length < base + size) {
      throw new Error("cannot read Int16 from data - not enough data");
    }
    this.#view.setUint8(0, data[base]!);
    this.#view.setUint8(1, data[base + 1]!);
    return this.#view.getInt16(0, true);
  }
}

export function getReader(datatype: number, offset: number): FieldReader {
  switch (datatype) {
    case DATATYPE.int8:
      return new Int8Reader(offset);
    case DATATYPE.uint8:
      return new Uint8Reader(offset);
    case DATATYPE.int16:
      return new Int16Reader(offset);
    case DATATYPE.uint16:
      return new Uint16Reader(offset);
    case DATATYPE.int32:
      return new Int32Reader(offset);
    case DATATYPE.uint32:
      return new Uint32Reader(offset);
    case DATATYPE.float32:
      return new Float32Reader(offset);
    case DATATYPE.float64:
      return new Float64Reader(offset);
    default:
      throw new Error(\`Unsupported datatype: '\${datatype}'\`);
  }
}
`},{fileName:"time.ts",sourceCode:`import type { Time } from "./types.ts";

/**
 * Checks ROS-time equality.
 */
export const areSame = (t1: Time, t2: Time): boolean => t1.sec === t2.sec && t1.nsec === t2.nsec;

/**
 * Compare two times, returning a negative value if the right is greater or a
 * positive value if the left is greater or 0 if the times are equal useful to
 * supply to Array.prototype.sort
 */
export const compare = (left: Time, right: Time): number => {
  const secDiff = left.sec - right.sec;
  return secDiff !== 0 ? secDiff : left.nsec - right.nsec;
};

const fixTime = (t: Time): Time => {
  // Equivalent to fromNanoSec(toNanoSec(t)), but no chance of precision loss.
  // nsec should be non-negative, and less than 1e9.
  let { sec, nsec } = t;
  while (nsec > 1e9) {
    nsec -= 1e9;
    sec += 1;
  }
  while (nsec < 0) {
    nsec += 1e9;
    sec -= 1;
  }
  return { sec, nsec };
};

export const subtractTimes = (
  { sec: sec1, nsec: nsec1 }: Time,
  { sec: sec2, nsec: nsec2 }: Time,
): Time => {
  return fixTime({ sec: sec1 - sec2, nsec: nsec1 - nsec2 });
};
`},{fileName:"types.ts",sourceCode:`import type { MessageTypeByTopic, MessageTypeBySchemaName } from "./generatedTypes.ts";

/**
 * Message is a generic type for getting the type of a message for a schema name.
 *
 * \`\`\`
 * type GeometryPose = Message<"geometry_msgs/Pose">;
 * type PkgGeometryPose = Message<"pkg.geometry.Pose">;
 * \`\`\`
 */
export type Message<T extends keyof MessageTypeBySchemaName> = MessageTypeBySchemaName[T];

/**
 * Input type is a generic type for getting the event type on a topic.
 *
 * Most commonly used to type the input argument to your process function.
 *
 * \`\`\`
 * function process(msgEvent: Input<"/points">) { ... }
 * \`\`\`
 */
export type Input<T extends keyof MessageTypeByTopic> = {
  topic: T;
  receiveTime: Time;
  publishTime?: Time;
  message: MessageTypeByTopic[T];
};

export type RGBA = {
  // all values are scaled between 0-1 instead of 0-255
  r: number;
  g: number;
  b: number;
  a: number; // opacity -- typically you should set this to 1.
};

export type Header = {
  frame_id: string;
  stamp: Time;
  seq: number;
};

export type Point = {
  x: number;
  y: number;
  z: number;
};

export type Time = {
  sec: number;
  nsec: number;
};

export type Translation = {
  x: number;
  y: number;
  z: number;
};

export type Rotation = {
  x: number;
  y: number;
  z: number;
  w: number;
};

export type Pose = {
  position: Point;
  orientation: Quaternion;
};

export type Quaternion = {
  x: number;
  y: number;
  z: number;
  w: number;
};

export type Transform = {
  header: Header;
  child_frame_id: string;
  transform: {
    translation: Translation;
    rotation: Rotation;
  };
};
`},{fileName:"vectors.ts",sourceCode:`import type { Point, Rotation } from "./types.ts";

type vec3 = [number, number, number];

/**
 * Dot-product of two vectors.
 */
export function dot(vec1: number[], vec2: number[]): number {
  let ret = 0.0;
  for (let i = 0; i < vec1.length && i < vec2.length; ++i) {
    ret += vec1[i]! * vec2[i]!;
  }
  return ret;
}

/**
 * Cross-product of two vectors.
 */
export function cross(vec1: vec3, vec2: vec3): vec3 {
  const [ax, ay, az] = vec1;
  const [bx, by, bz] = vec2;
  return [ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx];
}

/**
 * Performs a rotation transformation on a point.
 */
export function rotate(rotation: Rotation, point: Point): Point {
  // Adapted from https://github.com/mrdoob/three.js/blob/8343b4b85ad73f74098dd568633d300e5aee993a/src/math/Vector3.js#L252

  // quaternion q is assumed to have unit length

  const vx = point.x;
  const vy = point.y;
  const vz = point.z;
  const qx = rotation.x;
  const qy = rotation.y;
  const qz = rotation.z;
  const qw = rotation.w;

  // t = 2 * cross( q.xyz, v );
  const tx = 2 * (qy * vz - qz * vy);
  const ty = 2 * (qz * vx - qx * vz);
  const tz = 2 * (qx * vy - qy * vx);

  // v + q.w * t + cross( q.xyz, t );
  const x = vx + qw * tx + qy * tz - qz * ty;
  const y = vy + qw * ty + qz * tx - qx * tz;
  const z = vz + qw * tz + qx * ty - qy * tx;

  return { x, y, z };
}

/**
 * Scales a vector.
 */
export function scalarMultiply(vector: number[], scalar: number): number[] {
  const ret = vector.slice();
  let i;
  for (i = 0; i < ret.length; ++i) {
    ret[i]! *= scalar;
  }
  return ret;
}

/**
 * Sums an array of vectors
 * NOTE: all the vector arrays must be at least the length of the first vector
 */
export function vectorAddition(vectors: number[][]): number[] {
  const first = vectors[0];
  if (!first) {
    throw new Error("vectorAddition requires vectors");
  }
  const ret = first.slice();
  for (let i = 1; i < vectors.length; ++i) {
    for (let j = 0; j < ret.length; ++j) {
      ret[j]! += vectors[i]![j]!;
    }
  }
  return ret;
}
`},{fileName:"markers.ts",sourceCode:`import type { Header, Pose, Point, RGBA, Time } from "./types.ts";

export interface IMarker {
  header: Header;
  ns: string;
  id: number;
  type: number;
  action: number;
  pose: Pose;
  scale: Point;
  color: RGBA;
  lifetime: Time;
  frame_locked: boolean;
  points: Point[];
  colors: RGBA[];
  text: string;
  mesh_resource: string;
  mesh_use_embedded_materials: boolean;
}

export type IRosMarker = IMarker;

export interface ImageMarker {
  header: Header;
  ns: string;
  id: number;
  type: number;
  action: number;
  position: Point;
  scale: number;
  outline_color: RGBA;
  filled: boolean;
  fill_color: RGBA;
  lifetime: Time;
  points: Point[];
  outline_colors: RGBA[];
}

/**
 * buildRosMarker builds a complete Marker message from an optional set of args.
 *
 * See https://docs.foxglove.dev/docs/visualization/panels/3d for a list of supported Marker types
 *
 * @param args override any defaults in the marker fields
 * @returns an IRosMarker instance with default values for any omitted args
 */
export function buildRosMarker(args?: Partial<IRosMarker>): IRosMarker {
  const {
    header,
    ns,
    id,
    type,
    action,
    pose,
    scale,
    color,
    lifetime,
    frame_locked,
    points,
    colors,
    text,
    mesh_resource,
    mesh_use_embedded_materials,
  } = args ?? {};

  return {
    header: header ?? {
      frame_id: "",
      stamp: {
        sec: 0,
        nsec: 0,
      },
      seq: 0,
    },
    ns: ns ?? "",
    id: id ?? 0,
    type: type ?? 0,
    action: action ?? 0,
    pose: pose ?? {
      position: {
        x: 0,
        y: 0,
        z: 0,
      },
      orientation: {
        x: 0,
        y: 0,
        z: 0,
        w: 0,
      },
    },
    scale: scale ?? { x: 0, y: 0, z: 0 },
    color: color ?? { r: 0, g: 0, b: 0, a: 0 },
    lifetime: lifetime ?? { sec: 0, nsec: 0 },
    frame_locked: frame_locked ?? false,
    points: points ?? [],
    colors: colors ?? [],
    text: text ?? "",
    mesh_resource: mesh_resource ?? "",
    mesh_use_embedded_materials: mesh_use_embedded_materials ?? false,
  };
}

/**
 * buildImageMarker builds a complete Marker message from an optional set of args.
 *
 * See https://docs.foxglove.dev/docs/visualization/panels/image for a list of supported Marker types
 *
 * @param args override any defaults in the marker fields
 * @returns an ImageMarker instance with default values for any omitted args
 */
export function buildImageMarker(args?: Partial<ImageMarker>): ImageMarker {
  const {
    header,
    ns,
    id,
    type,
    action,
    lifetime,
    points,
    outline_color,
    outline_colors,
    filled,
    fill_color,
    position,
    scale,
  } = args ?? {};

  return {
    header: header ?? {
      frame_id: "",
      stamp: {
        sec: 0,
        nsec: 0,
      },
      seq: 0,
    },
    ns: ns ?? "",
    id: id ?? 0,
    type: type ?? 0,
    action: action ?? 0,
    position: position ?? {
      x: 0,
      y: 0,
      z: 0,
    },
    scale: scale ?? 1,
    outline_color: outline_color ?? { r: 0, g: 0, b: 0, a: 0 },
    lifetime: lifetime ?? { sec: 0, nsec: 0 },
    points: points ?? [],
    outline_colors: outline_colors ?? [],
    filled: filled ?? false,
    fill_color: fill_color ?? { r: 0, g: 0, b: 0, a: 0 },
  };
}

/**
 * Use this class to instantiate marker-like objects with defaulted values.
 *
 * @deprecated prefer \`buildRosMarker({ ... })\` instead
 */
export class Marker implements IMarker {
  public header: Header = {
    frame_id: "",
    stamp: {
      sec: 0,
      nsec: 0,
    },
    seq: 0,
  };
  public ns = "";
  public id = 0;
  public type = 0;
  public action = 0;
  public pose: Pose = {
    position: {
      x: 0,
      y: 0,
      z: 0,
    },
    orientation: {
      x: 0,
      y: 0,
      z: 0,
      w: 0,
    },
  };
  public scale: Point = {
    x: 0,
    y: 0,
    z: 0,
  };
  public color: RGBA = { r: 0, g: 0, b: 0, a: 0 };
  public lifetime: Time = { sec: 0, nsec: 0 };
  public frame_locked = false;
  public points: Point[] = [];
  public colors: RGBA[] = [];
  public text = "";
  public mesh_resource = "";
  public mesh_use_embedded_materials = false;

  public constructor({
    header,
    ns,
    id,
    type,
    action,
    pose,
    scale,
    color,
    lifetime,
    frame_locked,
    points,
    colors,
    text,
    mesh_resource,
    mesh_use_embedded_materials,
  }: Partial<IMarker>) {
    this.header = header ?? {
      frame_id: "",
      stamp: {
        sec: 0,
        nsec: 0,
      },
      seq: 0,
    };
    this.ns = ns ?? "";
    this.id = id ?? 0;
    this.type = type ?? 0;
    this.action = action ?? 0;
    this.pose = pose ?? {
      position: {
        x: 0,
        y: 0,
        z: 0,
      },
      orientation: {
        x: 0,
        y: 0,
        z: 0,
        w: 0,
      },
    };
    this.scale = scale ?? { x: 0, y: 0, z: 0 };
    this.color = color ?? { r: 0, g: 0, b: 0, a: 0 };
    this.lifetime = lifetime ?? { sec: 0, nsec: 0 };
    this.frame_locked = frame_locked ?? false;
    this.points = points ?? [];
    this.colors = colors ?? [];
    this.text = text ?? "";
    this.mesh_resource = mesh_resource ?? "";
    this.mesh_use_embedded_materials = mesh_use_embedded_materials ?? false;
  }
}
/**
 * Corresponds to the 'type' field of a marker.
 */
export enum MarkerTypes {
  ARROW = 0,
  CUBE = 1,
  SPHERE = 2,
  CYLINDER = 3,
  LINE_STRIP = 4,
  LINE_LIST = 5,
  CUBE_LIST = 6,
  SPHERE_LIST = 7,
  POINTS = 8,
  TEXT = 9,
  MESH = 10,
  TRIANGLE_LIST = 11,
}
`}];var o=n(33740);function mn(){return m.A([...(0,u.exportTypeScriptSchemas)({includeTypedArrays:!0}).entries()],([e])=>e).map(([e,t])=>({fileName:`@foxglove/schemas/${e}.ts`,filePath:`@foxglove/schemas/${e}.ts`,sourceCode:t.replaceAll(/export enum (\w+) {/g,"export const enum $1 {")}))}const un=fn.map(s=>({...s,filePath:`/foxglove_script/${s.fileName}`}));function pn(s=[]){const a=[];a.push({fileName:r,filePath:r,sourceCode:dn}),a.push(...mn());const e=s.map(t=>({fileName:t.name,filePath:`/foxglove_script/${t.name}`,sourceCode:t.source}));return{defaultLibFileName:r,rosLib:{fileName:o.h,filePath:`/node_modules/${o.h}`,sourceCode:o.v},declarations:a,builtinUtilityFiles:un,extensionUtilityFiles:e}}},82976(){},92313(){},96582(){}}]);})();
