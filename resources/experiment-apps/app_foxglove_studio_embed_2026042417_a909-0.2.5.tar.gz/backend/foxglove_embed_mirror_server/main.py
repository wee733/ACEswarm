"""CLI entry point for the Foxglove embed mirror."""
from __future__ import annotations

import argparse
import asyncio
import shutil
import sys
from pathlib import Path

from config import load_config
import manifest


def cmd_crawl(args: argparse.Namespace) -> int:
    from crawl import run_crawl

    cfg = load_config(args.config)
    asyncio.run(run_crawl(cfg))
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    from server import serve

    cfg = load_config(args.config)
    serve(cfg)
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    if not cfg.manifest_file.exists():
        print(f"[verify] no manifest at {cfg.manifest_file}", file=sys.stderr)
        return 2
    count, errors = manifest.verify(cfg.manifest_file, cfg.static_root)
    if errors:
        for e in errors:
            print(f"[verify] ERROR {e}")
        print(f"[verify] {len(errors)} problem(s) across {count} entries")
        return 1
    print(f"[verify] OK: {count} entries match")
    return 0


def cmd_clean(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    if not args.yes:
        print(
            f"refuse to clean without --yes: would remove {cfg.static_root} and {cfg.manifest_file}",
            file=sys.stderr,
        )
        return 2
    if cfg.static_root.exists():
        shutil.rmtree(cfg.static_root)
        print(f"[clean] removed {cfg.static_root}")
    if cfg.manifest_file.exists():
        cfg.manifest_file.unlink()
        print(f"[clean] removed {cfg.manifest_file}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="foxglove-embed-mirror",
        description="Offline mirror of https://embed.foxglove.dev/ for @foxglove/embed.",
    )
    p.add_argument(
        "--config",
        default=str(Path(__file__).parent / "config.example.yaml"),
        help="path to YAML config (default: ./config.example.yaml)",
    )
    sub = p.add_subparsers(dest="command", required=True)

    pc = sub.add_parser("crawl", help="crawl embed.foxglove.dev into static/")
    pc.set_defaults(func=cmd_crawl)

    ps = sub.add_parser("serve", help="serve static/ over http")
    ps.set_defaults(func=cmd_serve)

    pv = sub.add_parser("verify", help="verify manifest hashes against static/")
    pv.set_defaults(func=cmd_verify)

    pk = sub.add_parser("clean", help="remove static/ and manifest.json")
    pk.add_argument("--yes", action="store_true", help="confirm destructive clean")
    pk.set_defaults(func=cmd_clean)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
