"""Manifest read/write/verify for mirrored assets."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Entry:
    path: str
    size: int
    sha256: str
    content_type: str

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "size": self.size,
            "sha256": self.sha256,
            "content_type": self.content_type,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Entry":
        return cls(
            path=d["path"],
            size=int(d["size"]),
            sha256=d["sha256"],
            content_type=d.get("content_type", "application/octet-stream"),
        )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def write(manifest_path: Path, entries: list[Entry]) -> None:
    entries_sorted = sorted(entries, key=lambda e: e.path)
    payload = {
        "version": 1,
        "count": len(entries_sorted),
        "entries": [e.to_dict() for e in entries_sorted],
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=False)
        f.write("\n")


def read(manifest_path: Path) -> list[Entry]:
    with open(manifest_path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    return [Entry.from_dict(d) for d in payload.get("entries", [])]


def verify(manifest_path: Path, static_dir: Path) -> tuple[int, list[str]]:
    entries = read(manifest_path)
    errors: list[str] = []
    for e in entries:
        fp = static_dir / e.path
        if not fp.is_file():
            errors.append(f"missing: {e.path}")
            continue
        if fp.stat().st_size != e.size:
            errors.append(f"size mismatch: {e.path} ({fp.stat().st_size} != {e.size})")
            continue
        actual = sha256_file(fp)
        if actual != e.sha256:
            errors.append(f"hash mismatch: {e.path}")
    return len(entries), errors
