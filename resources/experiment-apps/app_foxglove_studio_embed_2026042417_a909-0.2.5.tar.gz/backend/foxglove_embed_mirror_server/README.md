# foxglove_embed_mirror_server

一次性爬取 `https://embed.foxglove.dev/`，在 `127.0.0.1:3000` 起一个本地后端替代官方 CDN，让 `@foxglove/embed` / `@foxglove/embed-react` 完全离线加载 Foxglove Studio。数据源走 `live` WebSocket（指向你自己的 `foxglove_aggregator` 或 `ros-foxglove-bridge`）。

## 运行环境

- conda env：`foxglove-studio-embed-py310`（已装 playwright、PyYAML、websockets、requests）。
- 浏览器二进制需一次性安装：`python3 -m playwright install chromium`
- HTTP 服务只用 Python stdlib，零额外依赖。

## 使用流程

```bash
conda activate foxglove-studio-embed-py310

cd foxglove_embed_mirror_server

# 首次：装 Chromium
python3 -m playwright install chromium

# 1) 爬取（headless，已经覆盖所有 panel，无需交互）
python3 main.py --config config.example.yaml crawl

# 2) 校验文件完整性
python3 main.py --config config.example.yaml verify

# 3) 起本地服务
python3 main.py --config config.example.yaml serve
# => http://127.0.0.1:3000/
```

清空重来：

```bash
python3 main.py --config config.example.yaml clean --yes
```

## 爬取策略

crawl 分四个阶段，逐层补全资源：

1. **首屏加载**：headless Chromium 打开 `embed.foxglove.dev/?src=live&url=ws%3A%2F%2Fdummy`，保存所有被浏览器发起的请求。
2. **main.js chunk map**：解析 `main.<hash>.js` 里的 webpack chunk 表，拉取全部 ~100 个 JS chunk。
3. **secondary chunk map**：再次扫描所有已下载 chunk，收集它们内嵌的次级 chunk 表（例如 `9807` 这类 feature chunk 会单独声明 `5461` 等 wasm-wrapper chunk），拉取这批次级 chunk。**这一步很关键**，Plot / ROS2 / compression 等依赖的 wasm 就在这里。
4. **非 JS 资源扫描**：扫描所有已下载 chunk 中形如 `<name>.<20-hex-contenthash>.<ext>` 的字面量，拉取 wasm / woff2 / ttf / png / webp / json 等所有资源。

跑完后，`static/.assets/` 下大约有 250 个 JS chunk + 6 个 wasm（draco、ros2_db3、lz4、zstd、module.wasm 等）+ 字体 / 缩略图等。

## 配置

`config.example.yaml`：

- `listen.host` / `listen.port` —— 默认 `127.0.0.1:3000`。
- `runtime_config` —— 注入给 `globalThis.FOXGLOVE_RUNTIME_CONFIG` 的对象。默认把 `FOXGLOVE_API_URL` / `FOXGLOVE_APP_URL` 指到本地伪前缀，防止任何残余代码意外回连官方云。
- `crawl.probe_query` —— 爬取时给 URL 带的 query（默认 `?src=live&url=ws%3A%2F%2Fdummy`，触发 live 数据源代码路径）。
- `crawl.allowed_hosts` —— 只保存哪些 host 的响应。默认只保存 `embed.foxglove.dev`。

## 在前端项目里对接

`@foxglove/embed-react`：

```tsx
import { FoxgloveViewer } from "@foxglove/embed-react";

<FoxgloveViewer
  src="http://127.0.0.1:3000/"
  initialDataSource={{ type: "live", url: "ws://localhost:8765" }}
/>
```

原生 `@foxglove/embed`：

```ts
import { FoxgloveViewer } from "@foxglove/embed";

const viewer = new FoxgloveViewer({
  iframe: document.querySelector("iframe")!,
  src: "http://127.0.0.1:3000/",
  initialDataSource: { type: "live", url: "ws://localhost:8765" },
});
```

**注意 sign-in 弹窗里的 organization slug 填 `offline`**（server stub 里的 org id）。

## 反代到子路径（Caddy / nginx）

产物是**路径无关**的：爬取时已经把 `index.html` 里的 `/.assets/...` 改成 `./\.assets/...`，把 `main.*.js` 里 webpack 硬编码的 `publicPath="/.assets/"` 改成运行时根据 `document.currentScript.src` 推导，把注入的 `FOXGLOVE_API_URL`/`FOXGLOVE_APP_URL` 改成从 `document.baseURI` 现算。一次爬取，可挂在 `/`、`/foxglove/`、`/tools/fg/` 任意路径，mirror 服务本身无需感知前缀。

### Caddy 配置

反代时**剥掉挂载前缀**，mirror 后端永远以为自己在 origin 根路径：

```caddy
example.com {
    handle_path /foxglove/* {
        reverse_proxy 127.0.0.1:3000
    }
    # 宿主站其它路径...
}
```

关键是 `handle_path`（带 `_path` 后缀）而不是 `handle`——前者在转发前 strip 掉匹配到的前缀。

外层 iframe / 父页面要求跨源隔离时再给 Caddy 挂这些响应头：

```caddy
example.com {
    header {
        Cross-Origin-Embedder-Policy credentialless
        Cross-Origin-Opener-Policy same-origin
    }
    handle_path /foxglove/* {
        reverse_proxy 127.0.0.1:3000
    }
}
```

访问 `https://example.com/foxglove/` 即可加载整个 Studio。所有 chunk 与 stub API 都会走 `https://example.com/foxglove/.assets/...`、`https://example.com/foxglove/_stub_api/v1/me` 等路径。

### nginx 配置

```nginx
location /foxglove/ {
    proxy_pass http://127.0.0.1:3000/;   # 末尾斜杠很关键，等价于 strip 前缀
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

nginx 的 `proxy_pass` 后面加末尾 `/` 实现 strip，与 Caddy 的 `handle_path` 等价。

### 在 `@foxglove/embed-react` 里

```tsx
<FoxgloveViewer
  src="https://example.com/foxglove/"
  initialDataSource={{ type: "live", url: "ws://your-robot:8765" }}
/>
```

## 认证绕过（自动）

Studio 在 embed 模式下会检查 `document.cookie.includes("fox.signedin")`，没 cookie 就弹 sign-in device-code 对话框。mirror 里做了这些：

- index.html 注入的脚本会 patch `document.cookie` getter，让 `fox.signedin=1` 在 iframe 的 partitioned cookie 容器里也可见。
- Server 对 HTML 响应同时下发 `Set-Cookie: fox.signedin=1`（双保险）。
- Stub `/v1/me` 返回一个 enterprise 计划的 offline user（免除计划 gating），`/v1/orgs/{slug}/usage-limits` 返回 `{"limits":[]}` 等参数化端点也都 stub 掉。
- device-code / device-token / signin 都返回合法响应，万一 sign-in 弹窗被触发也能正常关闭走完登录流程。

正常情况下打开即进入主界面。

## 遥测屏蔽

爬取写入的 `index.html` 带一段脚本，运行时 patch 掉 `fetch` / XHR / `sendBeacon` / WebSocket / `<script>.src` / `<img>.src` / `<link>.href`，屏蔽对 `sentry.io`、`e.foxglove.dev`、PostHog、GA 这几个遥测域名的所有请求。本地部署完全不会 phone home。

## 当前快照版本

从 chunk 内嵌的 `SENTRY_RELEASE.id` 可以读出当前镜像对应的 Foxglove embed 构建（即上游 git commit）：

```bash
grep -oE 'SENTRY_RELEASE=\{id:"[a-f0-9]+"' static/.assets/5461.*.js | head -1
# e.g. SENTRY_RELEASE={id:"ce8816cce2410255cfbd4bcc736da8fd2798c49c"
```

想确认上游发了新版，对比 `curl -s https://embed.foxglove.dev/ | grep -oE 'main\.[a-f0-9]+\.js'` 和本地 `ls static/.assets/main.*.js`，不一致就重爬。

## 端到端验证

1. 浏览器直接访问 `http://127.0.0.1:3000/?src=live&url=ws://localhost:8765`，Studio 应加载并尝试连到你的 WebSocket server。
2. DevTools Network 面板过滤 `-domain:127.0.0.1 -domain:localhost`：应为空。
3. **离线测试**：关 WiFi / 拔网线，硬刷新，Studio 仍能加载。
4. 打开 Plot / 3D / Image / Log / Raw Messages / Diagnostics 等 panel，全部应正常渲染。

## 常见问题

**Q: 某个 `/.assets/XXXX.js` 或 `.wasm` 404。**
A: 说明 crawl 漏抓。重跑 `crawl` 即可（四阶段爬取幂等，manifest 合并，已有文件跳过）。如果还是 404，说明上游用了爬虫扫不到的模式（如 `new URL(eval(...), location)`），请把报错 URL 贴出来我补规则。

**Q: Sign-in 弹窗出现。**
A: 检查浏览器没屏蔽 third-party cookie 的 iframe JS 访问。如果浏览器策略极严格，弹窗里 org 填 `offline` 走完流程也能进。

**Q: 怎么升级到上游最新 Studio？**
A: 清空 `static/` 和 `manifest.json` 后 `crawl`。mirror 是一次性快照。

**Q: 不想绑 localhost，想暴露到内网。**
A: 编辑 `config.example.yaml` 的 `listen.host`。注意 COEP credentialless 要求 secure context —— 非 localhost 的 IP 通常需要 HTTPS，请自行加反向代理 TLS。

## 目录结构

```
foxglove_embed_mirror_server/
├── main.py              # CLI
├── config.py            # YAML 加载
├── crawl.py             # Playwright 爬虫 + index.html 改写 + 遥测屏蔽
├── server.py            # ThreadingHTTPServer + COEP/COOP 头 + API stub
├── manifest.py          # 清单/校验
├── config.example.yaml  # 配置模板
├── static/              # 爬下来的资源
└── manifest.json        # 文件清单
```
