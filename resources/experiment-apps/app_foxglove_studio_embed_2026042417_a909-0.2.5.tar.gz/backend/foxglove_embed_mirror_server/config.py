"""YAML config loader with dataclass typing."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class Listen:
    host: str = "127.0.0.1"
    port: int = 3000


@dataclass
class Crawl:
    target_url: str = "https://embed.foxglove.dev/"
    probe_query: str = "?src=live&url=ws%3A%2F%2Fdummy"
    settle_seconds: float = 8.0
    nav_timeout_ms: int = 60000
    allowed_hosts: list[str] = field(default_factory=lambda: ["embed.foxglove.dev"])


@dataclass
class Config:
    listen: Listen
    static_dir: Path
    manifest_path: Path
    runtime_config: dict[str, Any]
    crawl: Crawl
    config_path: Path

    @property
    def static_root(self) -> Path:
        return self.static_dir.resolve()

    @property
    def manifest_file(self) -> Path:
        return self.manifest_path.resolve()


def _abs(base: Path, p: str | Path) -> Path:
    pp = Path(p)
    return pp if pp.is_absolute() else (base / pp)


def load_config(path: str | Path) -> Config:
    cfg_path = Path(path).resolve()
    with open(cfg_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    base = cfg_path.parent
    listen_raw = raw.get("listen") or {}
    crawl_raw = raw.get("crawl") or {}

    return Config(
        listen=Listen(
            host=str(listen_raw.get("host", "127.0.0.1")),
            port=int(listen_raw.get("port", 3000)),
        ),
        static_dir=_abs(base, raw.get("static_dir", "./static")),
        manifest_path=_abs(base, raw.get("manifest_path", "./manifest.json")),
        runtime_config=dict(raw.get("runtime_config") or {}),
        crawl=Crawl(
            target_url=str(crawl_raw.get("target_url", "https://embed.foxglove.dev/")),
            probe_query=str(crawl_raw.get("probe_query", "")),
            settle_seconds=float(crawl_raw.get("settle_seconds", 8.0)),
            nav_timeout_ms=int(crawl_raw.get("nav_timeout_ms", 60000)),
            allowed_hosts=list(crawl_raw.get("allowed_hosts") or ["embed.foxglove.dev"]),
        ),
        config_path=cfg_path,
    )
