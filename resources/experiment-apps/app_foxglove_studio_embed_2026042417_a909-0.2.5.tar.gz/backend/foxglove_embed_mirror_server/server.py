"""Offline-friendly static server for the mirrored embed.foxglove.dev tree.

Responsibilities beyond pure static serving:
  - Cross-origin isolation headers (COEP/COOP) so Studio's SharedArrayBuffer works.
  - Sets the `fox.signedin` cookie on HTML responses so Studio skips sign-in.
  - Stubs a small number of API endpoints (/v1/me, /v1/session, /v1/signout,
    /_stub_api/*, /_stub_app/*) with believable offline responses.
  - Any other /v1/*, /internal/*, /api/* request returns 204 with `[]` or ``
    so Studio's startup queries don't blow up with 501.
"""
from __future__ import annotations

import json
import mimetypes
import posixpath
import re
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from config import Config


_EXTRA_MIME = {
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".wasm": "application/wasm",
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".ttf": "font/ttf",
    ".map": "application/json; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/vnd.microsoft.icon",
    ".html": "text/html; charset=utf-8",
    ".htm": "text/html; charset=utf-8",
}

_STUB_API_PREFIXES = ("/v1/", "/internal/", "/api/", "/_stub_api/", "/_stub_app/")

_STUB_ME = {
    "id": "usr_offline",
    "email": "offline@localhost",
    "username": "offline",
    "displayName": "Offline User",
    "avatarImageUrl": "",
    "admin": True,
    "seatType": "admin",
    "ip": "127.0.0.1",
    "org": {
        "id": "org_offline",
        "slug": "offline",
        "displayName": "Offline",
        "planName": "enterprise",
        "isEnterprise": True,
    },
}

_STUB_SESSION = {
    "id": "sess_offline",
    "expiresAt": "2099-01-01T00:00:00Z",
}

_STUB_DEVICE_CODE = {
    "deviceCode": "offline-device-code",
    "userCode": "OFFLINE",
    "verificationUri": "http://127.0.0.1:3000/_stub_app/verify",
    "verificationUriComplete": "http://127.0.0.1:3000/_stub_app/verify?user_code=OFFLINE",
    "signupVerificationUri": "http://127.0.0.1:3000/_stub_app/signup",
    "signupVerificationUriComplete": "http://127.0.0.1:3000/_stub_app/signup?user_code=OFFLINE",
    "expiresIn": 600,
    "interval": 5,
}

_STUB_DEVICE_TOKEN = {
    "accessToken": "offline-access-token",
    "tokenType": "Bearer",
    "expiresIn": 31536000,
    "refreshToken": "offline-refresh-token",
    "idToken": "offline-id-token",
}

_STUB_VERIFY_HTML = b"""<!doctype html>
<html><head><meta charset="utf-8"><title>Sign in</title>
<style>body{font-family:system-ui;background:#111;color:#eee;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center}</style>
</head><body>
<div>
<h2>Offline Sign-in</h2>
<p>This is the local mirror. You are already signed in.</p>
<p>This window will close automatically.</p>
</div>
<script>
setTimeout(function(){ try { window.close(); } catch(e) {} }, 500);
</script>
</body></html>
"""

# Pattern-based stubs for parameterized endpoints. Tried in order.
# Each tuple: (compiled regex, JSON payload).
# Static payloads are deep-copied by json.dumps so list/dict sharing is safe.
_STUB_PATTERNS = [
    (re.compile(r"^/v1/orgs/[^/]+/usage-limits/?$"), {"limits": []}),
    (re.compile(r"^/v1/orgs/[^/]+/members/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/projects/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/layouts/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/devices/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/recordings/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/events/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/api-keys/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/extensions/?$"), []),
    (re.compile(r"^/v1/orgs/[^/]+/custom-properties/?$"), []),
]

_STUB_SIGNIN = {
    "bearerToken": "offline-bearer-token",
    **_STUB_ME,
}


def _guess_type(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext in _EXTRA_MIME:
        return _EXTRA_MIME[ext]
    guessed, _ = mimetypes.guess_type(path)
    return guessed or "application/octet-stream"


def _is_api_path(url_path: str) -> bool:
    return any(url_path.startswith(p) for p in _STUB_API_PREFIXES)


def make_handler(cfg: Config) -> type[SimpleHTTPRequestHandler]:
    static_root = cfg.static_root

    class Handler(SimpleHTTPRequestHandler):
        server_version = "foxglove-embed-mirror/0.1"

        def log_message(self, fmt: str, *args) -> None:
            sys.stderr.write(
                "[%s] %s - %s\n"
                % (
                    self.log_date_time_string(),
                    self.address_string(),
                    fmt % args,
                )
            )

        # ---------- path translation ----------

        def translate_path(self, path: str) -> str:
            path = path.split("?", 1)[0].split("#", 1)[0]
            path = posixpath.normpath(unquote(path))
            parts = [p for p in path.split("/") if p and p != "."]
            if any(p == ".." for p in parts):
                return str(static_root)
            rel = "/".join(parts)
            if not rel:
                rel = "index.html"
            full = static_root / rel
            if full.is_dir():
                full = full / "index.html"
            return str(full)

        def guess_type(self, path: str) -> str:  # type: ignore[override]
            return _guess_type(path)

        # ---------- response headers ----------

        def _send_common_cors_headers(self) -> None:
            self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
            self.send_header("Cross-Origin-Opener-Policy", "same-origin")
            self.send_header("Cross-Origin-Resource-Policy", "cross-origin")
            self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "*"))
            self.send_header("Access-Control-Allow-Credentials", "true")

        def end_headers(self) -> None:
            # Runs for the SimpleHTTPRequestHandler static-file path.
            # Stub responses bypass this by setting _skip_end_headers=True and
            # calling send_header / super().end_headers() directly.
            if getattr(self, "_skip_end_headers", False):
                super().end_headers()
                return

            self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
            self.send_header("Cross-Origin-Opener-Policy", "same-origin")
            self.send_header("Cross-Origin-Resource-Policy", "cross-origin")
            self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
            self.send_header("X-Content-Type-Options", "nosniff")

            url_path = self.path.split("?", 1)[0].split("#", 1)[0]
            ext = Path(url_path).suffix.lower()
            if ext in {".html", ".htm"} or ext == "":
                self.send_header("Cache-Control", "no-store")
                # Inject the SIGNEDIN cookie so Studio enters signed-in mode.
                self.send_header(
                    "Set-Cookie",
                    "fox.signedin=1; Path=/; Max-Age=31536000; SameSite=Lax",
                )
            else:
                self.send_header("Cache-Control", "public, max-age=31536000, immutable")

            super().end_headers()

        # ---------- JSON stub helpers ----------

        def _send_json(self, status: int, payload) -> None:
            body = json.dumps(payload).encode("utf-8")
            self._skip_end_headers = True
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self._send_common_cors_headers()
            self.end_headers()
            self._skip_end_headers = False
            if self.command != "HEAD":
                self.wfile.write(body)

        def _send_html(self, status: int, body: bytes) -> None:
            self._skip_end_headers = True
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self._send_common_cors_headers()
            self.end_headers()
            self._skip_end_headers = False
            if self.command != "HEAD":
                self.wfile.write(body)

        def _dispatch_stub(self, url_path: str) -> bool:
            """Return True if the path was served as a stub."""
            # Verify popup pages (from _STUB_DEVICE_CODE URLs) — serve HTML, not JSON.
            if url_path in (
                "/_stub_app/verify",
                "/_stub_app/signup",
                "/verify",
                "/signup",
            ):
                self._send_html(200, _STUB_VERIFY_HTML)
                return True

            # Strip /_stub_api or /_stub_app prefix so API client routes match.
            # Studio's API client calls ${FOXGLOVE_API_URL}/v1/me which, with
            # FOXGLOVE_API_URL="http://127.0.0.1:3000/_stub_api", lands here as
            # /_stub_api/v1/me. We normalize that to /v1/me for dispatch.
            api_path = url_path
            for prefix in ("/_stub_api", "/_stub_app"):
                if api_path.startswith(prefix):
                    api_path = api_path[len(prefix):] or "/"
                    break

            # Canonical endpoints Studio expects at startup.
            if api_path == "/v1/me":
                self._send_json(200, _STUB_ME)
                return True
            if api_path == "/v1/session":
                self._send_json(200, _STUB_SESSION)
                return True
            if api_path == "/v1/signout":
                self._send_json(200, {"ok": True})
                return True
            if api_path == "/v1/auth/device-code":
                self._send_json(200, _STUB_DEVICE_CODE)
                return True
            if api_path in ("/v1/auth/device-token", "/v1/auth/token"):
                self._send_json(200, _STUB_DEVICE_TOKEN)
                return True
            if api_path == "/v1/signin":
                self._send_json(200, _STUB_SIGNIN)
                return True
            # Lists -> empty
            if api_path in (
                "/v1/layouts",
                "/v1/recordings",
                "/v1/devices",
                "/v1/events",
                "/v1/event-types",
                "/v1/extensions",
                "/v1/api-keys",
                "/v1/custom-properties",
                "/v1/org-members",
                "/v1/projects",
                "/v1/audit-events",
                "/v1/completed-tours",
                "/v1/device-tokens",
                "/v1/sessions",
            ):
                self._send_json(200, [])
                return True
            # Orgs list (/internal/auth/orgs) — return the single offline org
            if api_path == "/internal/auth/orgs":
                self._send_json(200, [dict(_STUB_ME["org"])])
                return True
            # Single org detail (/v1/orgs/{slug})
            if re.match(r"^/v1/orgs/[^/]+/?$", api_path):
                self._send_json(200, dict(_STUB_ME["org"]))
                return True
            # Parameterized endpoints (usage-limits, members, etc.)
            for pattern, payload in _STUB_PATTERNS:
                if pattern.match(api_path):
                    self._send_json(200, payload)
                    return True
            # Any other api-shaped path -> empty array for GETs, empty object for writes.
            if _is_api_path(url_path):
                if self.command == "GET":
                    self._send_json(200, [])
                else:
                    self._send_json(200, {"ok": True})
                return True
            return False

        # ---------- HTTP method entry points ----------

        def do_GET(self) -> None:  # noqa: N802
            url_path = urlparse(self.path).path
            if self._dispatch_stub(url_path):
                return
            super().do_GET()

        def do_HEAD(self) -> None:  # noqa: N802
            url_path = urlparse(self.path).path
            if self._dispatch_stub(url_path):
                return
            super().do_HEAD()

        def do_POST(self) -> None:  # noqa: N802
            url_path = urlparse(self.path).path
            # drain body so socket stays healthy
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length > 0:
                try:
                    self.rfile.read(length)
                except Exception:
                    pass
            if self._dispatch_stub(url_path):
                return
            self._send_json(404, {"error": "not_found", "path": url_path})

        def do_PUT(self) -> None:  # noqa: N802
            self.do_POST()

        def do_PATCH(self) -> None:  # noqa: N802
            self.do_POST()

        def do_DELETE(self) -> None:  # noqa: N802
            self.do_POST()

        def do_OPTIONS(self) -> None:  # noqa: N802
            self._skip_end_headers = True
            self.send_response(204)
            origin = self.headers.get("Origin", "*")
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Credentials", "true")
            self.send_header(
                "Access-Control-Allow-Methods",
                "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS",
            )
            self.send_header(
                "Access-Control-Allow-Headers",
                "Content-Type, Authorization, X-Requested-With",
            )
            self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
            self.send_header("Cross-Origin-Opener-Policy", "same-origin")
            self.end_headers()
            self._skip_end_headers = False

    return Handler


def serve(cfg: Config) -> None:
    if not cfg.static_root.is_dir():
        print(
            f"[serve] static dir missing: {cfg.static_root}\n"
            f"        run `python3 main.py --config {cfg.config_path} crawl` first.",
            file=sys.stderr,
        )
        sys.exit(2)

    index = cfg.static_root / "index.html"
    if not index.is_file():
        print(
            f"[serve] index.html not found at {index} — run crawl first.",
            file=sys.stderr,
        )
        sys.exit(2)

    handler_cls = make_handler(cfg)
    addr = (cfg.listen.host, cfg.listen.port)
    httpd = ThreadingHTTPServer(addr, handler_cls)
    print(
        f"[serve] serving {cfg.static_root} on http://{addr[0]}:{addr[1]}/ "
        f"(Ctrl-C to stop)"
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[serve] stopping")
    finally:
        httpd.server_close()
