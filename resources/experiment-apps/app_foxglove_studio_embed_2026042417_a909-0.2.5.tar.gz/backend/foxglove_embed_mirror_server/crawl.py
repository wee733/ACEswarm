"""Playwright-based crawler for embed.foxglove.dev."""
from __future__ import annotations

import asyncio
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

from playwright.async_api import async_playwright, Response

from config import Config
from manifest import Entry, sha256_bytes, write as write_manifest


RUNTIME_CONFIG_MARKER = "__FOXGLOVE_RUNTIME_CONFIG_INJECTED__"
PUBLIC_PATH_PATCH_MARKER = "__FOXGLOVE_PUBLICPATH_PATCHED__"


def _url_to_relpath(url: str) -> str | None:
    """Map an embed.foxglove.dev URL to a static-root-relative file path.

    `/` -> `index.html`, any other path kept verbatim (query/fragment dropped).
    """
    u = urlparse(url)
    path = u.path or "/"
    if path.endswith("/"):
        path = path + "index.html"
    rel = path.lstrip("/")
    if ".." in rel.split("/"):
        return None
    return rel


def rewrite_main_js(body: bytes) -> bytes:
    """Rewrite hard-coded webpack publicPath to be path-agnostic.

    Applied to main.*.js AND every worker-entry chunk that bakes in
    ``X.p="/.assets/"``. Workers run in a separate script context with their
    own webpack runtime, so main.js's patched publicPath does NOT carry over
    — each worker chunk has to be patched independently or its dynamic
    chunk loads go to ``/.assets/...`` at origin root and 404 under a
    reverse-proxy prefix.

    Rewrite:
      old:  X.p="/.assets/"
      new:  X.p=(function(){var s=typeof document<"u"&&document.currentScript;
                var b=(s&&s.src)||(typeof self<"u"&&self.location&&self.location.href)||"";
                return new URL("./",b).href;})()

    Inside a Worker there is no `document`, so the fallback walks to
    ``self.location.href`` (the worker script's own URL). Either way the
    public path resolves to the directory holding the running script,
    which is the same directory (`.assets/`) that holds every chunk.

    Idempotent via PUBLIC_PATH_PATCH_MARKER.
    """
    if PUBLIC_PATH_PATCH_MARKER.encode("ascii") in body:
        return body
    pattern = re.compile(rb'([a-zA-Z_$][a-zA-Z0-9_$]{0,3})\.p\s*=\s*"/\.assets/"')
    m = pattern.search(body)
    if not m:
        return body
    var = m.group(1).decode("ascii")
    replacement = (
        f'{var}.p=(function(){{'
        f'var s=typeof document<"u"&&document.currentScript;'
        f'var b=(s&&s.src)||(typeof self<"u"&&self.location&&self.location.href)||"";'
        f'return new URL("./",b).href;}})()'
        f'/*{PUBLIC_PATH_PATCH_MARKER}*/'
    ).encode("ascii")
    return pattern.sub(replacement, body, count=1)


def rewrite_absolute_asset_paths(html: bytes) -> bytes:
    """Make absolute `/.assets/...` references in index.html relative.

    Upstream ships `<script src="/.assets/main.XYZ.js">` etc. That works at the
    origin root but breaks when mounted at a subpath. Relative references
    (``./\\.assets/...``) resolve correctly under any mount prefix.

    Only touches `src="/.assets/..."`, `href="/.assets/..."`, and similar
    attributes inside HTML. Leaves absolute URLs on other hosts alone.
    """
    return re.sub(
        rb'(src|href|data-src)=(["\'])/(\.assets/)',
        rb'\1=\2./\3',
        html,
        flags=re.IGNORECASE,
    )


_BLOCKED_HOSTS_JS = [
    "e.foxglove.dev",
    "sentry.io",
    "ingest.sentry.io",
    "ingest.us.sentry.io",
    "ingest.de.sentry.io",
    "app.posthog.com",
    "us.i.posthog.com",
    "eu.i.posthog.com",
    "google-analytics.com",
    "www.google-analytics.com",
    "analytics.google.com",
]


def rewrite_index_html(html: bytes, runtime_config: dict) -> bytes:
    """Inject globalThis.FOXGLOVE_RUNTIME_CONFIG + block third-party telemetry.

    Path-agnostic: any absolute ``/.assets/...`` references are rewritten to
    relative ``./\\.assets/...`` so the page works behind a reverse proxy at
    any mount prefix. The injected FOXGLOVE_RUNTIME_CONFIG computes API/APP
    URLs from ``location.href`` at runtime; static runtime_config values from
    YAML are merged on top so users can still override individual keys.

    Idempotent: if marker already present, returns input unchanged.
    """
    if RUNTIME_CONFIG_MARKER.encode("ascii") in html:
        return html

    html = rewrite_absolute_asset_paths(html)

    # Static runtime_config from YAML — merged on top of the runtime-computed
    # API/APP URLs. We only serialize the static portion here; the dynamic
    # URLs are filled in on the client.
    cfg_json = json.dumps(runtime_config, separators=(",", ":"))
    blocked_json = json.dumps(_BLOCKED_HOSTS_JS, separators=(",", ":"))
    # Block fetch/XHR/sendBeacon/<script>/<img>/<link>/WebSocket to telemetry
    # hosts. Uses a permissive suffix match so subdomains (e.g. *.sentry.io)
    # are covered. Stubs return empty 200 responses.
    block_script = (
        "(function(){"
        f"var BLOCKED={blocked_json};"
        "function isBlocked(u){try{var h=new URL(u,location.href).hostname;"
        "return BLOCKED.some(function(b){return h===b||h.endsWith('.'+b)||b.split('.').length>=3&&h.endsWith(b.split('.').slice(-2).join('.'))});}"
        "catch(e){return false}}"
        "var of=window.fetch;window.fetch=function(u,o){"
        "var s=typeof u==='string'?u:(u&&u.url)||'';"
        "if(isBlocked(s)){return Promise.resolve(new Response('{}',{status:200,headers:{'content-type':'application/json'}}));}"
        "return of.apply(this,arguments)};"
        "var oo=XMLHttpRequest.prototype.open;"
        "XMLHttpRequest.prototype.open=function(m,u){this.__url=u;return oo.apply(this,arguments)};"
        "var os=XMLHttpRequest.prototype.send;"
        "XMLHttpRequest.prototype.send=function(){"
        "if(isBlocked(this.__url||'')){try{this.abort()}catch(e){};return}"
        "return os.apply(this,arguments)};"
        "if(navigator.sendBeacon){var ob=navigator.sendBeacon.bind(navigator);"
        "navigator.sendBeacon=function(u,d){return isBlocked(u)?true:ob(u,d)};}"
        "var ows=window.WebSocket;window.WebSocket=function(u,p){"
        "if(isBlocked(u)){var fake={close:function(){},send:function(){},addEventListener:function(){},removeEventListener:function(){},readyState:3};return fake;}"
        "return p?new ows(u,p):new ows(u)};window.WebSocket.prototype=ows.prototype;"
        "function patchSrc(tag){var proto=tag.prototype;var desc=Object.getOwnPropertyDescriptor(proto,'src');"
        "if(!desc||!desc.set)return;"
        "Object.defineProperty(proto,'src',{configurable:true,enumerable:true,"
        "get:function(){return desc.get.call(this)},"
        "set:function(v){if(isBlocked(v)){return}desc.set.call(this,v)}});}"
        "patchSrc(HTMLScriptElement);patchSrc(HTMLImageElement);patchSrc(HTMLIFrameElement);"
        "var lproto=HTMLLinkElement.prototype;var ld=Object.getOwnPropertyDescriptor(lproto,'href');"
        "if(ld&&ld.set){Object.defineProperty(lproto,'href',{configurable:true,enumerable:true,"
        "get:function(){return ld.get.call(this)},"
        "set:function(v){if(isBlocked(v)){return}ld.set.call(this,v)}});}"
        "})();"
    )
    snippet = (
        f'<script data-origin="{RUNTIME_CONFIG_MARKER}">'
        # Force-patch document.cookie so the SIGNEDIN cookie is ALWAYS present,
        # even inside a partitioned iframe where storage access is blocked.
        # Belt-and-suspenders with Set-Cookie header + document.cookie assign.
        "try{document.cookie=\"fox.signedin=1; Path=/; Max-Age=31536000; SameSite=Lax\";}catch(e){}"
        "(function(){try{"
        "var proto=Document.prototype;"
        "var d=Object.getOwnPropertyDescriptor(proto,'cookie');"
        "if(d&&d.get){"
        "Object.defineProperty(proto,'cookie',{configurable:true,enumerable:true,"
        "get:function(){var v=d.get.call(this)||'';"
        "return v.indexOf('fox.signedin=')>=0?v:(v?v+'; ':'')+'fox.signedin=1';},"
        "set:function(v){return d.set.call(this,v);}});"
        "}"
        "if(document.requestStorageAccess){"
        "document.requestStorageAccess=function(){return Promise.resolve();};"
        "}"
        "if(document.hasStorageAccess){"
        "document.hasStorageAccess=function(){return Promise.resolve(true);};"
        "}"
        "}catch(e){}})();"
        # Build runtime_config with API/APP URLs resolved against the document
        # base URL — so the mirror works under any mount prefix (/, /foxglove,
        # /tools/foxglove, …) without rebaking artifacts. Static keys from
        # config.yaml are merged on top and can override these defaults.
        "(function(){"
        "var base=new URL('./',document.baseURI||location.href).href;"
        "var rt={"
        "FOXGLOVE_API_URL:new URL('_stub_api',base).href,"
        "FOXGLOVE_APP_URL:new URL('_stub_app',base).href"
        "};"
        f"var extra={cfg_json};"
        "for(var k in extra){rt[k]=extra[k];}"
        "globalThis.FOXGLOVE_RUNTIME_CONFIG=rt;"
        "})();"
        f"{block_script}"
        f"</script>"
    ).encode("utf-8")

    text = html
    # Try: insert before first <script…> tag
    m = re.search(rb"<script\b", text, flags=re.IGNORECASE)
    if m:
        idx = m.start()
        return text[:idx] + snippet + text[idx:]

    # Fallback: insert before </head>
    m = re.search(rb"</head\s*>", text, flags=re.IGNORECASE)
    if m:
        idx = m.start()
        return text[:idx] + snippet + text[idx:]

    # Last resort: prepend
    return snippet + text


async def _save_response(
    resp: Response,
    static_dir: Path,
    allowed_hosts: set[str],
    collected: dict[str, Entry],
    runtime_config: dict,
) -> None:
    try:
        u = urlparse(resp.url)
    except Exception:
        return
    if u.scheme not in {"http", "https"}:
        return
    if u.hostname not in allowed_hosts:
        return
    if resp.status >= 400:
        # still record failures to aid debugging, but don't save body
        print(f"[crawl] SKIP {resp.status} {resp.url}", file=sys.stderr)
        return

    rel = _url_to_relpath(resp.url)
    if rel is None:
        return

    try:
        body = await resp.body()
    except Exception as e:
        print(f"[crawl] body() failed for {resp.url}: {e}", file=sys.stderr)
        return

    # Playwright sometimes fires `response` before the body is fully streamed,
    # yielding an empty buffer. Skip zero-length JS/CSS/wasm — the real response
    # will fire again once streaming completes.
    if len(body) == 0 and rel != "index.html":
        ext = Path(rel).suffix.lower()
        if ext in {".js", ".mjs", ".css", ".wasm", ".woff2", ".woff", ".ttf"}:
            return

    # rewrite index.html
    if rel == "index.html":
        body = rewrite_index_html(body, runtime_config)
    # Rewrite webpack publicPath in any .js chunk that bakes in "/.assets/".
    # That includes main.*.js (the host runtime) AND every worker-entry chunk
    # (workers have their own webpack runtime; main.js's patch doesn't reach
    # them). Safe to apply broadly because the rewriter is a no-op when the
    # pattern isn't present.
    elif rel.startswith(".assets/") and rel.endswith((".js", ".mjs")):
        body = rewrite_main_js(body)

    out_path = static_dir / rel
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(body)

    headers = resp.headers
    content_type = headers.get("content-type", "application/octet-stream")
    cache_control = headers.get("cache-control", "")

    meta = {
        "original_url": resp.url,
        "status": resp.status,
        "content_type": content_type,
        "cache_control": cache_control,
    }
    out_path.with_suffix(out_path.suffix + ".meta.json").write_text(
        json.dumps(meta, indent=2) + "\n", encoding="utf-8"
    )

    collected[rel] = Entry(
        path=rel,
        size=len(body),
        sha256=sha256_bytes(body),
        content_type=content_type,
    )
    print(f"[crawl] SAVE {resp.status} {resp.url} -> {rel} ({len(body)} bytes)")


def _extract_chunk_map(main_js: str) -> dict[str, str]:
    """Extract webpack chunk id -> contenthash map from main.js.

    Webpack emits something like: r.u=e=>"."+{0:"abc...",123:"def..."}[e]+".js".
    We pick pairs `<id>:"<hex>"` that look like contenthashes (16-40 hex chars).
    """
    pairs = re.findall(r'([0-9]{1,5}):"([0-9a-f]{16,40})"', main_js)
    return {chunk_id: h for chunk_id, h in pairs}


def _extract_all_chunk_maps(assets_dir: Path) -> dict[str, str]:
    """Extract chunk_id -> contenthash from every JS chunk under .assets/.

    Beyond main.js, feature chunks can contain additional async-chunk maps
    (e.g. chunk 9807 declares chunk 5461's hash, which main.js does not know).
    We union all such maps; when the same chunk id appears with different
    hashes across files, the last-seen wins — an acceptable heuristic because
    every chunk's map is built against the same build manifest.
    """
    merged: dict[str, str] = {}
    for js_file in assets_dir.glob("*.js"):
        try:
            text = js_file.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for chunk_id, h in re.findall(r'([0-9]{1,5}):"([0-9a-f]{16,40})"', text):
            merged[chunk_id] = h
    return merged


async def _prefetch_urls(page, urls: list[str], label: str) -> int:
    if not urls:
        return 0
    script = """
    async (urls) => {
      const results = [];
      for (const u of urls) {
        try {
          const r = await fetch(u, { credentials: 'omit', mode: 'same-origin' });
          results.push([u, r.status]);
        } catch (e) {
          results.push([u, -1]);
        }
      }
      return results;
    }
    """
    try:
        results = await page.evaluate(script, urls)
    except Exception as e:
        print(f"[crawl] {label} evaluate failed: {e}", file=sys.stderr)
        return 0
    ok = sum(1 for _, s in results if s == 200)
    print(f"[crawl] {label}: fetched {ok}/{len(urls)}")
    return ok


async def _prefetch_chunks(page, base_url: str, main_js_relpath: Path, seen: set[str]) -> None:
    """Load main.js bytes, extract chunk ids, and request each one via the page."""
    try:
        main_js_text = main_js_relpath.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        print(f"[crawl] could not read main.js for chunk prefetch: {e}", file=sys.stderr)
        return

    chunks = _extract_chunk_map(main_js_text)
    print(f"[crawl] main.js declares {len(chunks)} chunk hashes")

    base = base_url.rstrip("/")
    urls: list[str] = []
    for chunk_id, h in chunks.items():
        rel = f".assets/{chunk_id}.{h}.js"
        if rel in seen:
            continue
        urls.append(f"{base}/{rel}")

    await _prefetch_urls(page, urls, "chunk prefetch")


async def _prefetch_secondary_chunks(
    page, base_url: str, assets_dir: Path, seen: set[str]
) -> None:
    """Scan all downloaded chunks for additional chunk_id:hash maps.

    Feature chunks (e.g. the one that loads ros2_db3) declare their own async
    chunks that main.js does not know about. Run this after the main chunk
    prefetch to pull those in.
    """
    merged = _extract_all_chunk_maps(assets_dir)
    base = base_url.rstrip("/")
    urls: list[str] = []
    for chunk_id, h in merged.items():
        rel = f".assets/{chunk_id}.{h}.js"
        if rel in seen:
            continue
        urls.append(f"{base}/{rel}")
    print(f"[crawl] merged chunk map across all chunks: {len(merged)} entries, {len(urls)} new")
    await _prefetch_urls(page, urls, "secondary chunk prefetch")


async def _prefetch_index_refs(page, base_url: str, index_html_path: Path, seen: set[str]) -> None:
    """Scan index.html for referenced static assets (icons, webp, css) and fetch them."""
    try:
        html = index_html_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return
    refs = set(
        re.findall(
            r'(/\.assets/[a-zA-Z0-9._-]+\.(?:webp|png|jpg|jpeg|ico|svg|gif|css|woff2|woff|ttf|wasm|json))',
            html,
        )
    )
    base = base_url.rstrip("/")
    urls = [f"{base}{r}" for r in sorted(refs) if r.lstrip("/") not in seen]
    await _prefetch_urls(page, urls, "index-ref prefetch")


# File extensions we consider "asset-like" when scanning chunk bodies for
# referenced filenames (fonts, wasm, thumbnails, marker icons, Monaco JSONs…).
# Kept conservative to avoid matching arbitrary strings inside chunks.
_ASSET_EXT_RE = (
    r"(?:wasm|woff2?|ttf|otf|png|jpg|jpeg|webp|gif|ico|svg|mp4|webm|bin|data|json)"
)


def _extract_asset_filenames_from_chunks(assets_dir: Path) -> set[str]:
    """Scan every .js chunk for hashed asset filenames.

    Webpack's `file-loader` / `asset/resource` output typically has the form
    `<name>.<20-hex-contenthash>.<ext>`. We capture those aggressively.

    We intentionally skip bare (unhashed) names like `marker-icon.png` —
    embed.foxglove.dev returns 403 on those paths (Leaflet's defaults reference
    them but the app typically never fetches them at runtime because the icon
    path is overridden at init).
    """
    hashed = re.compile(
        rf'[\"\']([a-zA-Z0-9_-]+\.[0-9a-f]{{8,40}}\.{_ASSET_EXT_RE})[\"\']'
    )

    found: set[str] = set()
    for js_file in assets_dir.glob("*.js"):
        try:
            text = js_file.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for m in hashed.finditer(text):
            found.add(m.group(1))
    return found


async def _prefetch_chunk_assets(
    page, base_url: str, assets_dir: Path, seen: set[str]
) -> None:
    """Scan downloaded chunks for referenced asset files and fetch each one.

    Catches thumbnails, wasm decoders, fonts, leaflet marker icons, etc.
    Foxglove panels fail silently if these are missing on the local mirror.
    """
    filenames = _extract_asset_filenames_from_chunks(assets_dir)
    if not filenames:
        return
    base = base_url.rstrip("/")
    urls = [
        f"{base}/.assets/{name}"
        for name in sorted(filenames)
        if f".assets/{name}" not in seen
    ]
    print(f"[crawl] chunk scan found {len(filenames)} asset refs, {len(urls)} new")
    await _prefetch_urls(page, urls, "chunk-asset prefetch")


async def run_crawl(cfg: Config) -> None:
    cfg.static_root.mkdir(parents=True, exist_ok=True)
    # Merge with any pre-existing manifest so successive crawls accumulate
    collected: dict[str, Entry] = {}
    if cfg.manifest_file.exists():
        try:
            from manifest import read as read_manifest

            for e in read_manifest(cfg.manifest_file):
                collected[e.path] = e
        except Exception as e:
            print(f"[crawl] existing manifest unreadable, ignoring: {e}", file=sys.stderr)

    allowed = set(cfg.crawl.allowed_hosts)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(ignore_https_errors=True)
        page = await context.new_page()

        page.on(
            "response",
            lambda resp: asyncio.create_task(
                _save_response(resp, cfg.static_root, allowed, collected, cfg.runtime_config)
            ),
        )

        probe = cfg.crawl.probe_query or ""
        if probe and not probe.startswith("?"):
            probe = "?" + probe
        target = cfg.crawl.target_url.rstrip("/") + "/" + probe

        print(f"[crawl] navigating to {target}")
        try:
            await page.goto(
                target, wait_until="domcontentloaded", timeout=cfg.crawl.nav_timeout_ms
            )
        except Exception as e:
            print(f"[crawl] navigation warning: {e}", file=sys.stderr)

        # Initial settle to let eager chunks load
        await page.wait_for_timeout(int(cfg.crawl.settle_seconds * 1000))

        # Prefetch every chunk declared in main.js to guarantee completeness
        main_js_candidates = list(cfg.static_root.glob(".assets/main.*.js"))
        if main_js_candidates:
            await _prefetch_chunks(
                page,
                base_url=cfg.crawl.target_url,
                main_js_relpath=main_js_candidates[0],
                seen=set(collected.keys()),
            )
            await page.wait_for_timeout(2000)

        # Secondary pass: scan all downloaded chunks for additional chunk_id->hash
        # tables they embed (feature chunks that dynamically import smaller chunks,
        # e.g. the ros2_db3 wasm wrapper). Fetch those too.
        assets_dir = cfg.static_root / ".assets"
        if assets_dir.is_dir():
            await _prefetch_secondary_chunks(
                page,
                base_url=cfg.crawl.target_url,
                assets_dir=assets_dir,
                seen=set(collected.keys()),
            )
            await page.wait_for_timeout(1500)

        # Prefetch assets referenced in index.html (icons, webp, favicons)
        index_path = cfg.static_root / "index.html"
        if index_path.is_file():
            await _prefetch_index_refs(
                page,
                base_url=cfg.crawl.target_url,
                index_html_path=index_path,
                seen=set(collected.keys()),
            )
            await page.wait_for_timeout(1000)

        # Scan chunk bodies for referenced asset files (thumbnails, wasm, fonts,
        # marker icons, Monaco JSONs) and fetch them. Panels that reference a
        # missing asset fail silently in embed mode, which is why plots etc.
        # can break even when every JS chunk is present.
        if assets_dir.is_dir():
            await _prefetch_chunk_assets(
                page,
                base_url=cfg.crawl.target_url,
                assets_dir=assets_dir,
                seen=set(collected.keys()),
            )
            await page.wait_for_timeout(1500)

        # nudge lazy chunks one more time
        try:
            await page.evaluate("window.dispatchEvent(new Event('resize'))")
            await page.evaluate("window.scrollBy(0, 200)")
        except Exception:
            pass
        await page.wait_for_timeout(2000)

        await context.close()
        await browser.close()

    write_manifest(cfg.manifest_file, list(collected.values()))
    print(f"[crawl] wrote manifest with {len(collected)} entries -> {cfg.manifest_file}")
