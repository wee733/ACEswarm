#!/usr/bin/env python3
"""
Custom Foxglove SDK server for visualization topics.

This server subscribes to robot telemetry via Zenoh and serves visualization assets and data to Foxglove Studio via the Foxglove SDK. 

A foxglove aggregator elsewhere combines this foxglove sdk server with the ROS foxglove bridge server to provide a unified address for Foxglove Studio to connect to.
"""

from __future__ import annotations

import argparse
import logging
import signal
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import foxglove

try:
    import yaml
except ImportError:  # pragma: no cover - pre_install should install this.
    yaml = None

try:
    from .display_control_api import DisplayControlApiServer
    from .visualizer_rotor import RotorVisualizerManager
except ImportError:  # Allows running this file directly.
    from display_control_api import DisplayControlApiServer
    from visualizer_rotor import RotorVisualizerManager


ASSET_ROOT = Path(__file__).resolve().parent / "assets"
PACKAGE_NAME = "px4_rotor_sim"


@dataclass(frozen=True)
class FoxgloveSdkServerRuntime:
    publish_rate_hz: float = 20.0
    history_publish_rate_hz: float = 5.0


@dataclass(frozen=True)
class ReplaceRobotDisplaysResult:
    ok: bool
    skipped_robots: list[dict[str, str]]


def _yaml_get(root: dict[str, Any], dotted_path: str, default: Any = None) -> Any:
    current: Any = root
    for part in dotted_path.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current


def _float_value(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _int_value(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _str_value(value: Any, default: str) -> str:
    return value if isinstance(value, str) and value else default


def robot_type_from_metadata(metadata: dict[str, Any] | None) -> str:
    if metadata is None:
        return "rotor"
    if not isinstance(metadata, dict):
        logging.warning("robot metadata must be a dict, got %s", type(metadata).__name__)
        return "rotor"
    return _str_value(metadata.get("robot_type"), "rotor").lower()


def load_config(path: Path | None) -> tuple[str, int, str, str, int, float, FoxgloveSdkServerRuntime]:
    raw: dict[str, Any] = {}
    if path is not None and path.is_file():
        if yaml is None:
            raise RuntimeError("PyYAML is required to load config")
        with path.open("r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

    app = raw.get("foxglove_studio_embed", raw)
    visualize = _yaml_get(app, "backend.visualize", {}) or {}
    foxglove_sdk_server = (
        visualize.get("foxglove_sdk_server", {}) if isinstance(visualize, dict) else {}
    )
    display_control_api = (
        visualize.get("display_control_api", {}) if isinstance(visualize, dict) else {}
    )
    runtime = FoxgloveSdkServerRuntime(
        publish_rate_hz=_float_value(visualize.get("publish_rate_hz"), 20.0),
        history_publish_rate_hz=_float_value(visualize.get("history_publish_rate_hz"), 5.0),
    )
    return (
        _str_value(foxglove_sdk_server.get("listen_host"), "127.0.0.1"),
        _int_value(foxglove_sdk_server.get("listen_port"), 18767),
        _str_value(foxglove_sdk_server.get("zenoh_endpoint"), ""),
        _str_value(display_control_api.get("listen_host"), "127.0.0.1"),
        _int_value(display_control_api.get("listen_port"), 19287),
        _float_value(display_control_api.get("idle_clear_delay_sec"), 3.0),
        runtime,
    )


def asset_handler(uri: str) -> bytes | None:
    prefix = f"package://{PACKAGE_NAME}/"
    if not uri.startswith(prefix):
        return None

    rel = uri[len(prefix) :]
    path = (ASSET_ROOT / PACKAGE_NAME / rel).resolve()
    try:
        path.relative_to(ASSET_ROOT.resolve())
    except ValueError:
        return None
    if not path.is_file():
        return None
    return path.read_bytes()


class FoxgloveSdkDisplayServer:
    def __init__(self, server_runtime: FoxgloveSdkServerRuntime) -> None:
        self.rotor_visualizer_manager = RotorVisualizerManager(server_runtime)

    @staticmethod
    def _supports_metadata(metadata: dict[str, Any] | None) -> bool:
        return "rotor" in robot_type_from_metadata(metadata)

    def add_robot_display(self, name: str, metadata: dict[str, Any] | None = None) -> bool:
        robot_type = robot_type_from_metadata(metadata)
        if not self._supports_metadata(metadata):
            logging.warning("unsupported robot_type=%s for add_robot_display(%s)", robot_type, name)
            return False
        return self.rotor_visualizer_manager.add_robot(name, metadata)

    def update_robot_display(self, name: str, metadata: dict[str, Any] | None = None) -> bool:
        robot_type = robot_type_from_metadata(metadata)
        if not self._supports_metadata(metadata):
            logging.warning("unsupported robot_type=%s for update_robot_display(%s)", robot_type, name)
            return False
        return self.rotor_visualizer_manager.update_robot(name, metadata)

    def remove_robot_display(self, name: str, metadata: dict[str, Any] | None = None) -> bool:
        robot_type = robot_type_from_metadata(metadata)
        if not self._supports_metadata(metadata):
            logging.warning("unsupported robot_type=%s for remove_robot_display(%s)", robot_type, name)
            return False
        return self.rotor_visualizer_manager.remove_robot(name)

    def list_robot_displays(self) -> list[dict[str, Any]]:
        return self.rotor_visualizer_manager.list_robots()

    def replace_robot_displays(self, robots: list[dict[str, Any]]) -> ReplaceRobotDisplaysResult:
        desired_names: set[str] = set()
        supported_robots: list[dict[str, Any]] = []
        skipped_robots: list[dict[str, str]] = []
        for robot in robots:
            name = robot.get("name")
            metadata = robot.get("metadata", {})
            if not isinstance(name, str) or not name.strip():
                return ReplaceRobotDisplaysResult(ok=False, skipped_robots=skipped_robots)
            normalized_name = name.strip()
            robot_type = robot_type_from_metadata(metadata)
            if not self._supports_metadata(metadata):
                logging.warning(
                    "unsupported robot_type=%s for replace_robot_displays(%s); skipping",
                    robot_type,
                    normalized_name,
                )
                skipped_robots.append(
                    {
                        "name": normalized_name,
                        "robot_type": robot_type,
                        "reason": "unsupported_robot_type",
                    }
                )
                continue
            desired_names.add(normalized_name)
            supported_robots.append({"name": normalized_name, "metadata": metadata})

        current_names = {robot["name"] for robot in self.list_robot_displays()}
        for name in sorted(current_names - desired_names):
            self.remove_robot_display(name)

        for robot in supported_robots:
            name = robot["name"]
            metadata = robot.get("metadata", {})
            if name in current_names:
                if not self.update_robot_display(name, metadata):
                    return ReplaceRobotDisplaysResult(ok=False, skipped_robots=skipped_robots)
            elif not self.add_robot_display(name, metadata):
                return ReplaceRobotDisplaysResult(ok=False, skipped_robots=skipped_robots)
        return ReplaceRobotDisplaysResult(ok=True, skipped_robots=skipped_robots)

    def start(self, endpoint: str, stop_event: threading.Event) -> None:
        self.rotor_visualizer_manager.start(endpoint, stop_event)

    def stop(self) -> None:
        self.rotor_visualizer_manager.stop()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config-path", type=Path, help="Aivuda app config YAML")
    parser.add_argument("--host", help="Override custom server host")
    parser.add_argument("--port", type=int, help="Override custom server port")
    parser.add_argument("--control-host", help="Override display control API host")
    parser.add_argument("--control-port", type=int, help="Override display control API port")
    parser.add_argument("--zenoh-endpoint", help="Zenoh locator, e.g. tcp/127.0.0.1:7447 (empty for LAN discovery)")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper()), format="%(asctime)s %(levelname)s %(message)s")
    host, port, zenoh_endpoint, control_host, control_port, idle_clear_delay_sec, runtime = load_config(args.config_path)
    if args.host:
        host = args.host
    if args.port:
        port = args.port
    if args.zenoh_endpoint is not None:
        zenoh_endpoint = args.zenoh_endpoint
    if args.control_host:
        control_host = args.control_host
    if args.control_port:
        control_port = args.control_port

    endpoint = zenoh_endpoint.strip()
    display_server = FoxgloveSdkDisplayServer(runtime)
    stop_event = threading.Event()

    def request_stop(_signum: int, _frame: Any) -> None:
        stop_event.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)

    foxglove.set_log_level(logging.INFO)
    server = foxglove.start_server(
        name="visualize_foxglove_server",
        host=host,
        port=port,
        asset_handler=asset_handler,
    )
    control_api = DisplayControlApiServer(control_host, control_port, display_server, idle_clear_delay_sec)
    control_api.start()
    display_server.start(endpoint, stop_event)

    logging.info("visualize_foxglove_server listening on ws://%s:%d", host, port)
    logging.info("display control API listening on http://%s:%d", control_host, control_port)
    logging.info("display idle clear delay: %.3fs", idle_clear_delay_sec)
    logging.info("joining Zenoh session using %s", endpoint or "LAN discovery")
    logging.info("initial robot display list is empty")

    try:
        while not stop_event.wait(0.5):
            pass
    finally:
        stop_event.set()
        control_api.stop()
        display_server.stop()
        server.stop()


if __name__ == "__main__":
    main()
