"""HTTP REST API for dynamic Foxglove display control."""

from __future__ import annotations

import json
import logging
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import unquote, urlparse


class DisplayControlApiServer:
    def __init__(self, host: str, port: int, display_server: Any, idle_clear_delay_sec: float = 3.0) -> None:
        self.host = host
        self.port = port
        self.display_server = display_server
        self.idle_clear_delay_sec = max(float(idle_clear_delay_sec), 0.0)
        self._httpd: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._lifecycle_lock = threading.Lock()
        self._idle_clear_timer: threading.Timer | None = None
        self._last_client_count = 0

    def start(self) -> None:
        if self._httpd is not None:
            return

        display_server = self.display_server
        api_server = self

        class Handler(DisplayControlRequestHandler):
            controller = display_server
            lifecycle_api = api_server

        self._httpd = ThreadingHTTPServer((self.host, self.port), Handler)
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            name="display-control-api",
            daemon=True,
        )
        self._thread.start()
        logging.info("display control API listening on http://%s:%d", self.host, self.port)

    def stop(self) -> None:
        if self._httpd is None:
            return
        logging.info("stopping display control API on http://%s:%d", self.host, self.port)
        self.cancel_idle_clear()
        self._httpd.shutdown()
        self._httpd.server_close()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._httpd = None
        self._thread = None

    def handle_lifecycle_event(self, payload: dict[str, Any]) -> dict[str, Any]:
        event = payload.get("event")
        if event != "frontend_client_count_changed":
            logging.info("display lifecycle ignored event=%s", event)
            return {"status": "ignored", "event": event}
        try:
            client_count = int(payload.get("client_count"))
        except (TypeError, ValueError):
            raise ValueError("client_count must be an integer") from None

        with self._lifecycle_lock:
            self._last_client_count = client_count
            if client_count > 0:
                canceled = self._cancel_idle_clear_locked()
                logging.info("display lifecycle client_count=%d; idle clear canceled=%s", client_count, canceled)
                return {"status": "active", "client_count": client_count, "idle_clear_canceled": canceled}

            self._cancel_idle_clear_locked()
            timer = threading.Timer(self.idle_clear_delay_sec, self._clear_displays_if_idle)
            timer.daemon = True
            self._idle_clear_timer = timer
            timer.start()
            logging.info(
                "display lifecycle client_count=0; scheduled idle clear in %.3fs",
                self.idle_clear_delay_sec,
            )
            return {
                "status": "scheduled",
                "client_count": client_count,
                "idle_clear_delay_sec": self.idle_clear_delay_sec,
            }

    def cancel_idle_clear(self) -> None:
        with self._lifecycle_lock:
            self._cancel_idle_clear_locked()

    def _cancel_idle_clear_locked(self) -> bool:
        timer = self._idle_clear_timer
        self._idle_clear_timer = None
        if timer is None:
            return False
        timer.cancel()
        return True

    def _clear_displays_if_idle(self) -> None:
        with self._lifecycle_lock:
            if self._last_client_count > 0:
                logging.info(
                    "display lifecycle idle clear skipped; client_count=%d",
                    self._last_client_count,
                )
                self._idle_clear_timer = None
                return
            self._idle_clear_timer = None
        logging.info("display lifecycle idle clear executing replace_robot_displays([])")
        if not self.display_server.replace_robot_displays([]):
            logging.error("display lifecycle idle clear failed")
            return
        logging.info("display lifecycle idle clear complete")


class DisplayControlRequestHandler(BaseHTTPRequestHandler):
    controller: Any
    lifecycle_api: DisplayControlApiServer
    server_version = "DisplayControlApi/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        logging.info("display-control %s - %s", self.address_string(), fmt % args)

    def do_OPTIONS(self) -> None:
        self._send_empty(HTTPStatus.NO_CONTENT)

    def do_GET(self) -> None:
        path = self._path()
        if path != "/displays":
            self._send_error(HTTPStatus.NOT_FOUND, "not found")
            return
        robots = self.controller.list_robot_displays()
        logging.info("display API GET /displays -> %d robots", len(robots))
        self._send_json(HTTPStatus.OK, {"robots": robots})

    def do_POST(self) -> None:
        path = self._path()
        if path == "/lifecycle":
            self._handle_lifecycle()
            return
        if path != "/displays":
            self._send_error(HTTPStatus.NOT_FOUND, "not found")
            return
        payload = self._read_json()
        if payload is None:
            return
        robot = self._parse_robot(payload)
        if robot is None:
            return
        if self._robot_exists(robot["name"]):
            self._send_error(HTTPStatus.CONFLICT, f"display {robot['name']} already exists")
            return
        logging.info(
            "display API POST /displays add name=%s robot_type=%s",
            robot["name"],
            robot["metadata"].get("robot_type", "rotor"),
        )
        if not self.controller.add_robot_display(robot["name"], robot["metadata"]):
            self._send_error(HTTPStatus.BAD_REQUEST, "unsupported display metadata")
            return
        robots = self.controller.list_robot_displays()
        logging.info("display API added %s; active robots=%s", robot["name"], robot_names(robots))
        self._send_json(HTTPStatus.CREATED, {"robots": robots})

    def do_PUT(self) -> None:
        path = self._path()
        if path != "/displays":
            self._send_error(HTTPStatus.NOT_FOUND, "not found")
            return
        payload = self._read_json()
        if payload is None:
            return
        robots = payload.get("robots") if isinstance(payload, dict) else None
        if not isinstance(robots, list):
            self._send_error(HTTPStatus.BAD_REQUEST, "robots must be a list")
            return
        parsed_robots = []
        seen_names: set[str] = set()
        for item in robots:
            robot = self._parse_robot(item)
            if robot is None:
                return
            if robot["name"] in seen_names:
                self._send_error(HTTPStatus.CONFLICT, f"duplicate display {robot['name']}")
                return
            seen_names.add(robot["name"])
            parsed_robots.append(robot)
        logging.info(
            "display API PUT /displays replace with %d robots: %s",
            len(parsed_robots),
            ", ".join(robot["name"] for robot in parsed_robots) or "<none>",
        )
        result = self.controller.replace_robot_displays(parsed_robots)
        if not result.ok:
            self._send_error(HTTPStatus.BAD_REQUEST, "unsupported display metadata")
            return
        robots = self.controller.list_robot_displays()
        logging.info(
            "display API replace complete; active robots=%s skipped=%d",
            robot_names(robots),
            len(result.skipped_robots),
        )
        self._send_json(
            HTTPStatus.OK,
            {
                "robots": robots,
                "skipped_robots": result.skipped_robots,
            },
        )

    def do_PATCH(self) -> None:
        name = self._display_name_from_path()
        if name is None:
            self._send_error(HTTPStatus.NOT_FOUND, "not found")
            return
        payload = self._read_json()
        if payload is None:
            return
        metadata = payload.get("metadata") if isinstance(payload, dict) else None
        if metadata is None:
            metadata = payload
        if not isinstance(metadata, dict):
            self._send_error(HTTPStatus.BAD_REQUEST, "metadata must be an object")
            return
        if not self._robot_exists(name):
            self._send_error(HTTPStatus.NOT_FOUND, f"display {name} does not exist")
            return
        logging.info("display API PATCH /displays/%s metadata keys=%s", name, ", ".join(sorted(metadata)) or "<none>")
        if not self.controller.update_robot_display(name, metadata):
            self._send_error(HTTPStatus.BAD_REQUEST, "unsupported display metadata")
            return
        robots = self.controller.list_robot_displays()
        logging.info("display API updated %s; active robots=%s", name, robot_names(robots))
        self._send_json(HTTPStatus.OK, {"robots": robots})

    def do_DELETE(self) -> None:
        name = self._display_name_from_path()
        if name is None:
            self._send_error(HTTPStatus.NOT_FOUND, "not found")
            return
        if not self._robot_exists(name):
            self._send_error(HTTPStatus.NOT_FOUND, f"display {name} does not exist")
            return
        logging.info("display API DELETE /displays/%s", name)
        if not self.controller.remove_robot_display(name):
            self._send_error(HTTPStatus.INTERNAL_SERVER_ERROR, f"failed to remove display {name}")
            return
        logging.info("display API removed %s", name)
        self._send_empty(HTTPStatus.NO_CONTENT)

    def _handle_lifecycle(self) -> None:
        payload = self._read_json()
        if payload is None:
            return
        if not isinstance(payload, dict):
            self._send_error(HTTPStatus.BAD_REQUEST, "lifecycle payload must be an object")
            return
        try:
            result = self.lifecycle_api.handle_lifecycle_event(payload)
        except ValueError as exc:
            self._send_error(HTTPStatus.BAD_REQUEST, str(exc))
            return
        self._send_json(HTTPStatus.OK, result)

    def _path(self) -> str:
        return urlparse(self.path).path.rstrip("/") or "/"

    def _display_name_from_path(self) -> str | None:
        path = self._path()
        prefix = "/displays/"
        if not path.startswith(prefix):
            return None
        name = unquote(path[len(prefix) :]).strip()
        return name or None

    def _robot_exists(self, name: str) -> bool:
        return any(robot["name"] == name for robot in self.controller.list_robot_displays())

    def _parse_robot(self, value: Any) -> dict[str, Any] | None:
        if not isinstance(value, dict):
            self._send_error(HTTPStatus.BAD_REQUEST, "robot must be an object")
            return None
        name = value.get("name")
        if not isinstance(name, str) or not name.strip():
            self._send_error(HTTPStatus.BAD_REQUEST, "robot name must be a non-empty string")
            return None
        metadata = value.get("metadata", {})
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            self._send_error(HTTPStatus.BAD_REQUEST, "metadata must be an object")
            return None
        return {"name": name.strip(), "metadata": metadata}

    def _read_json(self) -> Any | None:
        content_type = self.headers.get("Content-Type", "")
        if "application/json" not in content_type:
            self._send_error(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "Content-Type must be application/json")
            return None
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send_error(HTTPStatus.BAD_REQUEST, "invalid Content-Length")
            return None
        try:
            raw = self.rfile.read(length)
            return json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            self._send_error(HTTPStatus.BAD_REQUEST, "invalid JSON")
            return None

    def _send_json(self, status: HTTPStatus, value: Any) -> None:
        body = json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self._send_common_headers()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_empty(self, status: HTTPStatus) -> None:
        self.send_response(status)
        self._send_common_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _send_error(self, status: HTTPStatus, message: str) -> None:
        logging.warning("display API error %d: %s", status.value, message)
        self._send_json(status, {"error": message})

    def _send_common_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")


def robot_names(robots: list[dict[str, Any]]) -> str:
    return ", ".join(robot["name"] for robot in robots) or "<none>"
