"""rotor-drone visualizer backed by robot_telemetry zenoh keys."""

from __future__ import annotations

import json
import logging
import math
import threading
import time
from collections import deque
from functools import partial
from dataclasses import dataclass, field
from typing import Any

import foxglove
import zenoh
from foxglove.messages import (
    Color,
    Duration,
    FrameTransform,
    FrameTransforms,
    KeyValuePair,
    LinePrimitive,
    LinePrimitiveLineType,
    LocationFix,
    LocationFixPositionCovarianceType,
    ModelPrimitive,
    Point3,
    Pose,
    PoseInFrame,
    Quaternion,
    SceneEntity,
    SceneUpdate,
    TextPrimitive,
    Timestamp,
    Vector3,
)

try:
    import cbor2
except ImportError:  # pragma: no cover - pre_install should install this.
    cbor2 = None


PACKAGE_NAME = "px4_rotor_sim"
BODY_MESH_URI = f"package://{PACKAGE_NAME}/model/meshes/iris.stl"
PROP_CCW_MESH_URI = f"package://{PACKAGE_NAME}/model/meshes/iris_prop_ccw.stl"
PROP_CW_MESH_URI = f"package://{PACKAGE_NAME}/model/meshes/iris_prop_cw.stl"
ROTOR_RPM = 200.0
ROTOR_METADATA_KEYS = {
    "robot_type",
    "position_source",
    "history_duration_sec",
    "gps_origin",
    "color",
}


@dataclass(frozen=True)
class Vec3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def to_msg(self) -> Vector3:
        return Vector3(x=self.x, y=self.y, z=self.z)

    def to_point_msg(self) -> Point3:
        return Point3(x=self.x, y=self.y, z=self.z)


@dataclass(frozen=True)
class RgbaColor:
    r: float = 1.0
    g: float = 1.0
    b: float = 1.0
    a: float = 1.0

    def to_msg(self) -> Color:
        return Color(r=self.r, g=self.g, b=self.b, a=self.a)

    def with_alpha(self, alpha: float) -> "RgbaColor":
        return RgbaColor(r=self.r, g=self.g, b=self.b, a=alpha)


@dataclass(frozen=True)
class GpsOriginConfig:
    latitude: float = 39.978861
    longitude: float = 116.339803
    altitude: float = 53.0


@dataclass(frozen=True)
class RotorDisplayRuntime:
    position_source: str = "local_pos"
    history_duration_sec: float = 5.0
    gps_origin: GpsOriginConfig = field(default_factory=GpsOriginConfig)
    color: RgbaColor = field(default_factory=lambda: RED)


@dataclass(frozen=True)
class PropellerConfig:
    name: str
    origin: Vec3
    mesh_uri: str
    color: RgbaColor


RED = RgbaColor(r=0.9, g=0.1, b=0.1, a=1.0)
GREY = RgbaColor(r=0.7, g=0.7, b=0.7, a=1.0)
ROTOR_PROPELLERS = (
    PropellerConfig("rotor_0", Vec3(0.13, -0.22, 0.023), PROP_CCW_MESH_URI, RED),
    PropellerConfig("rotor_1", Vec3(-0.13, 0.2, 0.023), PROP_CCW_MESH_URI, GREY),
    PropellerConfig("rotor_2", Vec3(0.13, 0.22, 0.023), PROP_CW_MESH_URI, RED),
    PropellerConfig("rotor_3", Vec3(-0.13, -0.2, 0.023), PROP_CW_MESH_URI, GREY),
)


@dataclass(frozen=True)
class RotorRobotConfig:
    name: str
    telemetry_prefix: str
    topic_prefix: str
    frame_id: str
    base_frame_id: str
    marker_name: str
    body_mesh_uri: str
    body_color: RgbaColor
    propellers: tuple[PropellerConfig, ...]


def rotor_robot_config_from_name(name: str) -> RotorRobotConfig:
    return RotorRobotConfig(
        name=name,
        telemetry_prefix=name,
        topic_prefix=f"/visualize_foxglove_sdk/{name}",
        frame_id="map",
        base_frame_id=f"{name}/base_link",
        marker_name=name,
        body_mesh_uri=BODY_MESH_URI,
        body_color=RED,
        propellers=ROTOR_PROPELLERS,
    )


def _float_value(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _str_value(value: Any, default: str) -> str:
    return value if isinstance(value, str) and value else default


def metadata_dict(metadata: dict[str, Any] | None) -> dict[str, Any]:
    if metadata is None:
        return {}
    if isinstance(metadata, dict):
        unknown_keys = sorted(set(metadata) - ROTOR_METADATA_KEYS)
        if unknown_keys:
            logging.warning("ignoring unsupported rotor metadata keys: %s", ", ".join(unknown_keys))
        return metadata
    logging.warning("rotor metadata must be a dict, got %s", type(metadata).__name__)
    return {}


def parse_gps_origin(value: Any, default: GpsOriginConfig | None = None) -> GpsOriginConfig:
    fallback = default or GpsOriginConfig()
    if not isinstance(value, dict):
        if value is not None:
            logging.warning("gps_origin metadata must be a dict, using default")
        return fallback
    return GpsOriginConfig(
        latitude=_float_value(value.get("latitude"), fallback.latitude),
        longitude=_float_value(value.get("longitude"), fallback.longitude),
        altitude=_float_value(value.get("altitude"), fallback.altitude),
    )


def clamp_color_channel(value: float) -> float:
    return min(max(value, 0.0), 1.0)


def parse_rgba_color(value: Any, default: RgbaColor | None = None) -> RgbaColor:
    fallback = default or RED
    if not isinstance(value, dict):
        if value is not None:
            logging.warning("color metadata must be a dict with r/g/b/a channels, using default")
        return fallback

    missing_channels = [channel for channel in ("r", "g", "b", "a") if channel not in value]
    if missing_channels:
        logging.warning("color metadata missing channels %s, falling back per channel", ", ".join(missing_channels))

    return RgbaColor(
        r=clamp_color_channel(_float_value(value.get("r"), fallback.r)),
        g=clamp_color_channel(_float_value(value.get("g"), fallback.g)),
        b=clamp_color_channel(_float_value(value.get("b"), fallback.b)),
        a=clamp_color_channel(_float_value(value.get("a"), fallback.a)),
    )


def runtime_from_metadata(metadata: dict[str, Any] | None) -> RotorDisplayRuntime:
    values = metadata_dict(metadata)
    position_source = _str_value(values.get("position_source"), "local_pos").lower()
    if position_source not in {"local_pos", "gps"}:
        logging.warning("unsupported position_source=%s, using local_pos", position_source)
        position_source = "local_pos"
    return RotorDisplayRuntime(
        position_source=position_source,
        history_duration_sec=max(_float_value(values.get("history_duration_sec"), 5.0), 0.0),
        gps_origin=parse_gps_origin(values.get("gps_origin")),
        color=parse_rgba_color(values.get("color"), RED),
    )


def merge_runtime_metadata(current: RotorDisplayRuntime, metadata: dict[str, Any] | None) -> RotorDisplayRuntime:
    values = metadata_dict(metadata)
    position_source = current.position_source
    if "position_source" in values:
        position_source = _str_value(values.get("position_source"), current.position_source).lower()
        if position_source not in {"local_pos", "gps"}:
            logging.warning("unsupported position_source=%s, keeping %s", position_source, current.position_source)
            position_source = current.position_source

    history_duration_sec = current.history_duration_sec
    if "history_duration_sec" in values:
        history_duration_sec = max(_float_value(values.get("history_duration_sec"), current.history_duration_sec), 0.0)

    gps_origin = current.gps_origin
    if "gps_origin" in values:
        gps_origin = parse_gps_origin(values.get("gps_origin"), current.gps_origin)

    color = current.color
    if "color" in values:
        color = parse_rgba_color(values.get("color"), current.color)

    return RotorDisplayRuntime(
        position_source=position_source,
        history_duration_sec=history_duration_sec,
        gps_origin=gps_origin,
        color=color,
    )


def metadata_from_runtime(runtime: RotorDisplayRuntime) -> dict[str, Any]:
    return {
        "robot_type": "rotor",
        "position_source": runtime.position_source,
        "history_duration_sec": runtime.history_duration_sec,
        "gps_origin": {
            "latitude": runtime.gps_origin.latitude,
            "longitude": runtime.gps_origin.longitude,
            "altitude": runtime.gps_origin.altitude,
        },
        "color": {
            "r": runtime.color.r,
            "g": runtime.color.g,
            "b": runtime.color.b,
            "a": runtime.color.a,
        },
    }


def decode_payload(payload: Any, encoding: str | None) -> dict[str, Any] | None:
    if isinstance(payload, bytes):
        raw = payload
    elif isinstance(payload, bytearray):
        raw = bytes(payload)
    elif isinstance(payload, memoryview):
        raw = payload.tobytes()
    elif isinstance(payload, str):
        raw = payload.encode("utf-8")
    else:
        try:
            raw = bytes(payload)
        except (TypeError, ValueError):
            logging.warning("unsupported zenoh payload type: %s", type(payload).__name__)
            return None

    normalized = (encoding or "").lower()
    try:
        if "cbor" in normalized:
            if cbor2 is None:
                logging.warning("received CBOR telemetry but cbor2 is unavailable")
                return None
            decoded = cbor2.loads(raw)
        else:
            decoded = json.loads(raw.decode("utf-8"))
    except Exception:
        logging.exception("failed to decode telemetry payload encoding=%s", encoding)
        return None

    return decoded if isinstance(decoded, dict) else None


def finite_fields(data: Any, fields: tuple[str, ...]) -> tuple[float, ...] | None:
    if not isinstance(data, dict):
        return None
    values = tuple(data.get(key) for key in fields)
    if any(type(v) not in (float, int) or not math.isfinite(v) for v in values):
        return None
    return values


def current_quaternion(value: Any) -> Quaternion | None:
    q = finite_fields(value, ("x", "y", "z", "w"))
    if q is None:
        return None
    norm = math.hypot(*q)
    if not math.isfinite(norm) or norm < 1e-8:
        return None
    return Quaternion(x=q[0]/norm, y=q[1]/norm, z=q[2]/norm, w=q[3]/norm)


def enu_from_gps(lat: float, lon: float, alt: float, origin: Any) -> Vec3:
    lat0 = math.radians(origin.latitude)
    lon0 = math.radians(origin.longitude)
    lat1 = math.radians(lat)
    lon1 = math.radians(lon)
    earth_radius = 6378137.0
    east = (lon1 - lon0) * math.cos((lat0 + lat1) * 0.5) * earth_radius
    north = (lat1 - lat0) * earth_radius
    up = alt - origin.altitude
    return Vec3(x=east, y=north, z=up)


def yaw_to_quaternion(yaw: float) -> Quaternion:
    return Quaternion(x=0.0, y=0.0, z=math.sin(yaw * 0.5), w=math.cos(yaw * 0.5))


def wrap_to_pi(value: float) -> float:
    return value - 2.0 * math.pi * math.floor((value + math.pi) / (2.0 * math.pi))


class RotorDroneVisualizer:
    '''
    Visualizer for a single rotor drone, subscribing to telemetry via Zenoh and publishing visualization data via the Foxglove SDK.
    '''
    def __init__(self, config: RotorRobotConfig, runtime: Any) -> None:
        self.config = config
        self.runtime = runtime
        self.state: dict[str, Any] | None = None
        self.local_pos: dict[str, Any] | None = None
        self.gps: dict[str, Any] | None = None
        self.received: dict[str, float] = {}
        self.last_history_sample: float | None = None
        self.propeller_angles = [0.0, 0.5, 2.6, 1.4]
        self.history: deque[tuple[float, Vec3]] = deque()
        self.last_history_publish_time = 0.0
        self.lock = threading.Lock()

    @property
    def key_prefix(self) -> str:
        return self.config.telemetry_prefix

    def update_stream(self, stream: str, envelope: dict[str, Any]) -> None:
        data = envelope.get("data")
        if not isinstance(data, dict):
            return
        sources = envelope.get("sources")
        if not isinstance(sources, dict):
            sources = {}
        data = dict(data)
        for source, field_name in (("pose", "position"), ("attitude", "orientation"), ("global", "global")):
            info = sources.get(source)
            if isinstance(info, dict) and info.get("fresh") is False:
                data[field_name] = None
        with self.lock:
            if stream == "state":
                self.state = data
            elif stream == "local_pos":
                self.local_pos = data
            elif stream == "gps":
                self.gps = data
            self.received[stream] = time.monotonic()

    def update_runtime(self, runtime: Any) -> None:
        with self.lock:
            previous = self.runtime
            self.runtime = runtime
            if self._coordinate_runtime_changed(previous, runtime):
                self.history.clear()
                self.last_history_sample = None
                self.last_history_publish_time = 0.0

    def _coordinate_runtime_changed(self, previous: Any, current: Any) -> bool:
        if previous.position_source.lower() != current.position_source.lower():
            return True
        old_origin = previous.gps_origin
        new_origin = current.gps_origin
        return (
            old_origin.latitude != new_origin.latitude
            or old_origin.longitude != new_origin.longitude
            or old_origin.altitude != new_origin.altitude
        )

    def publish(self, now: float, dt: float, history_publish_rate_hz: float) -> None:
        received_now = time.monotonic()
        with self.lock:
            local_pos = self.local_pos if received_now - self.received.get("local_pos", -math.inf) <= 0.5 else None
            gps = self.gps if received_now - self.received.get("gps", -math.inf) <= 2.0 else None
            state = self.state if received_now - self.received.get("state", -math.inf) <= 2.5 else None
            runtime = self.runtime
            pose = self._current_pose(local_pos or {}, gps or {}, runtime)
            if pose is None:
                self.history.clear()
                self.last_history_sample = None
                return
            position, orientation = pose
            sample_time = self.received["gps" if runtime.position_source == "gps" else "local_pos"]
            if self.last_history_sample != sample_time:
                self._update_history(sample_time, position, runtime)
                self.last_history_sample = sample_time
            history = list(self.history)

        # Use station time for TF, scene and path when remote clocks disagree.
        stamp = Timestamp.from_epoch_secs(now)
        state = state or {}
        self._update_propeller_angles(state, dt)
        self._publish_pose(stamp, Pose(position=position.to_msg(), orientation=orientation))
        self._publish_tf(stamp, position, orientation)
        self._publish_robot_scene(stamp, state, runtime)
        self._publish_gps_origin(stamp, runtime)
        if received_now - self.last_history_publish_time >= 1.0 / max(history_publish_rate_hz, 0.1):
            self._publish_history(stamp, runtime, history)
            self.last_history_publish_time = received_now

    def _current_pose(
        self,
        local_pos: dict[str, Any],
        gps: dict[str, Any],
        runtime: RotorDisplayRuntime,
    ) -> tuple[Vec3, Quaternion] | None:
        orientation = current_quaternion(local_pos.get("orientation"))
        if orientation is None:
            return None
        if runtime.position_source == "gps":
            fix = finite_fields(gps.get("global"), ("lat", "lon", "alt"))
            if fix is None or abs(fix[0]) > 90 or abs(fix[1]) > 180:
                return None
            return enu_from_gps(*fix, runtime.gps_origin), orientation
        xyz = finite_fields(local_pos.get("position"), ("x", "y", "z"))
        if xyz is None:
            return None
        return Vec3(*xyz), orientation

    def _publish_pose(self, stamp: Timestamp, pose: Pose) -> None:
        foxglove.log(
            f"{self.config.topic_prefix}/pose",
            PoseInFrame(timestamp=stamp, frame_id=self.config.frame_id, pose=pose),
        )

    def _publish_tf(self, stamp: Timestamp, position: Vec3, orientation: Quaternion) -> None:
        foxglove.log(
            f"{self.config.topic_prefix}/tf",
            FrameTransforms(
                transforms=[
                    FrameTransform(
                        timestamp=stamp,
                        parent_frame_id=self.config.frame_id,
                        child_frame_id=self.config.base_frame_id,
                        translation=position.to_msg(),
                        rotation=orientation,
                    )
                ]
            ),
        )

    def _update_propeller_angles(self, state: dict[str, Any], dt: float) -> None:
        omega = ROTOR_RPM * 2.0 * math.pi / 60.0 if state.get("armed", False) else 0.0
        angles: list[float] = []
        for index, angle in enumerate(self.propeller_angles):
            mesh_uri = self.config.propellers[index].mesh_uri if index < len(self.config.propellers) else ""
            direction = -1.0 if "_cw" in mesh_uri else 1.0
            angles.append(wrap_to_pi(angle + direction * omega * dt))
        self.propeller_angles = angles

    def _publish_robot_scene(self, stamp: Timestamp, state: dict[str, Any], runtime: Any) -> None:
        metadata = [
            KeyValuePair(key="robot", value=self.config.name),
            KeyValuePair(key="armed", value=str(state["armed"]).lower() if isinstance(state.get("armed"), bool) else "unknown"),
        ]
        propeller_models = []
        for index, propeller in enumerate(self.config.propellers):
            angle = self.propeller_angles[index] if index < len(self.propeller_angles) else 0.0
            propeller_color = GREY if propeller.color == GREY else runtime.color
            propeller_models.append(
                ModelPrimitive(
                    pose=Pose(position=propeller.origin.to_msg(), orientation=yaw_to_quaternion(angle)),
                    scale=Vector3(x=1.0, y=1.0, z=1.0),
                    color=propeller_color.to_msg(),
                    override_color=True,
                    url=propeller.mesh_uri,
                    media_type="model/stl",
                )
            )

        foxglove.log(
            f"{self.config.topic_prefix}/scene",
            SceneUpdate(
                entities=[
                    SceneEntity(
                        timestamp=stamp,
                        frame_id=self.config.base_frame_id,
                        id=f"{self.config.name}/body",
                        frame_locked=True,
                        lifetime=Duration(sec=1),
                        metadata=metadata,
                        models=[
                            ModelPrimitive(
                                pose=Pose(
                                    position=Vector3(x=0.0, y=0.0, z=0.0),
                                    orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=1.0),
                                ),
                                scale=Vector3(x=1.0, y=1.0, z=1.0),
                                color=runtime.color.to_msg(),
                                override_color=True,
                                url=self.config.body_mesh_uri,
                                media_type="model/stl",
                            )
                        ],
                    ),
                    SceneEntity(
                        timestamp=stamp,
                        frame_id=self.config.base_frame_id,
                        id=f"{self.config.name}/propellers",
                        frame_locked=True,
                        lifetime=Duration(sec=1),
                        metadata=metadata,
                        models=propeller_models,
                    ),
                    SceneEntity(
                        timestamp=stamp,
                        frame_id=self.config.base_frame_id,
                        id=f"{self.config.name}/label",
                        frame_locked=True,
                        lifetime=Duration(sec=1),
                        texts=[
                            TextPrimitive(
                                pose=Pose(
                                    position=Vector3(x=0.27, y=0.27, z=0.27),
                                    orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=1.0),
                                ),
                                billboard=True,
                                font_size=0.2,
                                color=Color(r=0.0, g=0.0, b=0.0, a=0.9),
                                text=self.config.marker_name,
                            )
                        ],
                    ),
                ]
            ),
        )

    def _publish_gps_origin(self, stamp: Timestamp, runtime: Any) -> None:
        if runtime.position_source.lower() != "gps":
            return
        origin = runtime.gps_origin
        foxglove.log(
            f"{self.config.topic_prefix}/gps_origin",
            LocationFix(
                timestamp=stamp,
                frame_id=self.config.frame_id,
                latitude=origin.latitude,
                longitude=origin.longitude,
                altitude=origin.altitude,
                position_covariance=[0.0] * 9,
                position_covariance_type=LocationFixPositionCovarianceType.Known,
                color=Color(r=0.0, g=0.7, b=0.15, a=1.0),
                metadata=[KeyValuePair(key="role", value="origin")],
            ),
        )

    def _update_history(self, now: float, position: Vec3, runtime: Any) -> None:
        self.history.append((now, position))
        cutoff = now - max(runtime.history_duration_sec, 0.0)
        while self.history and self.history[0][0] < cutoff:
            self.history.popleft()

    def _publish_history(self, stamp: Timestamp, runtime: Any, history: list[tuple[float, Vec3]]) -> None:
        if len(history) < 2:
            return
        history_color = runtime.color.with_alpha(0.9)
        foxglove.log(
            f"{self.config.topic_prefix}/history_path",
            SceneUpdate(
                entities=[
                    SceneEntity(
                        timestamp=stamp,
                        frame_id=self.config.frame_id,
                        id=f"{self.config.name}/history_path",
                        frame_locked=True,
                        lifetime=Duration(sec=1),
                        lines=[
                            LinePrimitive(
                                type=LinePrimitiveLineType.LineStrip,
                                pose=Pose(
                                    position=Vector3(x=0.0, y=0.0, z=0.0),
                                    orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=1.0),
                                ),
                                thickness=1.0,
                                scale_invariant=True,
                                points=[point.to_point_msg() for _, point in history],
                                color=history_color.to_msg(),
                            )
                        ],
                    )
                ]
            ),
        )


class RotorVisualizerManager:
    '''
    Manages visualization for multiple rotor drones.
    '''
    def __init__(self, server_runtime: Any) -> None:
        self.server_runtime = server_runtime
        self.visualizers: dict[str, RotorDroneVisualizer] = {}
        self._threads: list[threading.Thread] = []
        self._lock = threading.RLock()
        self._session: Any | None = None
        self._subscribers: dict[str, Any] = {}
        self._stop_event: threading.Event | None = None

    def add_robot(self, name: str, metadata: dict[str, Any] | None = None) -> bool:
        if not name or any(c in name for c in "/*$?#"):
            logging.warning("invalid robot telemetry key segment: %r", name)
            return False
        try:
            zenoh.KeyExpr(name)
        except (TypeError, ValueError, zenoh.ZError):
            logging.warning("invalid robot telemetry key: %r", name)
            return False
        with self._lock:
            if name in self.visualizers:
                logging.warning("rotor visualizer %s already exists", name)
                return False
            runtime = runtime_from_metadata(metadata)
            visualizer = RotorDroneVisualizer(rotor_robot_config_from_name(name), runtime)
            self.visualizers[name] = visualizer
            try:
                self._declare_robot_subscribers_locked(name)
            except Exception:
                self._undeclare_robot_subscribers_locked(name)
                del self.visualizers[name]
                logging.exception("failed to subscribe robot %s", name)
                return False
        logging.info("added rotor visualizer %s", name)
        return True

    def update_robot(self, name: str, metadata: dict[str, Any] | None = None) -> bool:
        with self._lock:
            visualizer = self.visualizers.get(name)
            if visualizer is None:
                logging.warning("cannot update missing rotor visualizer %s", name)
                return False
            runtime = merge_runtime_metadata(visualizer.runtime, metadata)
            visualizer.update_runtime(runtime)
        logging.info("updated rotor visualizer %s", name)
        return True

    def robot_runtime(self, name: str) -> Any | None:
        with self._lock:
            visualizer = self.visualizers.get(name)
            return visualizer.runtime if visualizer is not None else None

    def list_robots(self) -> list[dict[str, Any]]:
        with self._lock:
            return [
                {
                    "name": name,
                    "metadata": metadata_from_runtime(visualizer.runtime),
                }
                for name, visualizer in sorted(self.visualizers.items())
            ]

    def remove_robot(self, name: str) -> bool:
        with self._lock:
            visualizer = self.visualizers.pop(name, None)
            if visualizer is None:
                logging.warning("cannot remove missing rotor visualizer %s", name)
                return False
            self._undeclare_robot_subscribers_locked(name)
        logging.info("removed rotor visualizer %s", name)
        return True

    @staticmethod
    def handle_sample(visualizer: RotorDroneVisualizer, stream: str, sample: zenoh.Sample) -> None:
        if sample.kind != zenoh.SampleKind.PUT:
            return
        envelope = decode_payload(sample.payload.to_bytes(), str(sample.encoding))
        if envelope is not None:
            visualizer.update_stream(stream, envelope)

    def start(self, endpoint: str, stop_event: threading.Event) -> None:
        self._stop_event = stop_event
        self._threads = [
            threading.Thread(
                target=self._publish_forever,
                args=(stop_event,),
                name="rotor-visualizer-publisher",
                daemon=True,
            ),
            threading.Thread(
                target=self._run_zenoh_until_stopped,
                args=(endpoint, stop_event),
                name="rotor-visualizer-zenoh",
                daemon=True,
            ),
        ]
        for thread in self._threads:
            thread.start()

    def stop(self) -> None:
        if self._stop_event is not None:
            self._stop_event.set()
        with self._lock:
            self._undeclare_all_subscribers_locked()
        for thread in self._threads:
            thread.join(timeout=2.0)
        self._threads = []
        self._stop_event = None

    def _publish_forever(self, stop_event: threading.Event) -> None:
        period = 1.0 / max(self.server_runtime.publish_rate_hz, 0.1)
        last = time.monotonic()
        while not stop_event.is_set():
            now = time.monotonic()
            wall_now = time.time()
            dt = max(now - last, 0.0)
            with self._lock:
                visualizers = list(self.visualizers.values())
            for visualizer in visualizers:
                try:
                    visualizer.publish(wall_now, dt, self.server_runtime.history_publish_rate_hz)
                except Exception:
                    logging.exception("failed to publish rotor visualizer update")
            last = now
            stop_event.wait(period)

    def subscription_keys(self) -> list[str]:
        keys: list[str] = []
        with self._lock:
            visualizers = list(self.visualizers.values())
        for visualizer in visualizers:
            base = visualizer.key_prefix
            keys.extend(
                [
                    f"{base}/telemetry/state",
                    f"{base}/telemetry/local_pos",
                    f"{base}/telemetry/gps",
                ]
            )
        return keys

    def _robot_subscription_keys(self, name: str) -> list[str]:
        return [
            f"{name}/telemetry/state",
            f"{name}/telemetry/local_pos",
            f"{name}/telemetry/gps",
        ]

    def _declare_robot_subscribers_locked(self, name: str) -> None:
        if self._session is None:
            return
        for key in self._robot_subscription_keys(name):
            if key in self._subscribers:
                continue
            # Capture this generation's visualizer so undeclare never waits for a
            # callback that itself needs the manager's subscription lock.
            callback = partial(self.handle_sample, self.visualizers[name], key.rsplit("/", 1)[1])
            self._subscribers[key] = self._session.declare_subscriber(key, callback)
            logging.info("subscribed rotor telemetry key %s", key)

    def _undeclare_robot_subscribers_locked(self, name: str) -> None:
        for key in self._robot_subscription_keys(name):
            subscriber = self._subscribers.pop(key, None)
            if subscriber is not None:
                close_subscriber(subscriber)

    def _undeclare_all_subscribers_locked(self) -> None:
        for subscriber in list(self._subscribers.values()):
            close_subscriber(subscriber)
        self._subscribers.clear()

    def _run_zenoh_until_stopped(self, endpoint: str, stop_event: threading.Event) -> None:
        config = zenoh.Config()
        if endpoint:
            config.insert_json5("connect/endpoints", json.dumps([endpoint]))
            config.insert_json5("scouting/multicast/enabled", "false")
        while not stop_event.is_set():
            try:
                with zenoh.open(config) as session:
                    try:
                        with self._lock:
                            self._session = session
                            for name in self.visualizers:
                                self._declare_robot_subscribers_locked(name)
                        logging.info("Zenoh telemetry session open (%s)", endpoint or "LAN discovery")
                        stop_event.wait()
                    finally:
                        with self._lock:
                            self._undeclare_all_subscribers_locked()
                            self._session = None
            except Exception:
                if not stop_event.is_set():
                    logging.exception("Zenoh telemetry session failed; retrying")
                    stop_event.wait(2)


def close_subscriber(subscriber: zenoh.Subscriber) -> None:
    subscriber.undeclare()
